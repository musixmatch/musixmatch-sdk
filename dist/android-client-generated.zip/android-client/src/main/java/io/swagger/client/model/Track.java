/**
 * Musixmatch API
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop 
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.swagger.client.model;

import io.swagger.client.model.TrackPrimaryGenres;
import io.swagger.client.model.TrackSecondaryGenres;
import java.math.BigDecimal;
import java.util.*;

import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


/**
 * a song in the Musixmatch database
 **/
@ApiModel(description = "a song in the Musixmatch database")
public class Track  {
  
  @SerializedName("instrumental")
  private BigDecimal instrumental = null;
  @SerializedName("album_coverart_350x350")
  private String albumCoverart350x350 = null;
  @SerializedName("first_release_date")
  private String firstReleaseDate = null;
  @SerializedName("track_isrc")
  private String trackIsrc = null;
  @SerializedName("explicit")
  private BigDecimal explicit = null;
  @SerializedName("track_edit_url")
  private String trackEditUrl = null;
  @SerializedName("num_favourite")
  private BigDecimal numFavourite = null;
  @SerializedName("album_coverart_500x500")
  private String albumCoverart500x500 = null;
  @SerializedName("album_name")
  private String albumName = null;
  @SerializedName("track_rating")
  private BigDecimal trackRating = null;
  @SerializedName("track_share_url")
  private String trackShareUrl = null;
  @SerializedName("track_soundcloud_id")
  private BigDecimal trackSoundcloudId = null;
  @SerializedName("artist_name")
  private String artistName = null;
  @SerializedName("album_coverart_800x800")
  private String albumCoverart800x800 = null;
  @SerializedName("album_coverart_100x100")
  private String albumCoverart100x100 = null;
  @SerializedName("track_name_translation_list")
  private List<String> trackNameTranslationList = null;
  @SerializedName("track_name")
  private String trackName = null;
  @SerializedName("restricted")
  private BigDecimal restricted = null;
  @SerializedName("has_subtitles")
  private BigDecimal hasSubtitles = null;
  @SerializedName("updated_time")
  private String updatedTime = null;
  @SerializedName("subtitle_id")
  private BigDecimal subtitleId = null;
  @SerializedName("lyrics_id")
  private BigDecimal lyricsId = null;
  @SerializedName("track_spotify_id")
  private String trackSpotifyId = null;
  @SerializedName("has_lyrics")
  private BigDecimal hasLyrics = null;
  @SerializedName("artist_id")
  private BigDecimal artistId = null;
  @SerializedName("album_id")
  private BigDecimal albumId = null;
  @SerializedName("artist_mbid")
  private String artistMbid = null;
  @SerializedName("secondary_genres")
  private TrackSecondaryGenres secondaryGenres = null;
  @SerializedName("commontrack_vanity_id")
  private String commontrackVanityId = null;
  @SerializedName("track_id")
  private BigDecimal trackId = null;
  @SerializedName("track_xboxmusic_id")
  private String trackXboxmusicId = null;
  @SerializedName("primary_genres")
  private TrackPrimaryGenres primaryGenres = null;
  @SerializedName("track_length")
  private BigDecimal trackLength = null;
  @SerializedName("track_mbid")
  private String trackMbid = null;
  @SerializedName("commontrack_id")
  private BigDecimal commontrackId = null;

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getInstrumental() {
    return instrumental;
  }
  public void setInstrumental(BigDecimal instrumental) {
    this.instrumental = instrumental;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCoverart350x350() {
    return albumCoverart350x350;
  }
  public void setAlbumCoverart350x350(String albumCoverart350x350) {
    this.albumCoverart350x350 = albumCoverart350x350;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getFirstReleaseDate() {
    return firstReleaseDate;
  }
  public void setFirstReleaseDate(String firstReleaseDate) {
    this.firstReleaseDate = firstReleaseDate;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getTrackIsrc() {
    return trackIsrc;
  }
  public void setTrackIsrc(String trackIsrc) {
    this.trackIsrc = trackIsrc;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getExplicit() {
    return explicit;
  }
  public void setExplicit(BigDecimal explicit) {
    this.explicit = explicit;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getTrackEditUrl() {
    return trackEditUrl;
  }
  public void setTrackEditUrl(String trackEditUrl) {
    this.trackEditUrl = trackEditUrl;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getNumFavourite() {
    return numFavourite;
  }
  public void setNumFavourite(BigDecimal numFavourite) {
    this.numFavourite = numFavourite;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCoverart500x500() {
    return albumCoverart500x500;
  }
  public void setAlbumCoverart500x500(String albumCoverart500x500) {
    this.albumCoverart500x500 = albumCoverart500x500;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumName() {
    return albumName;
  }
  public void setAlbumName(String albumName) {
    this.albumName = albumName;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getTrackRating() {
    return trackRating;
  }
  public void setTrackRating(BigDecimal trackRating) {
    this.trackRating = trackRating;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getTrackShareUrl() {
    return trackShareUrl;
  }
  public void setTrackShareUrl(String trackShareUrl) {
    this.trackShareUrl = trackShareUrl;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getTrackSoundcloudId() {
    return trackSoundcloudId;
  }
  public void setTrackSoundcloudId(BigDecimal trackSoundcloudId) {
    this.trackSoundcloudId = trackSoundcloudId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getArtistName() {
    return artistName;
  }
  public void setArtistName(String artistName) {
    this.artistName = artistName;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCoverart800x800() {
    return albumCoverart800x800;
  }
  public void setAlbumCoverart800x800(String albumCoverart800x800) {
    this.albumCoverart800x800 = albumCoverart800x800;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCoverart100x100() {
    return albumCoverart100x100;
  }
  public void setAlbumCoverart100x100(String albumCoverart100x100) {
    this.albumCoverart100x100 = albumCoverart100x100;
  }

  /**
   **/
  @ApiModelProperty(value = "")
  public List<String> getTrackNameTranslationList() {
    return trackNameTranslationList;
  }
  public void setTrackNameTranslationList(List<String> trackNameTranslationList) {
    this.trackNameTranslationList = trackNameTranslationList;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getTrackName() {
    return trackName;
  }
  public void setTrackName(String trackName) {
    this.trackName = trackName;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getRestricted() {
    return restricted;
  }
  public void setRestricted(BigDecimal restricted) {
    this.restricted = restricted;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getHasSubtitles() {
    return hasSubtitles;
  }
  public void setHasSubtitles(BigDecimal hasSubtitles) {
    this.hasSubtitles = hasSubtitles;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getUpdatedTime() {
    return updatedTime;
  }
  public void setUpdatedTime(String updatedTime) {
    this.updatedTime = updatedTime;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getSubtitleId() {
    return subtitleId;
  }
  public void setSubtitleId(BigDecimal subtitleId) {
    this.subtitleId = subtitleId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getLyricsId() {
    return lyricsId;
  }
  public void setLyricsId(BigDecimal lyricsId) {
    this.lyricsId = lyricsId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getTrackSpotifyId() {
    return trackSpotifyId;
  }
  public void setTrackSpotifyId(String trackSpotifyId) {
    this.trackSpotifyId = trackSpotifyId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getHasLyrics() {
    return hasLyrics;
  }
  public void setHasLyrics(BigDecimal hasLyrics) {
    this.hasLyrics = hasLyrics;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getArtistId() {
    return artistId;
  }
  public void setArtistId(BigDecimal artistId) {
    this.artistId = artistId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getAlbumId() {
    return albumId;
  }
  public void setAlbumId(BigDecimal albumId) {
    this.albumId = albumId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getArtistMbid() {
    return artistMbid;
  }
  public void setArtistMbid(String artistMbid) {
    this.artistMbid = artistMbid;
  }

  /**
   **/
  @ApiModelProperty(value = "")
  public TrackSecondaryGenres getSecondaryGenres() {
    return secondaryGenres;
  }
  public void setSecondaryGenres(TrackSecondaryGenres secondaryGenres) {
    this.secondaryGenres = secondaryGenres;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getCommontrackVanityId() {
    return commontrackVanityId;
  }
  public void setCommontrackVanityId(String commontrackVanityId) {
    this.commontrackVanityId = commontrackVanityId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getTrackId() {
    return trackId;
  }
  public void setTrackId(BigDecimal trackId) {
    this.trackId = trackId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getTrackXboxmusicId() {
    return trackXboxmusicId;
  }
  public void setTrackXboxmusicId(String trackXboxmusicId) {
    this.trackXboxmusicId = trackXboxmusicId;
  }

  /**
   **/
  @ApiModelProperty(value = "")
  public TrackPrimaryGenres getPrimaryGenres() {
    return primaryGenres;
  }
  public void setPrimaryGenres(TrackPrimaryGenres primaryGenres) {
    this.primaryGenres = primaryGenres;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getTrackLength() {
    return trackLength;
  }
  public void setTrackLength(BigDecimal trackLength) {
    this.trackLength = trackLength;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getTrackMbid() {
    return trackMbid;
  }
  public void setTrackMbid(String trackMbid) {
    this.trackMbid = trackMbid;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getCommontrackId() {
    return commontrackId;
  }
  public void setCommontrackId(BigDecimal commontrackId) {
    this.commontrackId = commontrackId;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Track track = (Track) o;
    return (instrumental == null ? track.instrumental == null : instrumental.equals(track.instrumental)) &&
        (albumCoverart350x350 == null ? track.albumCoverart350x350 == null : albumCoverart350x350.equals(track.albumCoverart350x350)) &&
        (firstReleaseDate == null ? track.firstReleaseDate == null : firstReleaseDate.equals(track.firstReleaseDate)) &&
        (trackIsrc == null ? track.trackIsrc == null : trackIsrc.equals(track.trackIsrc)) &&
        (explicit == null ? track.explicit == null : explicit.equals(track.explicit)) &&
        (trackEditUrl == null ? track.trackEditUrl == null : trackEditUrl.equals(track.trackEditUrl)) &&
        (numFavourite == null ? track.numFavourite == null : numFavourite.equals(track.numFavourite)) &&
        (albumCoverart500x500 == null ? track.albumCoverart500x500 == null : albumCoverart500x500.equals(track.albumCoverart500x500)) &&
        (albumName == null ? track.albumName == null : albumName.equals(track.albumName)) &&
        (trackRating == null ? track.trackRating == null : trackRating.equals(track.trackRating)) &&
        (trackShareUrl == null ? track.trackShareUrl == null : trackShareUrl.equals(track.trackShareUrl)) &&
        (trackSoundcloudId == null ? track.trackSoundcloudId == null : trackSoundcloudId.equals(track.trackSoundcloudId)) &&
        (artistName == null ? track.artistName == null : artistName.equals(track.artistName)) &&
        (albumCoverart800x800 == null ? track.albumCoverart800x800 == null : albumCoverart800x800.equals(track.albumCoverart800x800)) &&
        (albumCoverart100x100 == null ? track.albumCoverart100x100 == null : albumCoverart100x100.equals(track.albumCoverart100x100)) &&
        (trackNameTranslationList == null ? track.trackNameTranslationList == null : trackNameTranslationList.equals(track.trackNameTranslationList)) &&
        (trackName == null ? track.trackName == null : trackName.equals(track.trackName)) &&
        (restricted == null ? track.restricted == null : restricted.equals(track.restricted)) &&
        (hasSubtitles == null ? track.hasSubtitles == null : hasSubtitles.equals(track.hasSubtitles)) &&
        (updatedTime == null ? track.updatedTime == null : updatedTime.equals(track.updatedTime)) &&
        (subtitleId == null ? track.subtitleId == null : subtitleId.equals(track.subtitleId)) &&
        (lyricsId == null ? track.lyricsId == null : lyricsId.equals(track.lyricsId)) &&
        (trackSpotifyId == null ? track.trackSpotifyId == null : trackSpotifyId.equals(track.trackSpotifyId)) &&
        (hasLyrics == null ? track.hasLyrics == null : hasLyrics.equals(track.hasLyrics)) &&
        (artistId == null ? track.artistId == null : artistId.equals(track.artistId)) &&
        (albumId == null ? track.albumId == null : albumId.equals(track.albumId)) &&
        (artistMbid == null ? track.artistMbid == null : artistMbid.equals(track.artistMbid)) &&
        (secondaryGenres == null ? track.secondaryGenres == null : secondaryGenres.equals(track.secondaryGenres)) &&
        (commontrackVanityId == null ? track.commontrackVanityId == null : commontrackVanityId.equals(track.commontrackVanityId)) &&
        (trackId == null ? track.trackId == null : trackId.equals(track.trackId)) &&
        (trackXboxmusicId == null ? track.trackXboxmusicId == null : trackXboxmusicId.equals(track.trackXboxmusicId)) &&
        (primaryGenres == null ? track.primaryGenres == null : primaryGenres.equals(track.primaryGenres)) &&
        (trackLength == null ? track.trackLength == null : trackLength.equals(track.trackLength)) &&
        (trackMbid == null ? track.trackMbid == null : trackMbid.equals(track.trackMbid)) &&
        (commontrackId == null ? track.commontrackId == null : commontrackId.equals(track.commontrackId));
  }

  @Override
  public int hashCode() {
    int result = 17;
    result = 31 * result + (instrumental == null ? 0: instrumental.hashCode());
    result = 31 * result + (albumCoverart350x350 == null ? 0: albumCoverart350x350.hashCode());
    result = 31 * result + (firstReleaseDate == null ? 0: firstReleaseDate.hashCode());
    result = 31 * result + (trackIsrc == null ? 0: trackIsrc.hashCode());
    result = 31 * result + (explicit == null ? 0: explicit.hashCode());
    result = 31 * result + (trackEditUrl == null ? 0: trackEditUrl.hashCode());
    result = 31 * result + (numFavourite == null ? 0: numFavourite.hashCode());
    result = 31 * result + (albumCoverart500x500 == null ? 0: albumCoverart500x500.hashCode());
    result = 31 * result + (albumName == null ? 0: albumName.hashCode());
    result = 31 * result + (trackRating == null ? 0: trackRating.hashCode());
    result = 31 * result + (trackShareUrl == null ? 0: trackShareUrl.hashCode());
    result = 31 * result + (trackSoundcloudId == null ? 0: trackSoundcloudId.hashCode());
    result = 31 * result + (artistName == null ? 0: artistName.hashCode());
    result = 31 * result + (albumCoverart800x800 == null ? 0: albumCoverart800x800.hashCode());
    result = 31 * result + (albumCoverart100x100 == null ? 0: albumCoverart100x100.hashCode());
    result = 31 * result + (trackNameTranslationList == null ? 0: trackNameTranslationList.hashCode());
    result = 31 * result + (trackName == null ? 0: trackName.hashCode());
    result = 31 * result + (restricted == null ? 0: restricted.hashCode());
    result = 31 * result + (hasSubtitles == null ? 0: hasSubtitles.hashCode());
    result = 31 * result + (updatedTime == null ? 0: updatedTime.hashCode());
    result = 31 * result + (subtitleId == null ? 0: subtitleId.hashCode());
    result = 31 * result + (lyricsId == null ? 0: lyricsId.hashCode());
    result = 31 * result + (trackSpotifyId == null ? 0: trackSpotifyId.hashCode());
    result = 31 * result + (hasLyrics == null ? 0: hasLyrics.hashCode());
    result = 31 * result + (artistId == null ? 0: artistId.hashCode());
    result = 31 * result + (albumId == null ? 0: albumId.hashCode());
    result = 31 * result + (artistMbid == null ? 0: artistMbid.hashCode());
    result = 31 * result + (secondaryGenres == null ? 0: secondaryGenres.hashCode());
    result = 31 * result + (commontrackVanityId == null ? 0: commontrackVanityId.hashCode());
    result = 31 * result + (trackId == null ? 0: trackId.hashCode());
    result = 31 * result + (trackXboxmusicId == null ? 0: trackXboxmusicId.hashCode());
    result = 31 * result + (primaryGenres == null ? 0: primaryGenres.hashCode());
    result = 31 * result + (trackLength == null ? 0: trackLength.hashCode());
    result = 31 * result + (trackMbid == null ? 0: trackMbid.hashCode());
    result = 31 * result + (commontrackId == null ? 0: commontrackId.hashCode());
    return result;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Track {\n");
    
    sb.append("  instrumental: ").append(instrumental).append("\n");
    sb.append("  albumCoverart350x350: ").append(albumCoverart350x350).append("\n");
    sb.append("  firstReleaseDate: ").append(firstReleaseDate).append("\n");
    sb.append("  trackIsrc: ").append(trackIsrc).append("\n");
    sb.append("  explicit: ").append(explicit).append("\n");
    sb.append("  trackEditUrl: ").append(trackEditUrl).append("\n");
    sb.append("  numFavourite: ").append(numFavourite).append("\n");
    sb.append("  albumCoverart500x500: ").append(albumCoverart500x500).append("\n");
    sb.append("  albumName: ").append(albumName).append("\n");
    sb.append("  trackRating: ").append(trackRating).append("\n");
    sb.append("  trackShareUrl: ").append(trackShareUrl).append("\n");
    sb.append("  trackSoundcloudId: ").append(trackSoundcloudId).append("\n");
    sb.append("  artistName: ").append(artistName).append("\n");
    sb.append("  albumCoverart800x800: ").append(albumCoverart800x800).append("\n");
    sb.append("  albumCoverart100x100: ").append(albumCoverart100x100).append("\n");
    sb.append("  trackNameTranslationList: ").append(trackNameTranslationList).append("\n");
    sb.append("  trackName: ").append(trackName).append("\n");
    sb.append("  restricted: ").append(restricted).append("\n");
    sb.append("  hasSubtitles: ").append(hasSubtitles).append("\n");
    sb.append("  updatedTime: ").append(updatedTime).append("\n");
    sb.append("  subtitleId: ").append(subtitleId).append("\n");
    sb.append("  lyricsId: ").append(lyricsId).append("\n");
    sb.append("  trackSpotifyId: ").append(trackSpotifyId).append("\n");
    sb.append("  hasLyrics: ").append(hasLyrics).append("\n");
    sb.append("  artistId: ").append(artistId).append("\n");
    sb.append("  albumId: ").append(albumId).append("\n");
    sb.append("  artistMbid: ").append(artistMbid).append("\n");
    sb.append("  secondaryGenres: ").append(secondaryGenres).append("\n");
    sb.append("  commontrackVanityId: ").append(commontrackVanityId).append("\n");
    sb.append("  trackId: ").append(trackId).append("\n");
    sb.append("  trackXboxmusicId: ").append(trackXboxmusicId).append("\n");
    sb.append("  primaryGenres: ").append(primaryGenres).append("\n");
    sb.append("  trackLength: ").append(trackLength).append("\n");
    sb.append("  trackMbid: ").append(trackMbid).append("\n");
    sb.append("  commontrackId: ").append(commontrackId).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
