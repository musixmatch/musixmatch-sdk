/**
 * Musixmatch API
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop 
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.swagger.client.model;

import io.swagger.client.model.AlbumPrimaryGenres;
import io.swagger.client.model.ArtistSecondaryGenres;
import java.math.BigDecimal;

import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


/**
 * a album of songs in the Musixmatch database.
 **/
@ApiModel(description = "a album of songs in the Musixmatch database.")
public class Album  {
  
  @SerializedName("album_coverart_500x500")
  private String albumCoverart500x500 = null;
  @SerializedName("restricted")
  private BigDecimal restricted = null;
  @SerializedName("artist_id")
  private BigDecimal artistId = null;
  @SerializedName("album_name")
  private String albumName = null;
  @SerializedName("album_coverart_800x800")
  private String albumCoverart800x800 = null;
  @SerializedName("album_copyright")
  private String albumCopyright = null;
  @SerializedName("album_coverart_350x350")
  private String albumCoverart350x350 = null;
  @SerializedName("artist_name")
  private String artistName = null;
  @SerializedName("primary_genres")
  private AlbumPrimaryGenres primaryGenres = null;
  @SerializedName("album_id")
  private BigDecimal albumId = null;
  @SerializedName("album_rating")
  private BigDecimal albumRating = null;
  @SerializedName("album_pline")
  private String albumPline = null;
  @SerializedName("album_track_count")
  private BigDecimal albumTrackCount = null;
  @SerializedName("album_release_type")
  private String albumReleaseType = null;
  @SerializedName("album_release_date")
  private String albumReleaseDate = null;
  @SerializedName("album_edit_url")
  private String albumEditUrl = null;
  @SerializedName("updated_time")
  private String updatedTime = null;
  @SerializedName("secondary_genres")
  private ArtistSecondaryGenres secondaryGenres = null;
  @SerializedName("album_mbid")
  private String albumMbid = null;
  @SerializedName("album_vanity_id")
  private String albumVanityId = null;
  @SerializedName("album_coverart_100x100")
  private String albumCoverart100x100 = null;
  @SerializedName("album_label")
  private String albumLabel = null;

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCoverart500x500() {
    return albumCoverart500x500;
  }
  public void setAlbumCoverart500x500(String albumCoverart500x500) {
    this.albumCoverart500x500 = albumCoverart500x500;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getRestricted() {
    return restricted;
  }
  public void setRestricted(BigDecimal restricted) {
    this.restricted = restricted;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getArtistId() {
    return artistId;
  }
  public void setArtistId(BigDecimal artistId) {
    this.artistId = artistId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumName() {
    return albumName;
  }
  public void setAlbumName(String albumName) {
    this.albumName = albumName;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCoverart800x800() {
    return albumCoverart800x800;
  }
  public void setAlbumCoverart800x800(String albumCoverart800x800) {
    this.albumCoverart800x800 = albumCoverart800x800;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCopyright() {
    return albumCopyright;
  }
  public void setAlbumCopyright(String albumCopyright) {
    this.albumCopyright = albumCopyright;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCoverart350x350() {
    return albumCoverart350x350;
  }
  public void setAlbumCoverart350x350(String albumCoverart350x350) {
    this.albumCoverart350x350 = albumCoverart350x350;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getArtistName() {
    return artistName;
  }
  public void setArtistName(String artistName) {
    this.artistName = artistName;
  }

  /**
   **/
  @ApiModelProperty(value = "")
  public AlbumPrimaryGenres getPrimaryGenres() {
    return primaryGenres;
  }
  public void setPrimaryGenres(AlbumPrimaryGenres primaryGenres) {
    this.primaryGenres = primaryGenres;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getAlbumId() {
    return albumId;
  }
  public void setAlbumId(BigDecimal albumId) {
    this.albumId = albumId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getAlbumRating() {
    return albumRating;
  }
  public void setAlbumRating(BigDecimal albumRating) {
    this.albumRating = albumRating;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumPline() {
    return albumPline;
  }
  public void setAlbumPline(String albumPline) {
    this.albumPline = albumPline;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public BigDecimal getAlbumTrackCount() {
    return albumTrackCount;
  }
  public void setAlbumTrackCount(BigDecimal albumTrackCount) {
    this.albumTrackCount = albumTrackCount;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumReleaseType() {
    return albumReleaseType;
  }
  public void setAlbumReleaseType(String albumReleaseType) {
    this.albumReleaseType = albumReleaseType;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumReleaseDate() {
    return albumReleaseDate;
  }
  public void setAlbumReleaseDate(String albumReleaseDate) {
    this.albumReleaseDate = albumReleaseDate;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumEditUrl() {
    return albumEditUrl;
  }
  public void setAlbumEditUrl(String albumEditUrl) {
    this.albumEditUrl = albumEditUrl;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getUpdatedTime() {
    return updatedTime;
  }
  public void setUpdatedTime(String updatedTime) {
    this.updatedTime = updatedTime;
  }

  /**
   **/
  @ApiModelProperty(value = "")
  public ArtistSecondaryGenres getSecondaryGenres() {
    return secondaryGenres;
  }
  public void setSecondaryGenres(ArtistSecondaryGenres secondaryGenres) {
    this.secondaryGenres = secondaryGenres;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumMbid() {
    return albumMbid;
  }
  public void setAlbumMbid(String albumMbid) {
    this.albumMbid = albumMbid;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumVanityId() {
    return albumVanityId;
  }
  public void setAlbumVanityId(String albumVanityId) {
    this.albumVanityId = albumVanityId;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumCoverart100x100() {
    return albumCoverart100x100;
  }
  public void setAlbumCoverart100x100(String albumCoverart100x100) {
    this.albumCoverart100x100 = albumCoverart100x100;
  }

  /**
   * 
   **/
  @ApiModelProperty(value = "")
  public String getAlbumLabel() {
    return albumLabel;
  }
  public void setAlbumLabel(String albumLabel) {
    this.albumLabel = albumLabel;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Album album = (Album) o;
    return (albumCoverart500x500 == null ? album.albumCoverart500x500 == null : albumCoverart500x500.equals(album.albumCoverart500x500)) &&
        (restricted == null ? album.restricted == null : restricted.equals(album.restricted)) &&
        (artistId == null ? album.artistId == null : artistId.equals(album.artistId)) &&
        (albumName == null ? album.albumName == null : albumName.equals(album.albumName)) &&
        (albumCoverart800x800 == null ? album.albumCoverart800x800 == null : albumCoverart800x800.equals(album.albumCoverart800x800)) &&
        (albumCopyright == null ? album.albumCopyright == null : albumCopyright.equals(album.albumCopyright)) &&
        (albumCoverart350x350 == null ? album.albumCoverart350x350 == null : albumCoverart350x350.equals(album.albumCoverart350x350)) &&
        (artistName == null ? album.artistName == null : artistName.equals(album.artistName)) &&
        (primaryGenres == null ? album.primaryGenres == null : primaryGenres.equals(album.primaryGenres)) &&
        (albumId == null ? album.albumId == null : albumId.equals(album.albumId)) &&
        (albumRating == null ? album.albumRating == null : albumRating.equals(album.albumRating)) &&
        (albumPline == null ? album.albumPline == null : albumPline.equals(album.albumPline)) &&
        (albumTrackCount == null ? album.albumTrackCount == null : albumTrackCount.equals(album.albumTrackCount)) &&
        (albumReleaseType == null ? album.albumReleaseType == null : albumReleaseType.equals(album.albumReleaseType)) &&
        (albumReleaseDate == null ? album.albumReleaseDate == null : albumReleaseDate.equals(album.albumReleaseDate)) &&
        (albumEditUrl == null ? album.albumEditUrl == null : albumEditUrl.equals(album.albumEditUrl)) &&
        (updatedTime == null ? album.updatedTime == null : updatedTime.equals(album.updatedTime)) &&
        (secondaryGenres == null ? album.secondaryGenres == null : secondaryGenres.equals(album.secondaryGenres)) &&
        (albumMbid == null ? album.albumMbid == null : albumMbid.equals(album.albumMbid)) &&
        (albumVanityId == null ? album.albumVanityId == null : albumVanityId.equals(album.albumVanityId)) &&
        (albumCoverart100x100 == null ? album.albumCoverart100x100 == null : albumCoverart100x100.equals(album.albumCoverart100x100)) &&
        (albumLabel == null ? album.albumLabel == null : albumLabel.equals(album.albumLabel));
  }

  @Override
  public int hashCode() {
    int result = 17;
    result = 31 * result + (albumCoverart500x500 == null ? 0: albumCoverart500x500.hashCode());
    result = 31 * result + (restricted == null ? 0: restricted.hashCode());
    result = 31 * result + (artistId == null ? 0: artistId.hashCode());
    result = 31 * result + (albumName == null ? 0: albumName.hashCode());
    result = 31 * result + (albumCoverart800x800 == null ? 0: albumCoverart800x800.hashCode());
    result = 31 * result + (albumCopyright == null ? 0: albumCopyright.hashCode());
    result = 31 * result + (albumCoverart350x350 == null ? 0: albumCoverart350x350.hashCode());
    result = 31 * result + (artistName == null ? 0: artistName.hashCode());
    result = 31 * result + (primaryGenres == null ? 0: primaryGenres.hashCode());
    result = 31 * result + (albumId == null ? 0: albumId.hashCode());
    result = 31 * result + (albumRating == null ? 0: albumRating.hashCode());
    result = 31 * result + (albumPline == null ? 0: albumPline.hashCode());
    result = 31 * result + (albumTrackCount == null ? 0: albumTrackCount.hashCode());
    result = 31 * result + (albumReleaseType == null ? 0: albumReleaseType.hashCode());
    result = 31 * result + (albumReleaseDate == null ? 0: albumReleaseDate.hashCode());
    result = 31 * result + (albumEditUrl == null ? 0: albumEditUrl.hashCode());
    result = 31 * result + (updatedTime == null ? 0: updatedTime.hashCode());
    result = 31 * result + (secondaryGenres == null ? 0: secondaryGenres.hashCode());
    result = 31 * result + (albumMbid == null ? 0: albumMbid.hashCode());
    result = 31 * result + (albumVanityId == null ? 0: albumVanityId.hashCode());
    result = 31 * result + (albumCoverart100x100 == null ? 0: albumCoverart100x100.hashCode());
    result = 31 * result + (albumLabel == null ? 0: albumLabel.hashCode());
    return result;
  }

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Album {\n");
    
    sb.append("  albumCoverart500x500: ").append(albumCoverart500x500).append("\n");
    sb.append("  restricted: ").append(restricted).append("\n");
    sb.append("  artistId: ").append(artistId).append("\n");
    sb.append("  albumName: ").append(albumName).append("\n");
    sb.append("  albumCoverart800x800: ").append(albumCoverart800x800).append("\n");
    sb.append("  albumCopyright: ").append(albumCopyright).append("\n");
    sb.append("  albumCoverart350x350: ").append(albumCoverart350x350).append("\n");
    sb.append("  artistName: ").append(artistName).append("\n");
    sb.append("  primaryGenres: ").append(primaryGenres).append("\n");
    sb.append("  albumId: ").append(albumId).append("\n");
    sb.append("  albumRating: ").append(albumRating).append("\n");
    sb.append("  albumPline: ").append(albumPline).append("\n");
    sb.append("  albumTrackCount: ").append(albumTrackCount).append("\n");
    sb.append("  albumReleaseType: ").append(albumReleaseType).append("\n");
    sb.append("  albumReleaseDate: ").append(albumReleaseDate).append("\n");
    sb.append("  albumEditUrl: ").append(albumEditUrl).append("\n");
    sb.append("  updatedTime: ").append(updatedTime).append("\n");
    sb.append("  secondaryGenres: ").append(secondaryGenres).append("\n");
    sb.append("  albumMbid: ").append(albumMbid).append("\n");
    sb.append("  albumVanityId: ").append(albumVanityId).append("\n");
    sb.append("  albumCoverart100x100: ").append(albumCoverart100x100).append("\n");
    sb.append("  albumLabel: ").append(albumLabel).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
