# swagger-android-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-android-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-android-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-android-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.api.AlbumApi;

public class AlbumApiExample {

    public static void main(String[] args) {
        AlbumApi apiInstance = new AlbumApi();
        String albumId = "albumId_example"; // String | The musiXmatch album id
        String format = "json"; // String | output format: json, jsonp, xml.
        String callback = "callback_example"; // String | jsonp callback
        try {
            InlineResponse200 result = apiInstance.albumGetGet(albumId, format, callback);
            System.out.println(result);
        } catch (ApiException e) {
            System.err.println("Exception when calling AlbumApi#albumGetGet");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AlbumApi* | [**albumGetGet**](docs/AlbumApi.md#albumGetGet) | **GET** /album.get | 
*AlbumApi* | [**artistAlbumsGetGet**](docs/AlbumApi.md#artistAlbumsGetGet) | **GET** /artist.albums.get | 
*ArtistApi* | [**artistGetGet**](docs/ArtistApi.md#artistGetGet) | **GET** /artist.get | 
*ArtistApi* | [**artistRelatedGetGet**](docs/ArtistApi.md#artistRelatedGetGet) | **GET** /artist.related.get | 
*ArtistApi* | [**artistSearchGet**](docs/ArtistApi.md#artistSearchGet) | **GET** /artist.search | 
*ArtistApi* | [**chartArtistsGetGet**](docs/ArtistApi.md#chartArtistsGetGet) | **GET** /chart.artists.get | 
*LyricsApi* | [**matcherLyricsGetGet**](docs/LyricsApi.md#matcherLyricsGetGet) | **GET** /matcher.lyrics.get | 
*LyricsApi* | [**trackLyricsGetGet**](docs/LyricsApi.md#trackLyricsGetGet) | **GET** /track.lyrics.get | 
*SnippetApi* | [**trackSnippetGetGet**](docs/SnippetApi.md#trackSnippetGetGet) | **GET** /track.snippet.get | 
*SubtitleApi* | [**matcherSubtitleGetGet**](docs/SubtitleApi.md#matcherSubtitleGetGet) | **GET** /matcher.subtitle.get | 
*SubtitleApi* | [**trackSubtitleGetGet**](docs/SubtitleApi.md#trackSubtitleGetGet) | **GET** /track.subtitle.get | 
*TrackApi* | [**albumTracksGetGet**](docs/TrackApi.md#albumTracksGetGet) | **GET** /album.tracks.get | 
*TrackApi* | [**chartTracksGetGet**](docs/TrackApi.md#chartTracksGetGet) | **GET** /chart.tracks.get | 
*TrackApi* | [**matcherTrackGetGet**](docs/TrackApi.md#matcherTrackGetGet) | **GET** /matcher.track.get | 
*TrackApi* | [**trackGetGet**](docs/TrackApi.md#trackGetGet) | **GET** /track.get | 
*TrackApi* | [**trackSearchGet**](docs/TrackApi.md#trackSearchGet) | **GET** /track.search | 


## Documentation for Models

 - [Album](docs/Album.md)
 - [AlbumPrimaryGenres](docs/AlbumPrimaryGenres.md)
 - [AlbumPrimaryGenresMusicGenre](docs/AlbumPrimaryGenresMusicGenre.md)
 - [AlbumPrimaryGenresMusicGenreList](docs/AlbumPrimaryGenresMusicGenreList.md)
 - [Artist](docs/Artist.md)
 - [ArtistArtistAliasList](docs/ArtistArtistAliasList.md)
 - [ArtistArtistCredits](docs/ArtistArtistCredits.md)
 - [ArtistArtistNameTranslation](docs/ArtistArtistNameTranslation.md)
 - [ArtistArtistNameTranslationList](docs/ArtistArtistNameTranslationList.md)
 - [ArtistPrimaryGenres](docs/ArtistPrimaryGenres.md)
 - [ArtistPrimaryGenresMusicGenre](docs/ArtistPrimaryGenresMusicGenre.md)
 - [ArtistPrimaryGenresMusicGenreList](docs/ArtistPrimaryGenresMusicGenreList.md)
 - [ArtistSecondaryGenres](docs/ArtistSecondaryGenres.md)
 - [InlineResponse200](docs/InlineResponse200.md)
 - [InlineResponse2001](docs/InlineResponse2001.md)
 - [InlineResponse20010](docs/InlineResponse20010.md)
 - [InlineResponse20010Message](docs/InlineResponse20010Message.md)
 - [InlineResponse20010MessageBody](docs/InlineResponse20010MessageBody.md)
 - [InlineResponse2001Message](docs/InlineResponse2001Message.md)
 - [InlineResponse2001MessageBody](docs/InlineResponse2001MessageBody.md)
 - [InlineResponse2001MessageHeader](docs/InlineResponse2001MessageHeader.md)
 - [InlineResponse2002](docs/InlineResponse2002.md)
 - [InlineResponse2002Message](docs/InlineResponse2002Message.md)
 - [InlineResponse2002MessageBody](docs/InlineResponse2002MessageBody.md)
 - [InlineResponse2002MessageHeader](docs/InlineResponse2002MessageHeader.md)
 - [InlineResponse2003](docs/InlineResponse2003.md)
 - [InlineResponse2003Message](docs/InlineResponse2003Message.md)
 - [InlineResponse2003MessageBody](docs/InlineResponse2003MessageBody.md)
 - [InlineResponse2004](docs/InlineResponse2004.md)
 - [InlineResponse2004Message](docs/InlineResponse2004Message.md)
 - [InlineResponse2004MessageBody](docs/InlineResponse2004MessageBody.md)
 - [InlineResponse2005](docs/InlineResponse2005.md)
 - [InlineResponse2005Message](docs/InlineResponse2005Message.md)
 - [InlineResponse2005MessageHeader](docs/InlineResponse2005MessageHeader.md)
 - [InlineResponse2006](docs/InlineResponse2006.md)
 - [InlineResponse2006Message](docs/InlineResponse2006Message.md)
 - [InlineResponse2006MessageBody](docs/InlineResponse2006MessageBody.md)
 - [InlineResponse2006MessageBodyTrackList](docs/InlineResponse2006MessageBodyTrackList.md)
 - [InlineResponse2007](docs/InlineResponse2007.md)
 - [InlineResponse2007Message](docs/InlineResponse2007Message.md)
 - [InlineResponse2007MessageBody](docs/InlineResponse2007MessageBody.md)
 - [InlineResponse2008](docs/InlineResponse2008.md)
 - [InlineResponse2008Message](docs/InlineResponse2008Message.md)
 - [InlineResponse2008MessageBody](docs/InlineResponse2008MessageBody.md)
 - [InlineResponse2009](docs/InlineResponse2009.md)
 - [InlineResponse2009Message](docs/InlineResponse2009Message.md)
 - [InlineResponse200Message](docs/InlineResponse200Message.md)
 - [InlineResponse200MessageBody](docs/InlineResponse200MessageBody.md)
 - [InlineResponse200MessageHeader](docs/InlineResponse200MessageHeader.md)
 - [Lyrics](docs/Lyrics.md)
 - [Snippet](docs/Snippet.md)
 - [Subtitle](docs/Subtitle.md)
 - [Track](docs/Track.md)
 - [TrackPrimaryGenres](docs/TrackPrimaryGenres.md)
 - [TrackPrimaryGenresMusicGenre](docs/TrackPrimaryGenresMusicGenre.md)
 - [TrackPrimaryGenresMusicGenreList](docs/TrackPrimaryGenresMusicGenreList.md)
 - [TrackSecondaryGenres](docs/TrackSecondaryGenres.md)
 - [TrackSecondaryGenresMusicGenre](docs/TrackSecondaryGenresMusicGenre.md)
 - [TrackSecondaryGenresMusicGenreList](docs/TrackSecondaryGenresMusicGenreList.md)


## Documentation for Authorization

Authentication schemes defined for the API:
### key

- **Type**: API key
- **API key parameter name**: apikey
- **Location**: URL query string


## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issue.

## Author

info@musixmatch.com

