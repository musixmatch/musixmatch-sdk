
# InlineResponse200Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  |  [optional]
**body** | [**InlineResponse200MessageBody**](InlineResponse200MessageBody.md) |  |  [optional]



