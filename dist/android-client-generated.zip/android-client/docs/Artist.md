
# Artist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistCredits** | [**ArtistArtistCredits**](ArtistArtistCredits.md) |  |  [optional]
**artistMbid** | **String** |  |  [optional]
**artistName** | **String** |  |  [optional]
**secondaryGenres** | [**ArtistSecondaryGenres**](ArtistSecondaryGenres.md) |  |  [optional]
**artistAliasList** | [**List&lt;ArtistArtistAliasList&gt;**](ArtistArtistAliasList.md) |  |  [optional]
**artistVanityId** | **String** |  |  [optional]
**restricted** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**artistCountry** | **String** |  |  [optional]
**artistComment** | **String** |  |  [optional]
**artistNameTranslationList** | [**List&lt;ArtistArtistNameTranslationList&gt;**](ArtistArtistNameTranslationList.md) |  |  [optional]
**artistEditUrl** | **String** |  |  [optional]
**artistShareUrl** | **String** |  |  [optional]
**artistId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**updatedTime** | **String** |  |  [optional]
**managed** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**primaryGenres** | [**ArtistPrimaryGenres**](ArtistPrimaryGenres.md) |  |  [optional]
**artistTwitterUrl** | **String** |  |  [optional]
**artistRating** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



