
# TrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**List&lt;TrackPrimaryGenresMusicGenreList&gt;**](TrackPrimaryGenresMusicGenreList.md) |  |  [optional]



