# TrackApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**albumTracksGetGet**](TrackApi.md#albumTracksGetGet) | **GET** /album.tracks.get | 
[**chartTracksGetGet**](TrackApi.md#chartTracksGetGet) | **GET** /chart.tracks.get | 
[**matcherTrackGetGet**](TrackApi.md#matcherTrackGetGet) | **GET** /matcher.track.get | 
[**trackGetGet**](TrackApi.md#trackGetGet) | **GET** /track.get | 
[**trackSearchGet**](TrackApi.md#trackSearchGet) | **GET** /track.search | 


<a name="albumTracksGetGet"></a>
# **albumTracksGetGet**
> InlineResponse2001 albumTracksGetGet(albumId, format, callback, fHasLyrics, page, pageSize)





### Example
```java
// Import classes:
//import io.swagger.client.api.TrackApi;

TrackApi apiInstance = new TrackApi();
String albumId = "albumId_example"; // String | The musiXmatch album id
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
String fHasLyrics = "fHasLyrics_example"; // String | When set, filter only contents with lyrics
BigDecimal page = new BigDecimal(); // BigDecimal | Define the page number for paginated results
BigDecimal pageSize = new BigDecimal(); // BigDecimal | Define the page size for paginated results.Range is 1 to 100.
try {
    InlineResponse2001 result = apiInstance.albumTracksGetGet(albumId, format, callback, fHasLyrics, page, pageSize);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TrackApi#albumTracksGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **albumId** | **String**| The musiXmatch album id |
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **fHasLyrics** | **String**| When set, filter only contents with lyrics | [optional]
 **page** | **BigDecimal**| Define the page number for paginated results | [optional]
 **pageSize** | **BigDecimal**| Define the page size for paginated results.Range is 1 to 100. | [optional]

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="chartTracksGetGet"></a>
# **chartTracksGetGet**
> InlineResponse2006 chartTracksGetGet(format, callback, page, pageSize, country, fHasLyrics)





### Example
```java
// Import classes:
//import io.swagger.client.api.TrackApi;

TrackApi apiInstance = new TrackApi();
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
BigDecimal page = new BigDecimal(); // BigDecimal | Define the page number for paginated results
BigDecimal pageSize = new BigDecimal(); // BigDecimal | Define the page size for paginated results.Range is 1 to 100.
String country = "us"; // String | A valid ISO 3166 country code
String fHasLyrics = "fHasLyrics_example"; // String | When set, filter only contents with lyrics
try {
    InlineResponse2006 result = apiInstance.chartTracksGetGet(format, callback, page, pageSize, country, fHasLyrics);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TrackApi#chartTracksGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **page** | **BigDecimal**| Define the page number for paginated results | [optional]
 **pageSize** | **BigDecimal**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **country** | **String**| A valid ISO 3166 country code | [optional] [default to us]
 **fHasLyrics** | **String**| When set, filter only contents with lyrics | [optional]

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="matcherTrackGetGet"></a>
# **matcherTrackGetGet**
> InlineResponse2009 matcherTrackGetGet(format, callback, qArtist, qTrack, fHasLyrics, fHasSubtitle)





### Example
```java
// Import classes:
//import io.swagger.client.api.TrackApi;

TrackApi apiInstance = new TrackApi();
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
String qArtist = "qArtist_example"; // String | The song artist
String qTrack = "qTrack_example"; // String | The song title
BigDecimal fHasLyrics = new BigDecimal(); // BigDecimal | When set, filter only contents with lyrics
BigDecimal fHasSubtitle = new BigDecimal(); // BigDecimal | When set, filter only contents with subtitles
try {
    InlineResponse2009 result = apiInstance.matcherTrackGetGet(format, callback, qArtist, qTrack, fHasLyrics, fHasSubtitle);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TrackApi#matcherTrackGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **qArtist** | **String**| The song artist | [optional]
 **qTrack** | **String**| The song title | [optional]
 **fHasLyrics** | **BigDecimal**| When set, filter only contents with lyrics | [optional]
 **fHasSubtitle** | **BigDecimal**| When set, filter only contents with subtitles | [optional]

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="trackGetGet"></a>
# **trackGetGet**
> InlineResponse2009 trackGetGet(trackId, format, callback)





### Example
```java
// Import classes:
//import io.swagger.client.api.TrackApi;

TrackApi apiInstance = new TrackApi();
String trackId = "trackId_example"; // String | The musiXmatch track id
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
try {
    InlineResponse2009 result = apiInstance.trackGetGet(trackId, format, callback);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TrackApi#trackGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trackId** | **String**| The musiXmatch track id |
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="trackSearchGet"></a>
# **trackSearchGet**
> InlineResponse2006 trackSearchGet(format, callback, qTrack, qArtist, qLyrics, fArtistId, fMusicGenreId, fLyricsLanguage, fHasLyrics, sArtistRating, sTrackRating, quorumFactor, pageSize, page)





### Example
```java
// Import classes:
//import io.swagger.client.api.TrackApi;

TrackApi apiInstance = new TrackApi();
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
String qTrack = "qTrack_example"; // String | The song title
String qArtist = "qArtist_example"; // String | The song artist
String qLyrics = "qLyrics_example"; // String | Any word in the lyrics
BigDecimal fArtistId = new BigDecimal(); // BigDecimal | When set, filter by this artist id
BigDecimal fMusicGenreId = new BigDecimal(); // BigDecimal | When set, filter by this music category id
BigDecimal fLyricsLanguage = new BigDecimal(); // BigDecimal | Filter by the lyrics language (en,it,..)
BigDecimal fHasLyrics = new BigDecimal(); // BigDecimal | When set, filter only contents with lyrics
String sArtistRating = "sArtistRating_example"; // String | Sort by our popularity index for artists (asc|desc)
String sTrackRating = "sTrackRating_example"; // String | Sort by our popularity index for tracks (asc|desc)
BigDecimal quorumFactor = new BigDecimal(); // BigDecimal | Search only a part of the given query string.Allowed range is (0.1 – 0.9)
BigDecimal pageSize = new BigDecimal(); // BigDecimal | Define the page size for paginated results.Range is 1 to 100.
BigDecimal page = new BigDecimal(); // BigDecimal | Define the page number for paginated results
try {
    InlineResponse2006 result = apiInstance.trackSearchGet(format, callback, qTrack, qArtist, qLyrics, fArtistId, fMusicGenreId, fLyricsLanguage, fHasLyrics, sArtistRating, sTrackRating, quorumFactor, pageSize, page);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TrackApi#trackSearchGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **qTrack** | **String**| The song title | [optional]
 **qArtist** | **String**| The song artist | [optional]
 **qLyrics** | **String**| Any word in the lyrics | [optional]
 **fArtistId** | **BigDecimal**| When set, filter by this artist id | [optional]
 **fMusicGenreId** | **BigDecimal**| When set, filter by this music category id | [optional]
 **fLyricsLanguage** | **BigDecimal**| Filter by the lyrics language (en,it,..) | [optional]
 **fHasLyrics** | **BigDecimal**| When set, filter only contents with lyrics | [optional]
 **sArtistRating** | **String**| Sort by our popularity index for artists (asc|desc) | [optional]
 **sTrackRating** | **String**| Sort by our popularity index for tracks (asc|desc) | [optional]
 **quorumFactor** | **BigDecimal**| Search only a part of the given query string.Allowed range is (0.1 – 0.9) | [optional] [default to 1]
 **pageSize** | **BigDecimal**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **page** | **BigDecimal**| Define the page number for paginated results | [optional]

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

