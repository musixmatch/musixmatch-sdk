
# Album

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**albumCoverart500x500** | **String** |  |  [optional]
**restricted** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**artistId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**albumName** | **String** |  |  [optional]
**albumCoverart800x800** | **String** |  |  [optional]
**albumCopyright** | **String** |  |  [optional]
**albumCoverart350x350** | **String** |  |  [optional]
**artistName** | **String** |  |  [optional]
**primaryGenres** | [**AlbumPrimaryGenres**](AlbumPrimaryGenres.md) |  |  [optional]
**albumId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**albumRating** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**albumPline** | **String** |  |  [optional]
**albumTrackCount** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**albumReleaseType** | **String** |  |  [optional]
**albumReleaseDate** | **String** |  |  [optional]
**albumEditUrl** | **String** |  |  [optional]
**updatedTime** | **String** |  |  [optional]
**secondaryGenres** | [**ArtistSecondaryGenres**](ArtistSecondaryGenres.md) |  |  [optional]
**albumMbid** | **String** |  |  [optional]
**albumVanityId** | **String** |  |  [optional]
**albumCoverart100x100** | **String** |  |  [optional]
**albumLabel** | **String** |  |  [optional]



