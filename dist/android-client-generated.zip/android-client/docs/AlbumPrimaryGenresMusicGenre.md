
# AlbumPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreNameExtended** | **String** |  |  [optional]
**musicGenreVanity** | **String** |  |  [optional]
**musicGenreParentId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**musicGenreId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**musicGenreName** | **String** |  |  [optional]



