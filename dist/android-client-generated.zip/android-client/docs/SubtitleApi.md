# SubtitleApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**matcherSubtitleGetGet**](SubtitleApi.md#matcherSubtitleGetGet) | **GET** /matcher.subtitle.get | 
[**trackSubtitleGetGet**](SubtitleApi.md#trackSubtitleGetGet) | **GET** /track.subtitle.get | 


<a name="matcherSubtitleGetGet"></a>
# **matcherSubtitleGetGet**
> InlineResponse2008 matcherSubtitleGetGet(format, callback, qTrack, qArtist, fSubtitleLength, fSubtitleLengthMaxDeviation)





### Example
```java
// Import classes:
//import io.swagger.client.api.SubtitleApi;

SubtitleApi apiInstance = new SubtitleApi();
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
String qTrack = "qTrack_example"; // String | The song title
String qArtist = "qArtist_example"; // String |  The song artist
BigDecimal fSubtitleLength = new BigDecimal(); // BigDecimal | Filter by subtitle length in seconds
BigDecimal fSubtitleLengthMaxDeviation = new BigDecimal(); // BigDecimal | Max deviation for a subtitle length in seconds
try {
    InlineResponse2008 result = apiInstance.matcherSubtitleGetGet(format, callback, qTrack, qArtist, fSubtitleLength, fSubtitleLengthMaxDeviation);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SubtitleApi#matcherSubtitleGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **qTrack** | **String**| The song title | [optional]
 **qArtist** | **String**|  The song artist | [optional]
 **fSubtitleLength** | **BigDecimal**| Filter by subtitle length in seconds | [optional]
 **fSubtitleLengthMaxDeviation** | **BigDecimal**| Max deviation for a subtitle length in seconds | [optional]

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="trackSubtitleGetGet"></a>
# **trackSubtitleGetGet**
> InlineResponse2008 trackSubtitleGetGet(trackId, format, callback)





### Example
```java
// Import classes:
//import io.swagger.client.api.SubtitleApi;

SubtitleApi apiInstance = new SubtitleApi();
String trackId = "trackId_example"; // String | The musiXmatch track id
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
try {
    InlineResponse2008 result = apiInstance.trackSubtitleGetGet(trackId, format, callback);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling SubtitleApi#trackSubtitleGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trackId** | **String**| The musiXmatch track id |
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

