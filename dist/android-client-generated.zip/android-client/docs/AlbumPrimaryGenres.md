
# AlbumPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**List&lt;AlbumPrimaryGenresMusicGenreList&gt;**](AlbumPrimaryGenresMusicGenreList.md) |  |  [optional]



