
# InlineResponse2003Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  |  [optional]
**body** | [**InlineResponse2003MessageBody**](InlineResponse2003MessageBody.md) |  |  [optional]



