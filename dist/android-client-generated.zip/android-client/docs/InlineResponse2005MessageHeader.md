
# InlineResponse2005MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**statusCode** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**executeTime** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



