
# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2004Message**](InlineResponse2004Message.md) |  |  [optional]



