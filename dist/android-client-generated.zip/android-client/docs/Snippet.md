
# Snippet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**htmlTrackingUrl** | **String** |  |  [optional]
**instrumental** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**restricted** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**updatedTime** | **String** |  |  [optional]
**snippetBody** | **String** |  |  [optional]
**pixelTrackingUrl** | **String** |  |  [optional]
**snippetId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**scriptTrackingUrl** | **String** |  |  [optional]
**snippetLanguage** | **String** |  |  [optional]



