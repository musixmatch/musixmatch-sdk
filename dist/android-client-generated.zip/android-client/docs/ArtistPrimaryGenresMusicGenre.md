
# ArtistPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreParentId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**musicGenreName** | **String** |  |  [optional]
**musicGenreVanity** | **String** |  |  [optional]
**musicGenreId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**musicGenreNameExtended** | **String** |  |  [optional]



