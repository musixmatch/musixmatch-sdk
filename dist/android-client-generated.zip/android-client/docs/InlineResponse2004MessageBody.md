
# InlineResponse2004MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | [**List&lt;InlineResponse2003MessageBody&gt;**](InlineResponse2003MessageBody.md) | A list of artists |  [optional]



