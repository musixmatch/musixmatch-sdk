
# ArtistArtistAliasList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistAlias** | **String** |  |  [optional]



