
# ArtistPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**List&lt;ArtistPrimaryGenresMusicGenreList&gt;**](ArtistPrimaryGenresMusicGenreList.md) |  |  [optional]



