# Swagger\Client\LyricsApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**matcherLyricsGetGet**](LyricsApi.md#matcherLyricsGetGet) | **GET** /matcher.lyrics.get | 
[**trackLyricsGetGet**](LyricsApi.md#trackLyricsGetGet) | **GET** /track.lyrics.get | 


# **matcherLyricsGetGet**
> \Swagger\Client\Model\InlineResponse2007 matcherLyricsGetGet($format, $callback, $q_track, $q_artist)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\LyricsApi();
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$q_track = "q_track_example"; // string | The song title
$q_artist = "q_artist_example"; // string | The song artist

try {
    $result = $api_instance->matcherLyricsGetGet($format, $callback, $q_track, $q_artist);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling LyricsApi->matcherLyricsGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **q_track** | **string**| The song title | [optional]
 **q_artist** | **string**| The song artist | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2007**](../Model/InlineResponse2007.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **trackLyricsGetGet**
> \Swagger\Client\Model\InlineResponse2007 trackLyricsGetGet($track_id, $format, $callback)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\LyricsApi();
$track_id = "track_id_example"; // string | The musiXmatch track id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback

try {
    $result = $api_instance->trackLyricsGetGet($track_id, $format, $callback);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling LyricsApi->trackLyricsGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **string**| The musiXmatch track id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2007**](../Model/InlineResponse2007.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

