# Swagger\Client\TrackApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**albumTracksGetGet**](TrackApi.md#albumTracksGetGet) | **GET** /album.tracks.get | 
[**chartTracksGetGet**](TrackApi.md#chartTracksGetGet) | **GET** /chart.tracks.get | 
[**matcherTrackGetGet**](TrackApi.md#matcherTrackGetGet) | **GET** /matcher.track.get | 
[**trackGetGet**](TrackApi.md#trackGetGet) | **GET** /track.get | 
[**trackSearchGet**](TrackApi.md#trackSearchGet) | **GET** /track.search | 


# **albumTracksGetGet**
> \Swagger\Client\Model\InlineResponse2001 albumTracksGetGet($album_id, $format, $callback, $f_has_lyrics, $page, $page_size)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\TrackApi();
$album_id = "album_id_example"; // string | The musiXmatch album id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$f_has_lyrics = "f_has_lyrics_example"; // string | When set, filter only contents with lyrics
$page = 3.4; // float | Define the page number for paginated results
$page_size = 3.4; // float | Define the page size for paginated results.Range is 1 to 100.

try {
    $result = $api_instance->albumTracksGetGet($album_id, $format, $callback, $f_has_lyrics, $page, $page_size);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TrackApi->albumTracksGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **album_id** | **string**| The musiXmatch album id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **f_has_lyrics** | **string**| When set, filter only contents with lyrics | [optional]
 **page** | **float**| Define the page number for paginated results | [optional]
 **page_size** | **float**| Define the page size for paginated results.Range is 1 to 100. | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2001**](../Model/InlineResponse2001.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **chartTracksGetGet**
> \Swagger\Client\Model\InlineResponse2006 chartTracksGetGet($format, $callback, $page, $page_size, $country, $f_has_lyrics)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\TrackApi();
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$page = 3.4; // float | Define the page number for paginated results
$page_size = 3.4; // float | Define the page size for paginated results.Range is 1 to 100.
$country = "us"; // string | A valid ISO 3166 country code
$f_has_lyrics = "f_has_lyrics_example"; // string | When set, filter only contents with lyrics

try {
    $result = $api_instance->chartTracksGetGet($format, $callback, $page, $page_size, $country, $f_has_lyrics);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TrackApi->chartTracksGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **page** | **float**| Define the page number for paginated results | [optional]
 **page_size** | **float**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **country** | **string**| A valid ISO 3166 country code | [optional] [default to us]
 **f_has_lyrics** | **string**| When set, filter only contents with lyrics | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2006**](../Model/InlineResponse2006.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **matcherTrackGetGet**
> \Swagger\Client\Model\InlineResponse2009 matcherTrackGetGet($format, $callback, $q_artist, $q_track, $f_has_lyrics, $f_has_subtitle)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\TrackApi();
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$q_artist = "q_artist_example"; // string | The song artist
$q_track = "q_track_example"; // string | The song title
$f_has_lyrics = 3.4; // float | When set, filter only contents with lyrics
$f_has_subtitle = 3.4; // float | When set, filter only contents with subtitles

try {
    $result = $api_instance->matcherTrackGetGet($format, $callback, $q_artist, $q_track, $f_has_lyrics, $f_has_subtitle);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TrackApi->matcherTrackGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **q_artist** | **string**| The song artist | [optional]
 **q_track** | **string**| The song title | [optional]
 **f_has_lyrics** | **float**| When set, filter only contents with lyrics | [optional]
 **f_has_subtitle** | **float**| When set, filter only contents with subtitles | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2009**](../Model/InlineResponse2009.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **trackGetGet**
> \Swagger\Client\Model\InlineResponse2009 trackGetGet($track_id, $format, $callback)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\TrackApi();
$track_id = "track_id_example"; // string | The musiXmatch track id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback

try {
    $result = $api_instance->trackGetGet($track_id, $format, $callback);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TrackApi->trackGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **string**| The musiXmatch track id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2009**](../Model/InlineResponse2009.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **trackSearchGet**
> \Swagger\Client\Model\InlineResponse2006 trackSearchGet($format, $callback, $q_track, $q_artist, $q_lyrics, $f_artist_id, $f_music_genre_id, $f_lyrics_language, $f_has_lyrics, $s_artist_rating, $s_track_rating, $quorum_factor, $page_size, $page)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\TrackApi();
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$q_track = "q_track_example"; // string | The song title
$q_artist = "q_artist_example"; // string | The song artist
$q_lyrics = "q_lyrics_example"; // string | Any word in the lyrics
$f_artist_id = 3.4; // float | When set, filter by this artist id
$f_music_genre_id = 3.4; // float | When set, filter by this music category id
$f_lyrics_language = 3.4; // float | Filter by the lyrics language (en,it,..)
$f_has_lyrics = 3.4; // float | When set, filter only contents with lyrics
$s_artist_rating = "s_artist_rating_example"; // string | Sort by our popularity index for artists (asc|desc)
$s_track_rating = "s_track_rating_example"; // string | Sort by our popularity index for tracks (asc|desc)
$quorum_factor = 1; // float | Search only a part of the given query string.Allowed range is (0.1 – 0.9)
$page_size = 3.4; // float | Define the page size for paginated results.Range is 1 to 100.
$page = 3.4; // float | Define the page number for paginated results

try {
    $result = $api_instance->trackSearchGet($format, $callback, $q_track, $q_artist, $q_lyrics, $f_artist_id, $f_music_genre_id, $f_lyrics_language, $f_has_lyrics, $s_artist_rating, $s_track_rating, $quorum_factor, $page_size, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling TrackApi->trackSearchGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **q_track** | **string**| The song title | [optional]
 **q_artist** | **string**| The song artist | [optional]
 **q_lyrics** | **string**| Any word in the lyrics | [optional]
 **f_artist_id** | **float**| When set, filter by this artist id | [optional]
 **f_music_genre_id** | **float**| When set, filter by this music category id | [optional]
 **f_lyrics_language** | **float**| Filter by the lyrics language (en,it,..) | [optional]
 **f_has_lyrics** | **float**| When set, filter only contents with lyrics | [optional]
 **s_artist_rating** | **string**| Sort by our popularity index for artists (asc|desc) | [optional]
 **s_track_rating** | **string**| Sort by our popularity index for tracks (asc|desc) | [optional]
 **quorum_factor** | **float**| Search only a part of the given query string.Allowed range is (0.1 – 0.9) | [optional] [default to 1]
 **page_size** | **float**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **page** | **float**| Define the page number for paginated results | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2006**](../Model/InlineResponse2006.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

