# Swagger\Client\SubtitleApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**matcherSubtitleGetGet**](SubtitleApi.md#matcherSubtitleGetGet) | **GET** /matcher.subtitle.get | 
[**trackSubtitleGetGet**](SubtitleApi.md#trackSubtitleGetGet) | **GET** /track.subtitle.get | 


# **matcherSubtitleGetGet**
> \Swagger\Client\Model\InlineResponse2008 matcherSubtitleGetGet($format, $callback, $q_track, $q_artist, $f_subtitle_length, $f_subtitle_length_max_deviation)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\SubtitleApi();
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$q_track = "q_track_example"; // string | The song title
$q_artist = "q_artist_example"; // string | The song artist
$f_subtitle_length = 3.4; // float | Filter by subtitle length in seconds
$f_subtitle_length_max_deviation = 3.4; // float | Max deviation for a subtitle length in seconds

try {
    $result = $api_instance->matcherSubtitleGetGet($format, $callback, $q_track, $q_artist, $f_subtitle_length, $f_subtitle_length_max_deviation);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SubtitleApi->matcherSubtitleGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **q_track** | **string**| The song title | [optional]
 **q_artist** | **string**| The song artist | [optional]
 **f_subtitle_length** | **float**| Filter by subtitle length in seconds | [optional]
 **f_subtitle_length_max_deviation** | **float**| Max deviation for a subtitle length in seconds | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2008**](../Model/InlineResponse2008.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **trackSubtitleGetGet**
> \Swagger\Client\Model\InlineResponse2008 trackSubtitleGetGet($track_id, $format, $callback)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\SubtitleApi();
$track_id = "track_id_example"; // string | The musiXmatch track id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback

try {
    $result = $api_instance->trackSubtitleGetGet($track_id, $format, $callback);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SubtitleApi->trackSubtitleGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **string**| The musiXmatch track id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2008**](../Model/InlineResponse2008.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

