# Swagger\Client\ArtistApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**artistGetGet**](ArtistApi.md#artistGetGet) | **GET** /artist.get | 
[**artistRelatedGetGet**](ArtistApi.md#artistRelatedGetGet) | **GET** /artist.related.get | 
[**artistSearchGet**](ArtistApi.md#artistSearchGet) | **GET** /artist.search | 
[**chartArtistsGetGet**](ArtistApi.md#chartArtistsGetGet) | **GET** /chart.artists.get | 


# **artistGetGet**
> \Swagger\Client\Model\InlineResponse2003 artistGetGet($artist_id, $format, $callback)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\ArtistApi();
$artist_id = "artist_id_example"; // string | The musiXmatch artist id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback

try {
    $result = $api_instance->artistGetGet($artist_id, $format, $callback);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArtistApi->artistGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **string**| The musiXmatch artist id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2003**](../Model/InlineResponse2003.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **artistRelatedGetGet**
> \Swagger\Client\Model\InlineResponse2004 artistRelatedGetGet($artist_id, $format, $callback, $page_size, $page)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\ArtistApi();
$artist_id = "artist_id_example"; // string | The musiXmatch artist id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$page_size = 3.4; // float | Define the page size for paginated results.Range is 1 to 100.
$page = 3.4; // float | Define the page number for paginated results

try {
    $result = $api_instance->artistRelatedGetGet($artist_id, $format, $callback, $page_size, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArtistApi->artistRelatedGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **string**| The musiXmatch artist id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **page_size** | **float**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **page** | **float**| Define the page number for paginated results | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2004**](../Model/InlineResponse2004.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **artistSearchGet**
> \Swagger\Client\Model\InlineResponse2004 artistSearchGet($format, $callback, $q_artist, $f_artist_id, $page, $page_size)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\ArtistApi();
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$q_artist = "q_artist_example"; // string | The song artist
$f_artist_id = 3.4; // float | When set, filter by this artist id
$page = 3.4; // float | Define the page number for paginated results
$page_size = 3.4; // float | Define the page size for paginated results.Range is 1 to 100.

try {
    $result = $api_instance->artistSearchGet($format, $callback, $q_artist, $f_artist_id, $page, $page_size);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArtistApi->artistSearchGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **q_artist** | **string**| The song artist | [optional]
 **f_artist_id** | **float**| When set, filter by this artist id | [optional]
 **page** | **float**| Define the page number for paginated results | [optional]
 **page_size** | **float**| Define the page size for paginated results.Range is 1 to 100. | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2004**](../Model/InlineResponse2004.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **chartArtistsGetGet**
> \Swagger\Client\Model\InlineResponse2005 chartArtistsGetGet($format, $callback, $page, $page_size, $country)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\ArtistApi();
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$page = 3.4; // float | Define the page number for paginated results
$page_size = 3.4; // float | Define the page size for paginated results.Range is 1 to 100.
$country = "us"; // string | A valid ISO 3166 country code

try {
    $result = $api_instance->chartArtistsGetGet($format, $callback, $page, $page_size, $country);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ArtistApi->chartArtistsGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **page** | **float**| Define the page number for paginated results | [optional]
 **page_size** | **float**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **country** | **string**| A valid ISO 3166 country code | [optional] [default to us]

### Return type

[**\Swagger\Client\Model\InlineResponse2005**](../Model/InlineResponse2005.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

