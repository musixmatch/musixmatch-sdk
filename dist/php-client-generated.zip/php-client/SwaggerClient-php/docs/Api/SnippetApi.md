# Swagger\Client\SnippetApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**trackSnippetGetGet**](SnippetApi.md#trackSnippetGetGet) | **GET** /track.snippet.get | 


# **trackSnippetGetGet**
> \Swagger\Client\Model\InlineResponse20010 trackSnippetGetGet($track_id, $format, $callback)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\SnippetApi();
$track_id = "track_id_example"; // string | The musiXmatch track id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback

try {
    $result = $api_instance->trackSnippetGetGet($track_id, $format, $callback);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SnippetApi->trackSnippetGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **string**| The musiXmatch track id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse20010**](../Model/InlineResponse20010.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

