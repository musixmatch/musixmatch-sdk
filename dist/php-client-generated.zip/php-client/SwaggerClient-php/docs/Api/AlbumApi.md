# Swagger\Client\AlbumApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**albumGetGet**](AlbumApi.md#albumGetGet) | **GET** /album.get | 
[**artistAlbumsGetGet**](AlbumApi.md#artistAlbumsGetGet) | **GET** /artist.albums.get | 


# **albumGetGet**
> \Swagger\Client\Model\InlineResponse200 albumGetGet($album_id, $format, $callback)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\AlbumApi();
$album_id = "album_id_example"; // string | The musiXmatch album id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback

try {
    $result = $api_instance->albumGetGet($album_id, $format, $callback);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AlbumApi->albumGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **album_id** | **string**| The musiXmatch album id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse200**](../Model/InlineResponse200.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **artistAlbumsGetGet**
> \Swagger\Client\Model\InlineResponse2002 artistAlbumsGetGet($artist_id, $format, $callback, $s_release_date, $g_album_name, $page_size, $page)





### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: key
Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('apikey', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('apikey', 'Bearer');

$api_instance = new Swagger\Client\Api\AlbumApi();
$artist_id = "artist_id_example"; // string | The musiXmatch artist id
$format = "json"; // string | output format: json, jsonp, xml.
$callback = "callback_example"; // string | jsonp callback
$s_release_date = "s_release_date_example"; // string | Sort by release date (asc|desc)
$g_album_name = "g_album_name_example"; // string | Group by Album Name
$page_size = 3.4; // float | Define the page size for paginated results.Range is 1 to 100.
$page = 3.4; // float | Define the page number for paginated results

try {
    $result = $api_instance->artistAlbumsGetGet($artist_id, $format, $callback, $s_release_date, $g_album_name, $page_size, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling AlbumApi->artistAlbumsGetGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **string**| The musiXmatch artist id |
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional]
 **s_release_date** | **string**| Sort by release date (asc|desc) | [optional]
 **g_album_name** | **string**| Group by Album Name | [optional]
 **page_size** | **float**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **page** | **float**| Define the page number for paginated results | [optional]

### Return type

[**\Swagger\Client\Model\InlineResponse2002**](../Model/InlineResponse2002.md)

### Authorization

[key](../../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

