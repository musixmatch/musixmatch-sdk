# InlineResponse2005MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **float** |  | [optional] 
**status_code** | **float** |  | [optional] 
**execute_time** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


