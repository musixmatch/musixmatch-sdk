# InlineResponse2009Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**\Swagger\Client\Model\InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**\Swagger\Client\Model\InlineResponse2006MessageBodyTrackList**](InlineResponse2006MessageBodyTrackList.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


