# Artist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_credits** | [**\Swagger\Client\Model\ArtistArtistCredits**](ArtistArtistCredits.md) |  | [optional] 
**artist_mbid** | **string** |  | [optional] 
**artist_name** | **string** |  | [optional] 
**secondary_genres** | [**\Swagger\Client\Model\ArtistSecondaryGenres**](ArtistSecondaryGenres.md) |  | [optional] 
**artist_alias_list** | [**\Swagger\Client\Model\ArtistArtistAliasList[]**](ArtistArtistAliasList.md) |  | [optional] 
**artist_vanity_id** | **string** |  | [optional] 
**restricted** | **float** |  | [optional] 
**artist_country** | **string** |  | [optional] 
**artist_comment** | **string** |  | [optional] 
**artist_name_translation_list** | [**\Swagger\Client\Model\ArtistArtistNameTranslationList[]**](ArtistArtistNameTranslationList.md) |  | [optional] 
**artist_edit_url** | **string** |  | [optional] 
**artist_share_url** | **string** |  | [optional] 
**artist_id** | **float** |  | [optional] 
**updated_time** | **string** |  | [optional] 
**managed** | **float** |  | [optional] 
**primary_genres** | [**\Swagger\Client\Model\ArtistPrimaryGenres**](ArtistPrimaryGenres.md) |  | [optional] 
**artist_twitter_url** | **string** |  | [optional] 
**artist_rating** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


