# InlineResponse2004Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**\Swagger\Client\Model\InlineResponse2002MessageHeader**](InlineResponse2002MessageHeader.md) |  | [optional] 
**body** | [**\Swagger\Client\Model\InlineResponse2004MessageBody**](InlineResponse2004MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


