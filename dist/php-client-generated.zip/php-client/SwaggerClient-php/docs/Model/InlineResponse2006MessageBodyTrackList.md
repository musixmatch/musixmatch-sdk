# InlineResponse2006MessageBodyTrackList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track** | [**\Swagger\Client\Model\Track**](Track.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


