# InlineResponse2006MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track_list** | [**\Swagger\Client\Model\InlineResponse2006MessageBodyTrackList[]**](InlineResponse2006MessageBodyTrackList.md) | A list of tracks | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


