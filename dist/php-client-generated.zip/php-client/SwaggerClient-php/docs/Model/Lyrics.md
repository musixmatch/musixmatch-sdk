# Lyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | **float** |  | [optional] 
**pixel_tracking_url** | **string** |  | [optional] 
**publisher_list** | **string[]** |  | [optional] 
**lyrics_language_description** | **string** |  | [optional] 
**restricted** | **float** |  | [optional] 
**updated_time** | **string** |  | [optional] 
**explicit** | **float** |  | [optional] 
**lyrics_copyright** | **string** |  | [optional] 
**html_tracking_url** | **string** |  | [optional] 
**lyrics_language** | **string** |  | [optional] 
**script_tracking_url** | **string** |  | [optional] 
**verified** | **float** |  | [optional] 
**lyrics_body** | **string** |  | [optional] 
**lyrics_id** | **float** |  | [optional] 
**writer_list** | **string[]** |  | [optional] 
**can_edit** | **float** |  | [optional] 
**action_requested** | **string** |  | [optional] 
**locked** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


