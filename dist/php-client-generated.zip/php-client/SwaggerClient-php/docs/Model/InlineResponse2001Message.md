# InlineResponse2001Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**\Swagger\Client\Model\InlineResponse2001MessageHeader**](InlineResponse2001MessageHeader.md) |  | [optional] 
**body** | [**\Swagger\Client\Model\InlineResponse2001MessageBody**](InlineResponse2001MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


