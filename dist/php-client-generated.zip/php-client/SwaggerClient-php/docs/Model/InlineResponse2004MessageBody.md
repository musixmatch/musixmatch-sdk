# InlineResponse2004MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_list** | [**\Swagger\Client\Model\InlineResponse2003MessageBody[]**](InlineResponse2003MessageBody.md) | A list of artists | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


