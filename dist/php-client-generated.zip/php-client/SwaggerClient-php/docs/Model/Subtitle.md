# Subtitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subtitle_body** | **string** |  | [optional] 
**publisher_list** | **string[]** |  | [optional] 
**subtitle_language** | **string** |  | [optional] 
**subtitle_language_description** | **string** |  | [optional] 
**subtitle_id** | **float** |  | [optional] 
**pixel_tracking_url** | **string** |  | [optional] 
**html_tracking_url** | **string** |  | [optional] 
**restricted** | **float** |  | [optional] 
**lyrics_copyright** | **string** |  | [optional] 
**script_tracking_url** | **string** |  | [optional] 
**subtitle_length** | **float** |  | [optional] 
**updated_time** | **string** |  | [optional] 
**writer_list** | **string[]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


