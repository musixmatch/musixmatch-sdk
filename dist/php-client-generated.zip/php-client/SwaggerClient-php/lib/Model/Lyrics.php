<?php
/**
 * Lyrics
 *
 * PHP version 5
 *
 * @category Class
 * @package  Swagger\Client
 * @author   http://github.com/swagger-api/swagger-codegen
 * @license  http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link     https://github.com/swagger-api/swagger-codegen
 */

/**
 * Musixmatch API
 *
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen
 * Do not edit the class manually.
 */

namespace Swagger\Client\Model;

use \ArrayAccess;

/**
 * Lyrics Class Doc Comment
 *
 * @category    Class */
 // @description a Lyrics in the Musixmatch database.
/** 
 * @package     Swagger\Client
 * @author      http://github.com/swagger-api/swagger-codegen
 * @license     http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link        https://github.com/swagger-api/swagger-codegen
 */
class Lyrics implements ArrayAccess
{
    /**
      * The original name of the model.
      * @var string
      */
    protected static $swaggerModelName = 'Lyrics';

    /**
      * Array of property to type mappings. Used for (de)serialization
      * @var string[]
      */
    protected static $swaggerTypes = array(
        'instrumental' => 'float',
        'pixel_tracking_url' => 'string',
        'publisher_list' => 'string[]',
        'lyrics_language_description' => 'string',
        'restricted' => 'float',
        'updated_time' => 'string',
        'explicit' => 'float',
        'lyrics_copyright' => 'string',
        'html_tracking_url' => 'string',
        'lyrics_language' => 'string',
        'script_tracking_url' => 'string',
        'verified' => 'float',
        'lyrics_body' => 'string',
        'lyrics_id' => 'float',
        'writer_list' => 'string[]',
        'can_edit' => 'float',
        'action_requested' => 'string',
        'locked' => 'float'
    );

    public static function swaggerTypes()
    {
        return self::$swaggerTypes;
    }

    /**
     * Array of attributes where the key is the local name, and the value is the original name
     * @var string[]
     */
    protected static $attributeMap = array(
        'instrumental' => 'instrumental',
        'pixel_tracking_url' => 'pixel_tracking_url',
        'publisher_list' => 'publisher_list',
        'lyrics_language_description' => 'lyrics_language_description',
        'restricted' => 'restricted',
        'updated_time' => 'updated_time',
        'explicit' => 'explicit',
        'lyrics_copyright' => 'lyrics_copyright',
        'html_tracking_url' => 'html_tracking_url',
        'lyrics_language' => 'lyrics_language',
        'script_tracking_url' => 'script_tracking_url',
        'verified' => 'verified',
        'lyrics_body' => 'lyrics_body',
        'lyrics_id' => 'lyrics_id',
        'writer_list' => 'writer_list',
        'can_edit' => 'can_edit',
        'action_requested' => 'action_requested',
        'locked' => 'locked'
    );

    public static function attributeMap()
    {
        return self::$attributeMap;
    }

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     * @var string[]
     */
    protected static $setters = array(
        'instrumental' => 'setInstrumental',
        'pixel_tracking_url' => 'setPixelTrackingUrl',
        'publisher_list' => 'setPublisherList',
        'lyrics_language_description' => 'setLyricsLanguageDescription',
        'restricted' => 'setRestricted',
        'updated_time' => 'setUpdatedTime',
        'explicit' => 'setExplicit',
        'lyrics_copyright' => 'setLyricsCopyright',
        'html_tracking_url' => 'setHtmlTrackingUrl',
        'lyrics_language' => 'setLyricsLanguage',
        'script_tracking_url' => 'setScriptTrackingUrl',
        'verified' => 'setVerified',
        'lyrics_body' => 'setLyricsBody',
        'lyrics_id' => 'setLyricsId',
        'writer_list' => 'setWriterList',
        'can_edit' => 'setCanEdit',
        'action_requested' => 'setActionRequested',
        'locked' => 'setLocked'
    );

    public static function setters()
    {
        return self::$setters;
    }

    /**
     * Array of attributes to getter functions (for serialization of requests)
     * @var string[]
     */
    protected static $getters = array(
        'instrumental' => 'getInstrumental',
        'pixel_tracking_url' => 'getPixelTrackingUrl',
        'publisher_list' => 'getPublisherList',
        'lyrics_language_description' => 'getLyricsLanguageDescription',
        'restricted' => 'getRestricted',
        'updated_time' => 'getUpdatedTime',
        'explicit' => 'getExplicit',
        'lyrics_copyright' => 'getLyricsCopyright',
        'html_tracking_url' => 'getHtmlTrackingUrl',
        'lyrics_language' => 'getLyricsLanguage',
        'script_tracking_url' => 'getScriptTrackingUrl',
        'verified' => 'getVerified',
        'lyrics_body' => 'getLyricsBody',
        'lyrics_id' => 'getLyricsId',
        'writer_list' => 'getWriterList',
        'can_edit' => 'getCanEdit',
        'action_requested' => 'getActionRequested',
        'locked' => 'getLocked'
    );

    public static function getters()
    {
        return self::$getters;
    }

    

    

    /**
     * Associative array for storing property values
     * @var mixed[]
     */
    protected $container = array();

    /**
     * Constructor
     * @param mixed[] $data Associated array of property value initalizing the model
     */
    public function __construct(array $data = null)
    {
        $this->container['instrumental'] = isset($data['instrumental']) ? $data['instrumental'] : null;
        $this->container['pixel_tracking_url'] = isset($data['pixel_tracking_url']) ? $data['pixel_tracking_url'] : null;
        $this->container['publisher_list'] = isset($data['publisher_list']) ? $data['publisher_list'] : null;
        $this->container['lyrics_language_description'] = isset($data['lyrics_language_description']) ? $data['lyrics_language_description'] : null;
        $this->container['restricted'] = isset($data['restricted']) ? $data['restricted'] : null;
        $this->container['updated_time'] = isset($data['updated_time']) ? $data['updated_time'] : null;
        $this->container['explicit'] = isset($data['explicit']) ? $data['explicit'] : null;
        $this->container['lyrics_copyright'] = isset($data['lyrics_copyright']) ? $data['lyrics_copyright'] : null;
        $this->container['html_tracking_url'] = isset($data['html_tracking_url']) ? $data['html_tracking_url'] : null;
        $this->container['lyrics_language'] = isset($data['lyrics_language']) ? $data['lyrics_language'] : null;
        $this->container['script_tracking_url'] = isset($data['script_tracking_url']) ? $data['script_tracking_url'] : null;
        $this->container['verified'] = isset($data['verified']) ? $data['verified'] : null;
        $this->container['lyrics_body'] = isset($data['lyrics_body']) ? $data['lyrics_body'] : null;
        $this->container['lyrics_id'] = isset($data['lyrics_id']) ? $data['lyrics_id'] : null;
        $this->container['writer_list'] = isset($data['writer_list']) ? $data['writer_list'] : null;
        $this->container['can_edit'] = isset($data['can_edit']) ? $data['can_edit'] : null;
        $this->container['action_requested'] = isset($data['action_requested']) ? $data['action_requested'] : null;
        $this->container['locked'] = isset($data['locked']) ? $data['locked'] : null;
    }

    /**
     * show all the invalid properties with reasons.
     *
     * @return array invalid properties with reasons
     */
    public function listInvalidProperties()
    {
        $invalid_properties = array();
        return $invalid_properties;
    }

    /**
     * validate all the properties in the model
     * return true if all passed
     *
     * @return bool True if all properteis are valid
     */
    public function valid()
    {
        return true;
    }


    /**
     * Gets instrumental
     * @return float
     */
    public function getInstrumental()
    {
        return $this->container['instrumental'];
    }

    /**
     * Sets instrumental
     * @param float $instrumental 
     * @return $this
     */
    public function setInstrumental($instrumental)
    {
        $this->container['instrumental'] = $instrumental;

        return $this;
    }

    /**
     * Gets pixel_tracking_url
     * @return string
     */
    public function getPixelTrackingUrl()
    {
        return $this->container['pixel_tracking_url'];
    }

    /**
     * Sets pixel_tracking_url
     * @param string $pixel_tracking_url 
     * @return $this
     */
    public function setPixelTrackingUrl($pixel_tracking_url)
    {
        $this->container['pixel_tracking_url'] = $pixel_tracking_url;

        return $this;
    }

    /**
     * Gets publisher_list
     * @return string[]
     */
    public function getPublisherList()
    {
        return $this->container['publisher_list'];
    }

    /**
     * Sets publisher_list
     * @param string[] $publisher_list
     * @return $this
     */
    public function setPublisherList($publisher_list)
    {
        $this->container['publisher_list'] = $publisher_list;

        return $this;
    }

    /**
     * Gets lyrics_language_description
     * @return string
     */
    public function getLyricsLanguageDescription()
    {
        return $this->container['lyrics_language_description'];
    }

    /**
     * Sets lyrics_language_description
     * @param string $lyrics_language_description 
     * @return $this
     */
    public function setLyricsLanguageDescription($lyrics_language_description)
    {
        $this->container['lyrics_language_description'] = $lyrics_language_description;

        return $this;
    }

    /**
     * Gets restricted
     * @return float
     */
    public function getRestricted()
    {
        return $this->container['restricted'];
    }

    /**
     * Sets restricted
     * @param float $restricted 
     * @return $this
     */
    public function setRestricted($restricted)
    {
        $this->container['restricted'] = $restricted;

        return $this;
    }

    /**
     * Gets updated_time
     * @return string
     */
    public function getUpdatedTime()
    {
        return $this->container['updated_time'];
    }

    /**
     * Sets updated_time
     * @param string $updated_time 
     * @return $this
     */
    public function setUpdatedTime($updated_time)
    {
        $this->container['updated_time'] = $updated_time;

        return $this;
    }

    /**
     * Gets explicit
     * @return float
     */
    public function getExplicit()
    {
        return $this->container['explicit'];
    }

    /**
     * Sets explicit
     * @param float $explicit 
     * @return $this
     */
    public function setExplicit($explicit)
    {
        $this->container['explicit'] = $explicit;

        return $this;
    }

    /**
     * Gets lyrics_copyright
     * @return string
     */
    public function getLyricsCopyright()
    {
        return $this->container['lyrics_copyright'];
    }

    /**
     * Sets lyrics_copyright
     * @param string $lyrics_copyright 
     * @return $this
     */
    public function setLyricsCopyright($lyrics_copyright)
    {
        $this->container['lyrics_copyright'] = $lyrics_copyright;

        return $this;
    }

    /**
     * Gets html_tracking_url
     * @return string
     */
    public function getHtmlTrackingUrl()
    {
        return $this->container['html_tracking_url'];
    }

    /**
     * Sets html_tracking_url
     * @param string $html_tracking_url 
     * @return $this
     */
    public function setHtmlTrackingUrl($html_tracking_url)
    {
        $this->container['html_tracking_url'] = $html_tracking_url;

        return $this;
    }

    /**
     * Gets lyrics_language
     * @return string
     */
    public function getLyricsLanguage()
    {
        return $this->container['lyrics_language'];
    }

    /**
     * Sets lyrics_language
     * @param string $lyrics_language 
     * @return $this
     */
    public function setLyricsLanguage($lyrics_language)
    {
        $this->container['lyrics_language'] = $lyrics_language;

        return $this;
    }

    /**
     * Gets script_tracking_url
     * @return string
     */
    public function getScriptTrackingUrl()
    {
        return $this->container['script_tracking_url'];
    }

    /**
     * Sets script_tracking_url
     * @param string $script_tracking_url 
     * @return $this
     */
    public function setScriptTrackingUrl($script_tracking_url)
    {
        $this->container['script_tracking_url'] = $script_tracking_url;

        return $this;
    }

    /**
     * Gets verified
     * @return float
     */
    public function getVerified()
    {
        return $this->container['verified'];
    }

    /**
     * Sets verified
     * @param float $verified 
     * @return $this
     */
    public function setVerified($verified)
    {
        $this->container['verified'] = $verified;

        return $this;
    }

    /**
     * Gets lyrics_body
     * @return string
     */
    public function getLyricsBody()
    {
        return $this->container['lyrics_body'];
    }

    /**
     * Sets lyrics_body
     * @param string $lyrics_body 
     * @return $this
     */
    public function setLyricsBody($lyrics_body)
    {
        $this->container['lyrics_body'] = $lyrics_body;

        return $this;
    }

    /**
     * Gets lyrics_id
     * @return float
     */
    public function getLyricsId()
    {
        return $this->container['lyrics_id'];
    }

    /**
     * Sets lyrics_id
     * @param float $lyrics_id 
     * @return $this
     */
    public function setLyricsId($lyrics_id)
    {
        $this->container['lyrics_id'] = $lyrics_id;

        return $this;
    }

    /**
     * Gets writer_list
     * @return string[]
     */
    public function getWriterList()
    {
        return $this->container['writer_list'];
    }

    /**
     * Sets writer_list
     * @param string[] $writer_list
     * @return $this
     */
    public function setWriterList($writer_list)
    {
        $this->container['writer_list'] = $writer_list;

        return $this;
    }

    /**
     * Gets can_edit
     * @return float
     */
    public function getCanEdit()
    {
        return $this->container['can_edit'];
    }

    /**
     * Sets can_edit
     * @param float $can_edit 
     * @return $this
     */
    public function setCanEdit($can_edit)
    {
        $this->container['can_edit'] = $can_edit;

        return $this;
    }

    /**
     * Gets action_requested
     * @return string
     */
    public function getActionRequested()
    {
        return $this->container['action_requested'];
    }

    /**
     * Sets action_requested
     * @param string $action_requested 
     * @return $this
     */
    public function setActionRequested($action_requested)
    {
        $this->container['action_requested'] = $action_requested;

        return $this;
    }

    /**
     * Gets locked
     * @return float
     */
    public function getLocked()
    {
        return $this->container['locked'];
    }

    /**
     * Sets locked
     * @param float $locked 
     * @return $this
     */
    public function setLocked($locked)
    {
        $this->container['locked'] = $locked;

        return $this;
    }
    /**
     * Returns true if offset exists. False otherwise.
     * @param  integer $offset Offset
     * @return boolean
     */
    public function offsetExists($offset)
    {
        return isset($this->container[$offset]);
    }

    /**
     * Gets offset.
     * @param  integer $offset Offset
     * @return mixed
     */
    public function offsetGet($offset)
    {
        return isset($this->container[$offset]) ? $this->container[$offset] : null;
    }

    /**
     * Sets value based on offset.
     * @param  integer $offset Offset
     * @param  mixed   $value  Value to be set
     * @return void
     */
    public function offsetSet($offset, $value)
    {
        if (is_null($offset)) {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    /**
     * Unsets offset.
     * @param  integer $offset Offset
     * @return void
     */
    public function offsetUnset($offset)
    {
        unset($this->container[$offset]);
    }

    /**
     * Gets the string presentation of the object
     * @return string
     */
    public function __toString()
    {
        if (defined('JSON_PRETTY_PRINT')) { // use JSON pretty print
            return json_encode(\Swagger\Client\ObjectSerializer::sanitizeForSerialization($this), JSON_PRETTY_PRINT);
        }

        return json_encode(\Swagger\Client\ObjectSerializer::sanitizeForSerialization($this));
    }
}


