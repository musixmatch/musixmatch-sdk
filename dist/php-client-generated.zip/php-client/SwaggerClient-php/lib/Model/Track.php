<?php
/**
 * Track
 *
 * PHP version 5
 *
 * @category Class
 * @package  Swagger\Client
 * @author   http://github.com/swagger-api/swagger-codegen
 * @license  http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link     https://github.com/swagger-api/swagger-codegen
 */

/**
 * Musixmatch API
 *
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen
 * Do not edit the class manually.
 */

namespace Swagger\Client\Model;

use \ArrayAccess;

/**
 * Track Class Doc Comment
 *
 * @category    Class */
 // @description a song in the Musixmatch database
/** 
 * @package     Swagger\Client
 * @author      http://github.com/swagger-api/swagger-codegen
 * @license     http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link        https://github.com/swagger-api/swagger-codegen
 */
class Track implements ArrayAccess
{
    /**
      * The original name of the model.
      * @var string
      */
    protected static $swaggerModelName = 'Track';

    /**
      * Array of property to type mappings. Used for (de)serialization
      * @var string[]
      */
    protected static $swaggerTypes = array(
        'instrumental' => 'float',
        'album_coverart_350x350' => 'string',
        'first_release_date' => 'string',
        'track_isrc' => 'string',
        'explicit' => 'float',
        'track_edit_url' => 'string',
        'num_favourite' => 'float',
        'album_coverart_500x500' => 'string',
        'album_name' => 'string',
        'track_rating' => 'float',
        'track_share_url' => 'string',
        'track_soundcloud_id' => 'float',
        'artist_name' => 'string',
        'album_coverart_800x800' => 'string',
        'album_coverart_100x100' => 'string',
        'track_name_translation_list' => 'string[]',
        'track_name' => 'string',
        'restricted' => 'float',
        'has_subtitles' => 'float',
        'updated_time' => 'string',
        'subtitle_id' => 'float',
        'lyrics_id' => 'float',
        'track_spotify_id' => 'string',
        'has_lyrics' => 'float',
        'artist_id' => 'float',
        'album_id' => 'float',
        'artist_mbid' => 'string',
        'secondary_genres' => '\Swagger\Client\Model\TrackSecondaryGenres',
        'commontrack_vanity_id' => 'string',
        'track_id' => 'float',
        'track_xboxmusic_id' => 'string',
        'primary_genres' => '\Swagger\Client\Model\TrackPrimaryGenres',
        'track_length' => 'float',
        'track_mbid' => 'string',
        'commontrack_id' => 'float'
    );

    public static function swaggerTypes()
    {
        return self::$swaggerTypes;
    }

    /**
     * Array of attributes where the key is the local name, and the value is the original name
     * @var string[]
     */
    protected static $attributeMap = array(
        'instrumental' => 'instrumental',
        'album_coverart_350x350' => 'album_coverart_350x350',
        'first_release_date' => 'first_release_date',
        'track_isrc' => 'track_isrc',
        'explicit' => 'explicit',
        'track_edit_url' => 'track_edit_url',
        'num_favourite' => 'num_favourite',
        'album_coverart_500x500' => 'album_coverart_500x500',
        'album_name' => 'album_name',
        'track_rating' => 'track_rating',
        'track_share_url' => 'track_share_url',
        'track_soundcloud_id' => 'track_soundcloud_id',
        'artist_name' => 'artist_name',
        'album_coverart_800x800' => 'album_coverart_800x800',
        'album_coverart_100x100' => 'album_coverart_100x100',
        'track_name_translation_list' => 'track_name_translation_list',
        'track_name' => 'track_name',
        'restricted' => 'restricted',
        'has_subtitles' => 'has_subtitles',
        'updated_time' => 'updated_time',
        'subtitle_id' => 'subtitle_id',
        'lyrics_id' => 'lyrics_id',
        'track_spotify_id' => 'track_spotify_id',
        'has_lyrics' => 'has_lyrics',
        'artist_id' => 'artist_id',
        'album_id' => 'album_id',
        'artist_mbid' => 'artist_mbid',
        'secondary_genres' => 'secondary_genres',
        'commontrack_vanity_id' => 'commontrack_vanity_id',
        'track_id' => 'track_id',
        'track_xboxmusic_id' => 'track_xboxmusic_id',
        'primary_genres' => 'primary_genres',
        'track_length' => 'track_length',
        'track_mbid' => 'track_mbid',
        'commontrack_id' => 'commontrack_id'
    );

    public static function attributeMap()
    {
        return self::$attributeMap;
    }

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     * @var string[]
     */
    protected static $setters = array(
        'instrumental' => 'setInstrumental',
        'album_coverart_350x350' => 'setAlbumCoverart350x350',
        'first_release_date' => 'setFirstReleaseDate',
        'track_isrc' => 'setTrackIsrc',
        'explicit' => 'setExplicit',
        'track_edit_url' => 'setTrackEditUrl',
        'num_favourite' => 'setNumFavourite',
        'album_coverart_500x500' => 'setAlbumCoverart500x500',
        'album_name' => 'setAlbumName',
        'track_rating' => 'setTrackRating',
        'track_share_url' => 'setTrackShareUrl',
        'track_soundcloud_id' => 'setTrackSoundcloudId',
        'artist_name' => 'setArtistName',
        'album_coverart_800x800' => 'setAlbumCoverart800x800',
        'album_coverart_100x100' => 'setAlbumCoverart100x100',
        'track_name_translation_list' => 'setTrackNameTranslationList',
        'track_name' => 'setTrackName',
        'restricted' => 'setRestricted',
        'has_subtitles' => 'setHasSubtitles',
        'updated_time' => 'setUpdatedTime',
        'subtitle_id' => 'setSubtitleId',
        'lyrics_id' => 'setLyricsId',
        'track_spotify_id' => 'setTrackSpotifyId',
        'has_lyrics' => 'setHasLyrics',
        'artist_id' => 'setArtistId',
        'album_id' => 'setAlbumId',
        'artist_mbid' => 'setArtistMbid',
        'secondary_genres' => 'setSecondaryGenres',
        'commontrack_vanity_id' => 'setCommontrackVanityId',
        'track_id' => 'setTrackId',
        'track_xboxmusic_id' => 'setTrackXboxmusicId',
        'primary_genres' => 'setPrimaryGenres',
        'track_length' => 'setTrackLength',
        'track_mbid' => 'setTrackMbid',
        'commontrack_id' => 'setCommontrackId'
    );

    public static function setters()
    {
        return self::$setters;
    }

    /**
     * Array of attributes to getter functions (for serialization of requests)
     * @var string[]
     */
    protected static $getters = array(
        'instrumental' => 'getInstrumental',
        'album_coverart_350x350' => 'getAlbumCoverart350x350',
        'first_release_date' => 'getFirstReleaseDate',
        'track_isrc' => 'getTrackIsrc',
        'explicit' => 'getExplicit',
        'track_edit_url' => 'getTrackEditUrl',
        'num_favourite' => 'getNumFavourite',
        'album_coverart_500x500' => 'getAlbumCoverart500x500',
        'album_name' => 'getAlbumName',
        'track_rating' => 'getTrackRating',
        'track_share_url' => 'getTrackShareUrl',
        'track_soundcloud_id' => 'getTrackSoundcloudId',
        'artist_name' => 'getArtistName',
        'album_coverart_800x800' => 'getAlbumCoverart800x800',
        'album_coverart_100x100' => 'getAlbumCoverart100x100',
        'track_name_translation_list' => 'getTrackNameTranslationList',
        'track_name' => 'getTrackName',
        'restricted' => 'getRestricted',
        'has_subtitles' => 'getHasSubtitles',
        'updated_time' => 'getUpdatedTime',
        'subtitle_id' => 'getSubtitleId',
        'lyrics_id' => 'getLyricsId',
        'track_spotify_id' => 'getTrackSpotifyId',
        'has_lyrics' => 'getHasLyrics',
        'artist_id' => 'getArtistId',
        'album_id' => 'getAlbumId',
        'artist_mbid' => 'getArtistMbid',
        'secondary_genres' => 'getSecondaryGenres',
        'commontrack_vanity_id' => 'getCommontrackVanityId',
        'track_id' => 'getTrackId',
        'track_xboxmusic_id' => 'getTrackXboxmusicId',
        'primary_genres' => 'getPrimaryGenres',
        'track_length' => 'getTrackLength',
        'track_mbid' => 'getTrackMbid',
        'commontrack_id' => 'getCommontrackId'
    );

    public static function getters()
    {
        return self::$getters;
    }

    

    

    /**
     * Associative array for storing property values
     * @var mixed[]
     */
    protected $container = array();

    /**
     * Constructor
     * @param mixed[] $data Associated array of property value initalizing the model
     */
    public function __construct(array $data = null)
    {
        $this->container['instrumental'] = isset($data['instrumental']) ? $data['instrumental'] : null;
        $this->container['album_coverart_350x350'] = isset($data['album_coverart_350x350']) ? $data['album_coverart_350x350'] : null;
        $this->container['first_release_date'] = isset($data['first_release_date']) ? $data['first_release_date'] : null;
        $this->container['track_isrc'] = isset($data['track_isrc']) ? $data['track_isrc'] : null;
        $this->container['explicit'] = isset($data['explicit']) ? $data['explicit'] : null;
        $this->container['track_edit_url'] = isset($data['track_edit_url']) ? $data['track_edit_url'] : null;
        $this->container['num_favourite'] = isset($data['num_favourite']) ? $data['num_favourite'] : null;
        $this->container['album_coverart_500x500'] = isset($data['album_coverart_500x500']) ? $data['album_coverart_500x500'] : null;
        $this->container['album_name'] = isset($data['album_name']) ? $data['album_name'] : null;
        $this->container['track_rating'] = isset($data['track_rating']) ? $data['track_rating'] : null;
        $this->container['track_share_url'] = isset($data['track_share_url']) ? $data['track_share_url'] : null;
        $this->container['track_soundcloud_id'] = isset($data['track_soundcloud_id']) ? $data['track_soundcloud_id'] : null;
        $this->container['artist_name'] = isset($data['artist_name']) ? $data['artist_name'] : null;
        $this->container['album_coverart_800x800'] = isset($data['album_coverart_800x800']) ? $data['album_coverart_800x800'] : null;
        $this->container['album_coverart_100x100'] = isset($data['album_coverart_100x100']) ? $data['album_coverart_100x100'] : null;
        $this->container['track_name_translation_list'] = isset($data['track_name_translation_list']) ? $data['track_name_translation_list'] : null;
        $this->container['track_name'] = isset($data['track_name']) ? $data['track_name'] : null;
        $this->container['restricted'] = isset($data['restricted']) ? $data['restricted'] : null;
        $this->container['has_subtitles'] = isset($data['has_subtitles']) ? $data['has_subtitles'] : null;
        $this->container['updated_time'] = isset($data['updated_time']) ? $data['updated_time'] : null;
        $this->container['subtitle_id'] = isset($data['subtitle_id']) ? $data['subtitle_id'] : null;
        $this->container['lyrics_id'] = isset($data['lyrics_id']) ? $data['lyrics_id'] : null;
        $this->container['track_spotify_id'] = isset($data['track_spotify_id']) ? $data['track_spotify_id'] : null;
        $this->container['has_lyrics'] = isset($data['has_lyrics']) ? $data['has_lyrics'] : null;
        $this->container['artist_id'] = isset($data['artist_id']) ? $data['artist_id'] : null;
        $this->container['album_id'] = isset($data['album_id']) ? $data['album_id'] : null;
        $this->container['artist_mbid'] = isset($data['artist_mbid']) ? $data['artist_mbid'] : null;
        $this->container['secondary_genres'] = isset($data['secondary_genres']) ? $data['secondary_genres'] : null;
        $this->container['commontrack_vanity_id'] = isset($data['commontrack_vanity_id']) ? $data['commontrack_vanity_id'] : null;
        $this->container['track_id'] = isset($data['track_id']) ? $data['track_id'] : null;
        $this->container['track_xboxmusic_id'] = isset($data['track_xboxmusic_id']) ? $data['track_xboxmusic_id'] : null;
        $this->container['primary_genres'] = isset($data['primary_genres']) ? $data['primary_genres'] : null;
        $this->container['track_length'] = isset($data['track_length']) ? $data['track_length'] : null;
        $this->container['track_mbid'] = isset($data['track_mbid']) ? $data['track_mbid'] : null;
        $this->container['commontrack_id'] = isset($data['commontrack_id']) ? $data['commontrack_id'] : null;
    }

    /**
     * show all the invalid properties with reasons.
     *
     * @return array invalid properties with reasons
     */
    public function listInvalidProperties()
    {
        $invalid_properties = array();
        return $invalid_properties;
    }

    /**
     * validate all the properties in the model
     * return true if all passed
     *
     * @return bool True if all properteis are valid
     */
    public function valid()
    {
        return true;
    }


    /**
     * Gets instrumental
     * @return float
     */
    public function getInstrumental()
    {
        return $this->container['instrumental'];
    }

    /**
     * Sets instrumental
     * @param float $instrumental 
     * @return $this
     */
    public function setInstrumental($instrumental)
    {
        $this->container['instrumental'] = $instrumental;

        return $this;
    }

    /**
     * Gets album_coverart_350x350
     * @return string
     */
    public function getAlbumCoverart350x350()
    {
        return $this->container['album_coverart_350x350'];
    }

    /**
     * Sets album_coverart_350x350
     * @param string $album_coverart_350x350 
     * @return $this
     */
    public function setAlbumCoverart350x350($album_coverart_350x350)
    {
        $this->container['album_coverart_350x350'] = $album_coverart_350x350;

        return $this;
    }

    /**
     * Gets first_release_date
     * @return string
     */
    public function getFirstReleaseDate()
    {
        return $this->container['first_release_date'];
    }

    /**
     * Sets first_release_date
     * @param string $first_release_date 
     * @return $this
     */
    public function setFirstReleaseDate($first_release_date)
    {
        $this->container['first_release_date'] = $first_release_date;

        return $this;
    }

    /**
     * Gets track_isrc
     * @return string
     */
    public function getTrackIsrc()
    {
        return $this->container['track_isrc'];
    }

    /**
     * Sets track_isrc
     * @param string $track_isrc 
     * @return $this
     */
    public function setTrackIsrc($track_isrc)
    {
        $this->container['track_isrc'] = $track_isrc;

        return $this;
    }

    /**
     * Gets explicit
     * @return float
     */
    public function getExplicit()
    {
        return $this->container['explicit'];
    }

    /**
     * Sets explicit
     * @param float $explicit 
     * @return $this
     */
    public function setExplicit($explicit)
    {
        $this->container['explicit'] = $explicit;

        return $this;
    }

    /**
     * Gets track_edit_url
     * @return string
     */
    public function getTrackEditUrl()
    {
        return $this->container['track_edit_url'];
    }

    /**
     * Sets track_edit_url
     * @param string $track_edit_url 
     * @return $this
     */
    public function setTrackEditUrl($track_edit_url)
    {
        $this->container['track_edit_url'] = $track_edit_url;

        return $this;
    }

    /**
     * Gets num_favourite
     * @return float
     */
    public function getNumFavourite()
    {
        return $this->container['num_favourite'];
    }

    /**
     * Sets num_favourite
     * @param float $num_favourite 
     * @return $this
     */
    public function setNumFavourite($num_favourite)
    {
        $this->container['num_favourite'] = $num_favourite;

        return $this;
    }

    /**
     * Gets album_coverart_500x500
     * @return string
     */
    public function getAlbumCoverart500x500()
    {
        return $this->container['album_coverart_500x500'];
    }

    /**
     * Sets album_coverart_500x500
     * @param string $album_coverart_500x500 
     * @return $this
     */
    public function setAlbumCoverart500x500($album_coverart_500x500)
    {
        $this->container['album_coverart_500x500'] = $album_coverart_500x500;

        return $this;
    }

    /**
     * Gets album_name
     * @return string
     */
    public function getAlbumName()
    {
        return $this->container['album_name'];
    }

    /**
     * Sets album_name
     * @param string $album_name 
     * @return $this
     */
    public function setAlbumName($album_name)
    {
        $this->container['album_name'] = $album_name;

        return $this;
    }

    /**
     * Gets track_rating
     * @return float
     */
    public function getTrackRating()
    {
        return $this->container['track_rating'];
    }

    /**
     * Sets track_rating
     * @param float $track_rating 
     * @return $this
     */
    public function setTrackRating($track_rating)
    {
        $this->container['track_rating'] = $track_rating;

        return $this;
    }

    /**
     * Gets track_share_url
     * @return string
     */
    public function getTrackShareUrl()
    {
        return $this->container['track_share_url'];
    }

    /**
     * Sets track_share_url
     * @param string $track_share_url 
     * @return $this
     */
    public function setTrackShareUrl($track_share_url)
    {
        $this->container['track_share_url'] = $track_share_url;

        return $this;
    }

    /**
     * Gets track_soundcloud_id
     * @return float
     */
    public function getTrackSoundcloudId()
    {
        return $this->container['track_soundcloud_id'];
    }

    /**
     * Sets track_soundcloud_id
     * @param float $track_soundcloud_id 
     * @return $this
     */
    public function setTrackSoundcloudId($track_soundcloud_id)
    {
        $this->container['track_soundcloud_id'] = $track_soundcloud_id;

        return $this;
    }

    /**
     * Gets artist_name
     * @return string
     */
    public function getArtistName()
    {
        return $this->container['artist_name'];
    }

    /**
     * Sets artist_name
     * @param string $artist_name 
     * @return $this
     */
    public function setArtistName($artist_name)
    {
        $this->container['artist_name'] = $artist_name;

        return $this;
    }

    /**
     * Gets album_coverart_800x800
     * @return string
     */
    public function getAlbumCoverart800x800()
    {
        return $this->container['album_coverart_800x800'];
    }

    /**
     * Sets album_coverart_800x800
     * @param string $album_coverart_800x800 
     * @return $this
     */
    public function setAlbumCoverart800x800($album_coverart_800x800)
    {
        $this->container['album_coverart_800x800'] = $album_coverart_800x800;

        return $this;
    }

    /**
     * Gets album_coverart_100x100
     * @return string
     */
    public function getAlbumCoverart100x100()
    {
        return $this->container['album_coverart_100x100'];
    }

    /**
     * Sets album_coverart_100x100
     * @param string $album_coverart_100x100 
     * @return $this
     */
    public function setAlbumCoverart100x100($album_coverart_100x100)
    {
        $this->container['album_coverart_100x100'] = $album_coverart_100x100;

        return $this;
    }

    /**
     * Gets track_name_translation_list
     * @return string[]
     */
    public function getTrackNameTranslationList()
    {
        return $this->container['track_name_translation_list'];
    }

    /**
     * Sets track_name_translation_list
     * @param string[] $track_name_translation_list
     * @return $this
     */
    public function setTrackNameTranslationList($track_name_translation_list)
    {
        $this->container['track_name_translation_list'] = $track_name_translation_list;

        return $this;
    }

    /**
     * Gets track_name
     * @return string
     */
    public function getTrackName()
    {
        return $this->container['track_name'];
    }

    /**
     * Sets track_name
     * @param string $track_name 
     * @return $this
     */
    public function setTrackName($track_name)
    {
        $this->container['track_name'] = $track_name;

        return $this;
    }

    /**
     * Gets restricted
     * @return float
     */
    public function getRestricted()
    {
        return $this->container['restricted'];
    }

    /**
     * Sets restricted
     * @param float $restricted 
     * @return $this
     */
    public function setRestricted($restricted)
    {
        $this->container['restricted'] = $restricted;

        return $this;
    }

    /**
     * Gets has_subtitles
     * @return float
     */
    public function getHasSubtitles()
    {
        return $this->container['has_subtitles'];
    }

    /**
     * Sets has_subtitles
     * @param float $has_subtitles 
     * @return $this
     */
    public function setHasSubtitles($has_subtitles)
    {
        $this->container['has_subtitles'] = $has_subtitles;

        return $this;
    }

    /**
     * Gets updated_time
     * @return string
     */
    public function getUpdatedTime()
    {
        return $this->container['updated_time'];
    }

    /**
     * Sets updated_time
     * @param string $updated_time 
     * @return $this
     */
    public function setUpdatedTime($updated_time)
    {
        $this->container['updated_time'] = $updated_time;

        return $this;
    }

    /**
     * Gets subtitle_id
     * @return float
     */
    public function getSubtitleId()
    {
        return $this->container['subtitle_id'];
    }

    /**
     * Sets subtitle_id
     * @param float $subtitle_id 
     * @return $this
     */
    public function setSubtitleId($subtitle_id)
    {
        $this->container['subtitle_id'] = $subtitle_id;

        return $this;
    }

    /**
     * Gets lyrics_id
     * @return float
     */
    public function getLyricsId()
    {
        return $this->container['lyrics_id'];
    }

    /**
     * Sets lyrics_id
     * @param float $lyrics_id 
     * @return $this
     */
    public function setLyricsId($lyrics_id)
    {
        $this->container['lyrics_id'] = $lyrics_id;

        return $this;
    }

    /**
     * Gets track_spotify_id
     * @return string
     */
    public function getTrackSpotifyId()
    {
        return $this->container['track_spotify_id'];
    }

    /**
     * Sets track_spotify_id
     * @param string $track_spotify_id 
     * @return $this
     */
    public function setTrackSpotifyId($track_spotify_id)
    {
        $this->container['track_spotify_id'] = $track_spotify_id;

        return $this;
    }

    /**
     * Gets has_lyrics
     * @return float
     */
    public function getHasLyrics()
    {
        return $this->container['has_lyrics'];
    }

    /**
     * Sets has_lyrics
     * @param float $has_lyrics 
     * @return $this
     */
    public function setHasLyrics($has_lyrics)
    {
        $this->container['has_lyrics'] = $has_lyrics;

        return $this;
    }

    /**
     * Gets artist_id
     * @return float
     */
    public function getArtistId()
    {
        return $this->container['artist_id'];
    }

    /**
     * Sets artist_id
     * @param float $artist_id 
     * @return $this
     */
    public function setArtistId($artist_id)
    {
        $this->container['artist_id'] = $artist_id;

        return $this;
    }

    /**
     * Gets album_id
     * @return float
     */
    public function getAlbumId()
    {
        return $this->container['album_id'];
    }

    /**
     * Sets album_id
     * @param float $album_id 
     * @return $this
     */
    public function setAlbumId($album_id)
    {
        $this->container['album_id'] = $album_id;

        return $this;
    }

    /**
     * Gets artist_mbid
     * @return string
     */
    public function getArtistMbid()
    {
        return $this->container['artist_mbid'];
    }

    /**
     * Sets artist_mbid
     * @param string $artist_mbid 
     * @return $this
     */
    public function setArtistMbid($artist_mbid)
    {
        $this->container['artist_mbid'] = $artist_mbid;

        return $this;
    }

    /**
     * Gets secondary_genres
     * @return \Swagger\Client\Model\TrackSecondaryGenres
     */
    public function getSecondaryGenres()
    {
        return $this->container['secondary_genres'];
    }

    /**
     * Sets secondary_genres
     * @param \Swagger\Client\Model\TrackSecondaryGenres $secondary_genres
     * @return $this
     */
    public function setSecondaryGenres($secondary_genres)
    {
        $this->container['secondary_genres'] = $secondary_genres;

        return $this;
    }

    /**
     * Gets commontrack_vanity_id
     * @return string
     */
    public function getCommontrackVanityId()
    {
        return $this->container['commontrack_vanity_id'];
    }

    /**
     * Sets commontrack_vanity_id
     * @param string $commontrack_vanity_id 
     * @return $this
     */
    public function setCommontrackVanityId($commontrack_vanity_id)
    {
        $this->container['commontrack_vanity_id'] = $commontrack_vanity_id;

        return $this;
    }

    /**
     * Gets track_id
     * @return float
     */
    public function getTrackId()
    {
        return $this->container['track_id'];
    }

    /**
     * Sets track_id
     * @param float $track_id 
     * @return $this
     */
    public function setTrackId($track_id)
    {
        $this->container['track_id'] = $track_id;

        return $this;
    }

    /**
     * Gets track_xboxmusic_id
     * @return string
     */
    public function getTrackXboxmusicId()
    {
        return $this->container['track_xboxmusic_id'];
    }

    /**
     * Sets track_xboxmusic_id
     * @param string $track_xboxmusic_id 
     * @return $this
     */
    public function setTrackXboxmusicId($track_xboxmusic_id)
    {
        $this->container['track_xboxmusic_id'] = $track_xboxmusic_id;

        return $this;
    }

    /**
     * Gets primary_genres
     * @return \Swagger\Client\Model\TrackPrimaryGenres
     */
    public function getPrimaryGenres()
    {
        return $this->container['primary_genres'];
    }

    /**
     * Sets primary_genres
     * @param \Swagger\Client\Model\TrackPrimaryGenres $primary_genres
     * @return $this
     */
    public function setPrimaryGenres($primary_genres)
    {
        $this->container['primary_genres'] = $primary_genres;

        return $this;
    }

    /**
     * Gets track_length
     * @return float
     */
    public function getTrackLength()
    {
        return $this->container['track_length'];
    }

    /**
     * Sets track_length
     * @param float $track_length 
     * @return $this
     */
    public function setTrackLength($track_length)
    {
        $this->container['track_length'] = $track_length;

        return $this;
    }

    /**
     * Gets track_mbid
     * @return string
     */
    public function getTrackMbid()
    {
        return $this->container['track_mbid'];
    }

    /**
     * Sets track_mbid
     * @param string $track_mbid 
     * @return $this
     */
    public function setTrackMbid($track_mbid)
    {
        $this->container['track_mbid'] = $track_mbid;

        return $this;
    }

    /**
     * Gets commontrack_id
     * @return float
     */
    public function getCommontrackId()
    {
        return $this->container['commontrack_id'];
    }

    /**
     * Sets commontrack_id
     * @param float $commontrack_id 
     * @return $this
     */
    public function setCommontrackId($commontrack_id)
    {
        $this->container['commontrack_id'] = $commontrack_id;

        return $this;
    }
    /**
     * Returns true if offset exists. False otherwise.
     * @param  integer $offset Offset
     * @return boolean
     */
    public function offsetExists($offset)
    {
        return isset($this->container[$offset]);
    }

    /**
     * Gets offset.
     * @param  integer $offset Offset
     * @return mixed
     */
    public function offsetGet($offset)
    {
        return isset($this->container[$offset]) ? $this->container[$offset] : null;
    }

    /**
     * Sets value based on offset.
     * @param  integer $offset Offset
     * @param  mixed   $value  Value to be set
     * @return void
     */
    public function offsetSet($offset, $value)
    {
        if (is_null($offset)) {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    /**
     * Unsets offset.
     * @param  integer $offset Offset
     * @return void
     */
    public function offsetUnset($offset)
    {
        unset($this->container[$offset]);
    }

    /**
     * Gets the string presentation of the object
     * @return string
     */
    public function __toString()
    {
        if (defined('JSON_PRETTY_PRINT')) { // use JSON pretty print
            return json_encode(\Swagger\Client\ObjectSerializer::sanitizeForSerialization($this), JSON_PRETTY_PRINT);
        }

        return json_encode(\Swagger\Client\ObjectSerializer::sanitizeForSerialization($this));
    }
}


