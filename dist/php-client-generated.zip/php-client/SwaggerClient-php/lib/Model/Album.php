<?php
/**
 * Album
 *
 * PHP version 5
 *
 * @category Class
 * @package  Swagger\Client
 * @author   http://github.com/swagger-api/swagger-codegen
 * @license  http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link     https://github.com/swagger-api/swagger-codegen
 */

/**
 * Musixmatch API
 *
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen
 * Do not edit the class manually.
 */

namespace Swagger\Client\Model;

use \ArrayAccess;

/**
 * Album Class Doc Comment
 *
 * @category    Class */
 // @description a album of songs in the Musixmatch database.
/** 
 * @package     Swagger\Client
 * @author      http://github.com/swagger-api/swagger-codegen
 * @license     http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link        https://github.com/swagger-api/swagger-codegen
 */
class Album implements ArrayAccess
{
    /**
      * The original name of the model.
      * @var string
      */
    protected static $swaggerModelName = 'Album';

    /**
      * Array of property to type mappings. Used for (de)serialization
      * @var string[]
      */
    protected static $swaggerTypes = array(
        'album_coverart_500x500' => 'string',
        'restricted' => 'float',
        'artist_id' => 'float',
        'album_name' => 'string',
        'album_coverart_800x800' => 'string',
        'album_copyright' => 'string',
        'album_coverart_350x350' => 'string',
        'artist_name' => 'string',
        'primary_genres' => '\Swagger\Client\Model\AlbumPrimaryGenres',
        'album_id' => 'float',
        'album_rating' => 'float',
        'album_pline' => 'string',
        'album_track_count' => 'float',
        'album_release_type' => 'string',
        'album_release_date' => 'string',
        'album_edit_url' => 'string',
        'updated_time' => 'string',
        'secondary_genres' => '\Swagger\Client\Model\ArtistSecondaryGenres',
        'album_mbid' => 'string',
        'album_vanity_id' => 'string',
        'album_coverart_100x100' => 'string',
        'album_label' => 'string'
    );

    public static function swaggerTypes()
    {
        return self::$swaggerTypes;
    }

    /**
     * Array of attributes where the key is the local name, and the value is the original name
     * @var string[]
     */
    protected static $attributeMap = array(
        'album_coverart_500x500' => 'album_coverart_500x500',
        'restricted' => 'restricted',
        'artist_id' => 'artist_id',
        'album_name' => 'album_name',
        'album_coverart_800x800' => 'album_coverart_800x800',
        'album_copyright' => 'album_copyright',
        'album_coverart_350x350' => 'album_coverart_350x350',
        'artist_name' => 'artist_name',
        'primary_genres' => 'primary_genres',
        'album_id' => 'album_id',
        'album_rating' => 'album_rating',
        'album_pline' => 'album_pline',
        'album_track_count' => 'album_track_count',
        'album_release_type' => 'album_release_type',
        'album_release_date' => 'album_release_date',
        'album_edit_url' => 'album_edit_url',
        'updated_time' => 'updated_time',
        'secondary_genres' => 'secondary_genres',
        'album_mbid' => 'album_mbid',
        'album_vanity_id' => 'album_vanity_id',
        'album_coverart_100x100' => 'album_coverart_100x100',
        'album_label' => 'album_label'
    );

    public static function attributeMap()
    {
        return self::$attributeMap;
    }

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     * @var string[]
     */
    protected static $setters = array(
        'album_coverart_500x500' => 'setAlbumCoverart500x500',
        'restricted' => 'setRestricted',
        'artist_id' => 'setArtistId',
        'album_name' => 'setAlbumName',
        'album_coverart_800x800' => 'setAlbumCoverart800x800',
        'album_copyright' => 'setAlbumCopyright',
        'album_coverart_350x350' => 'setAlbumCoverart350x350',
        'artist_name' => 'setArtistName',
        'primary_genres' => 'setPrimaryGenres',
        'album_id' => 'setAlbumId',
        'album_rating' => 'setAlbumRating',
        'album_pline' => 'setAlbumPline',
        'album_track_count' => 'setAlbumTrackCount',
        'album_release_type' => 'setAlbumReleaseType',
        'album_release_date' => 'setAlbumReleaseDate',
        'album_edit_url' => 'setAlbumEditUrl',
        'updated_time' => 'setUpdatedTime',
        'secondary_genres' => 'setSecondaryGenres',
        'album_mbid' => 'setAlbumMbid',
        'album_vanity_id' => 'setAlbumVanityId',
        'album_coverart_100x100' => 'setAlbumCoverart100x100',
        'album_label' => 'setAlbumLabel'
    );

    public static function setters()
    {
        return self::$setters;
    }

    /**
     * Array of attributes to getter functions (for serialization of requests)
     * @var string[]
     */
    protected static $getters = array(
        'album_coverart_500x500' => 'getAlbumCoverart500x500',
        'restricted' => 'getRestricted',
        'artist_id' => 'getArtistId',
        'album_name' => 'getAlbumName',
        'album_coverart_800x800' => 'getAlbumCoverart800x800',
        'album_copyright' => 'getAlbumCopyright',
        'album_coverart_350x350' => 'getAlbumCoverart350x350',
        'artist_name' => 'getArtistName',
        'primary_genres' => 'getPrimaryGenres',
        'album_id' => 'getAlbumId',
        'album_rating' => 'getAlbumRating',
        'album_pline' => 'getAlbumPline',
        'album_track_count' => 'getAlbumTrackCount',
        'album_release_type' => 'getAlbumReleaseType',
        'album_release_date' => 'getAlbumReleaseDate',
        'album_edit_url' => 'getAlbumEditUrl',
        'updated_time' => 'getUpdatedTime',
        'secondary_genres' => 'getSecondaryGenres',
        'album_mbid' => 'getAlbumMbid',
        'album_vanity_id' => 'getAlbumVanityId',
        'album_coverart_100x100' => 'getAlbumCoverart100x100',
        'album_label' => 'getAlbumLabel'
    );

    public static function getters()
    {
        return self::$getters;
    }

    

    

    /**
     * Associative array for storing property values
     * @var mixed[]
     */
    protected $container = array();

    /**
     * Constructor
     * @param mixed[] $data Associated array of property value initalizing the model
     */
    public function __construct(array $data = null)
    {
        $this->container['album_coverart_500x500'] = isset($data['album_coverart_500x500']) ? $data['album_coverart_500x500'] : null;
        $this->container['restricted'] = isset($data['restricted']) ? $data['restricted'] : null;
        $this->container['artist_id'] = isset($data['artist_id']) ? $data['artist_id'] : null;
        $this->container['album_name'] = isset($data['album_name']) ? $data['album_name'] : null;
        $this->container['album_coverart_800x800'] = isset($data['album_coverart_800x800']) ? $data['album_coverart_800x800'] : null;
        $this->container['album_copyright'] = isset($data['album_copyright']) ? $data['album_copyright'] : null;
        $this->container['album_coverart_350x350'] = isset($data['album_coverart_350x350']) ? $data['album_coverart_350x350'] : null;
        $this->container['artist_name'] = isset($data['artist_name']) ? $data['artist_name'] : null;
        $this->container['primary_genres'] = isset($data['primary_genres']) ? $data['primary_genres'] : null;
        $this->container['album_id'] = isset($data['album_id']) ? $data['album_id'] : null;
        $this->container['album_rating'] = isset($data['album_rating']) ? $data['album_rating'] : null;
        $this->container['album_pline'] = isset($data['album_pline']) ? $data['album_pline'] : null;
        $this->container['album_track_count'] = isset($data['album_track_count']) ? $data['album_track_count'] : null;
        $this->container['album_release_type'] = isset($data['album_release_type']) ? $data['album_release_type'] : null;
        $this->container['album_release_date'] = isset($data['album_release_date']) ? $data['album_release_date'] : null;
        $this->container['album_edit_url'] = isset($data['album_edit_url']) ? $data['album_edit_url'] : null;
        $this->container['updated_time'] = isset($data['updated_time']) ? $data['updated_time'] : null;
        $this->container['secondary_genres'] = isset($data['secondary_genres']) ? $data['secondary_genres'] : null;
        $this->container['album_mbid'] = isset($data['album_mbid']) ? $data['album_mbid'] : null;
        $this->container['album_vanity_id'] = isset($data['album_vanity_id']) ? $data['album_vanity_id'] : null;
        $this->container['album_coverart_100x100'] = isset($data['album_coverart_100x100']) ? $data['album_coverart_100x100'] : null;
        $this->container['album_label'] = isset($data['album_label']) ? $data['album_label'] : null;
    }

    /**
     * show all the invalid properties with reasons.
     *
     * @return array invalid properties with reasons
     */
    public function listInvalidProperties()
    {
        $invalid_properties = array();
        return $invalid_properties;
    }

    /**
     * validate all the properties in the model
     * return true if all passed
     *
     * @return bool True if all properteis are valid
     */
    public function valid()
    {
        return true;
    }


    /**
     * Gets album_coverart_500x500
     * @return string
     */
    public function getAlbumCoverart500x500()
    {
        return $this->container['album_coverart_500x500'];
    }

    /**
     * Sets album_coverart_500x500
     * @param string $album_coverart_500x500 
     * @return $this
     */
    public function setAlbumCoverart500x500($album_coverart_500x500)
    {
        $this->container['album_coverart_500x500'] = $album_coverart_500x500;

        return $this;
    }

    /**
     * Gets restricted
     * @return float
     */
    public function getRestricted()
    {
        return $this->container['restricted'];
    }

    /**
     * Sets restricted
     * @param float $restricted 
     * @return $this
     */
    public function setRestricted($restricted)
    {
        $this->container['restricted'] = $restricted;

        return $this;
    }

    /**
     * Gets artist_id
     * @return float
     */
    public function getArtistId()
    {
        return $this->container['artist_id'];
    }

    /**
     * Sets artist_id
     * @param float $artist_id 
     * @return $this
     */
    public function setArtistId($artist_id)
    {
        $this->container['artist_id'] = $artist_id;

        return $this;
    }

    /**
     * Gets album_name
     * @return string
     */
    public function getAlbumName()
    {
        return $this->container['album_name'];
    }

    /**
     * Sets album_name
     * @param string $album_name 
     * @return $this
     */
    public function setAlbumName($album_name)
    {
        $this->container['album_name'] = $album_name;

        return $this;
    }

    /**
     * Gets album_coverart_800x800
     * @return string
     */
    public function getAlbumCoverart800x800()
    {
        return $this->container['album_coverart_800x800'];
    }

    /**
     * Sets album_coverart_800x800
     * @param string $album_coverart_800x800 
     * @return $this
     */
    public function setAlbumCoverart800x800($album_coverart_800x800)
    {
        $this->container['album_coverart_800x800'] = $album_coverart_800x800;

        return $this;
    }

    /**
     * Gets album_copyright
     * @return string
     */
    public function getAlbumCopyright()
    {
        return $this->container['album_copyright'];
    }

    /**
     * Sets album_copyright
     * @param string $album_copyright 
     * @return $this
     */
    public function setAlbumCopyright($album_copyright)
    {
        $this->container['album_copyright'] = $album_copyright;

        return $this;
    }

    /**
     * Gets album_coverart_350x350
     * @return string
     */
    public function getAlbumCoverart350x350()
    {
        return $this->container['album_coverart_350x350'];
    }

    /**
     * Sets album_coverart_350x350
     * @param string $album_coverart_350x350 
     * @return $this
     */
    public function setAlbumCoverart350x350($album_coverart_350x350)
    {
        $this->container['album_coverart_350x350'] = $album_coverart_350x350;

        return $this;
    }

    /**
     * Gets artist_name
     * @return string
     */
    public function getArtistName()
    {
        return $this->container['artist_name'];
    }

    /**
     * Sets artist_name
     * @param string $artist_name 
     * @return $this
     */
    public function setArtistName($artist_name)
    {
        $this->container['artist_name'] = $artist_name;

        return $this;
    }

    /**
     * Gets primary_genres
     * @return \Swagger\Client\Model\AlbumPrimaryGenres
     */
    public function getPrimaryGenres()
    {
        return $this->container['primary_genres'];
    }

    /**
     * Sets primary_genres
     * @param \Swagger\Client\Model\AlbumPrimaryGenres $primary_genres
     * @return $this
     */
    public function setPrimaryGenres($primary_genres)
    {
        $this->container['primary_genres'] = $primary_genres;

        return $this;
    }

    /**
     * Gets album_id
     * @return float
     */
    public function getAlbumId()
    {
        return $this->container['album_id'];
    }

    /**
     * Sets album_id
     * @param float $album_id 
     * @return $this
     */
    public function setAlbumId($album_id)
    {
        $this->container['album_id'] = $album_id;

        return $this;
    }

    /**
     * Gets album_rating
     * @return float
     */
    public function getAlbumRating()
    {
        return $this->container['album_rating'];
    }

    /**
     * Sets album_rating
     * @param float $album_rating 
     * @return $this
     */
    public function setAlbumRating($album_rating)
    {
        $this->container['album_rating'] = $album_rating;

        return $this;
    }

    /**
     * Gets album_pline
     * @return string
     */
    public function getAlbumPline()
    {
        return $this->container['album_pline'];
    }

    /**
     * Sets album_pline
     * @param string $album_pline 
     * @return $this
     */
    public function setAlbumPline($album_pline)
    {
        $this->container['album_pline'] = $album_pline;

        return $this;
    }

    /**
     * Gets album_track_count
     * @return float
     */
    public function getAlbumTrackCount()
    {
        return $this->container['album_track_count'];
    }

    /**
     * Sets album_track_count
     * @param float $album_track_count 
     * @return $this
     */
    public function setAlbumTrackCount($album_track_count)
    {
        $this->container['album_track_count'] = $album_track_count;

        return $this;
    }

    /**
     * Gets album_release_type
     * @return string
     */
    public function getAlbumReleaseType()
    {
        return $this->container['album_release_type'];
    }

    /**
     * Sets album_release_type
     * @param string $album_release_type 
     * @return $this
     */
    public function setAlbumReleaseType($album_release_type)
    {
        $this->container['album_release_type'] = $album_release_type;

        return $this;
    }

    /**
     * Gets album_release_date
     * @return string
     */
    public function getAlbumReleaseDate()
    {
        return $this->container['album_release_date'];
    }

    /**
     * Sets album_release_date
     * @param string $album_release_date 
     * @return $this
     */
    public function setAlbumReleaseDate($album_release_date)
    {
        $this->container['album_release_date'] = $album_release_date;

        return $this;
    }

    /**
     * Gets album_edit_url
     * @return string
     */
    public function getAlbumEditUrl()
    {
        return $this->container['album_edit_url'];
    }

    /**
     * Sets album_edit_url
     * @param string $album_edit_url 
     * @return $this
     */
    public function setAlbumEditUrl($album_edit_url)
    {
        $this->container['album_edit_url'] = $album_edit_url;

        return $this;
    }

    /**
     * Gets updated_time
     * @return string
     */
    public function getUpdatedTime()
    {
        return $this->container['updated_time'];
    }

    /**
     * Sets updated_time
     * @param string $updated_time 
     * @return $this
     */
    public function setUpdatedTime($updated_time)
    {
        $this->container['updated_time'] = $updated_time;

        return $this;
    }

    /**
     * Gets secondary_genres
     * @return \Swagger\Client\Model\ArtistSecondaryGenres
     */
    public function getSecondaryGenres()
    {
        return $this->container['secondary_genres'];
    }

    /**
     * Sets secondary_genres
     * @param \Swagger\Client\Model\ArtistSecondaryGenres $secondary_genres
     * @return $this
     */
    public function setSecondaryGenres($secondary_genres)
    {
        $this->container['secondary_genres'] = $secondary_genres;

        return $this;
    }

    /**
     * Gets album_mbid
     * @return string
     */
    public function getAlbumMbid()
    {
        return $this->container['album_mbid'];
    }

    /**
     * Sets album_mbid
     * @param string $album_mbid 
     * @return $this
     */
    public function setAlbumMbid($album_mbid)
    {
        $this->container['album_mbid'] = $album_mbid;

        return $this;
    }

    /**
     * Gets album_vanity_id
     * @return string
     */
    public function getAlbumVanityId()
    {
        return $this->container['album_vanity_id'];
    }

    /**
     * Sets album_vanity_id
     * @param string $album_vanity_id 
     * @return $this
     */
    public function setAlbumVanityId($album_vanity_id)
    {
        $this->container['album_vanity_id'] = $album_vanity_id;

        return $this;
    }

    /**
     * Gets album_coverart_100x100
     * @return string
     */
    public function getAlbumCoverart100x100()
    {
        return $this->container['album_coverart_100x100'];
    }

    /**
     * Sets album_coverart_100x100
     * @param string $album_coverart_100x100 
     * @return $this
     */
    public function setAlbumCoverart100x100($album_coverart_100x100)
    {
        $this->container['album_coverart_100x100'] = $album_coverart_100x100;

        return $this;
    }

    /**
     * Gets album_label
     * @return string
     */
    public function getAlbumLabel()
    {
        return $this->container['album_label'];
    }

    /**
     * Sets album_label
     * @param string $album_label 
     * @return $this
     */
    public function setAlbumLabel($album_label)
    {
        $this->container['album_label'] = $album_label;

        return $this;
    }
    /**
     * Returns true if offset exists. False otherwise.
     * @param  integer $offset Offset
     * @return boolean
     */
    public function offsetExists($offset)
    {
        return isset($this->container[$offset]);
    }

    /**
     * Gets offset.
     * @param  integer $offset Offset
     * @return mixed
     */
    public function offsetGet($offset)
    {
        return isset($this->container[$offset]) ? $this->container[$offset] : null;
    }

    /**
     * Sets value based on offset.
     * @param  integer $offset Offset
     * @param  mixed   $value  Value to be set
     * @return void
     */
    public function offsetSet($offset, $value)
    {
        if (is_null($offset)) {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    /**
     * Unsets offset.
     * @param  integer $offset Offset
     * @return void
     */
    public function offsetUnset($offset)
    {
        unset($this->container[$offset]);
    }

    /**
     * Gets the string presentation of the object
     * @return string
     */
    public function __toString()
    {
        if (defined('JSON_PRETTY_PRINT')) { // use JSON pretty print
            return json_encode(\Swagger\Client\ObjectSerializer::sanitizeForSerialization($this), JSON_PRETTY_PRINT);
        }

        return json_encode(\Swagger\Client\ObjectSerializer::sanitizeForSerialization($this));
    }
}


