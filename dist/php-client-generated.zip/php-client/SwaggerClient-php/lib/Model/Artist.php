<?php
/**
 * Artist
 *
 * PHP version 5
 *
 * @category Class
 * @package  Swagger\Client
 * @author   http://github.com/swagger-api/swagger-codegen
 * @license  http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link     https://github.com/swagger-api/swagger-codegen
 */

/**
 * Musixmatch API
 *
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen
 * Do not edit the class manually.
 */

namespace Swagger\Client\Model;

use \ArrayAccess;

/**
 * Artist Class Doc Comment
 *
 * @category    Class */
 // @description a artist in the Musixmatch database.
/** 
 * @package     Swagger\Client
 * @author      http://github.com/swagger-api/swagger-codegen
 * @license     http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link        https://github.com/swagger-api/swagger-codegen
 */
class Artist implements ArrayAccess
{
    /**
      * The original name of the model.
      * @var string
      */
    protected static $swaggerModelName = 'Artist';

    /**
      * Array of property to type mappings. Used for (de)serialization
      * @var string[]
      */
    protected static $swaggerTypes = array(
        'artist_credits' => '\Swagger\Client\Model\ArtistArtistCredits',
        'artist_mbid' => 'string',
        'artist_name' => 'string',
        'secondary_genres' => '\Swagger\Client\Model\ArtistSecondaryGenres',
        'artist_alias_list' => '\Swagger\Client\Model\ArtistArtistAliasList[]',
        'artist_vanity_id' => 'string',
        'restricted' => 'float',
        'artist_country' => 'string',
        'artist_comment' => 'string',
        'artist_name_translation_list' => '\Swagger\Client\Model\ArtistArtistNameTranslationList[]',
        'artist_edit_url' => 'string',
        'artist_share_url' => 'string',
        'artist_id' => 'float',
        'updated_time' => 'string',
        'managed' => 'float',
        'primary_genres' => '\Swagger\Client\Model\ArtistPrimaryGenres',
        'artist_twitter_url' => 'string',
        'artist_rating' => 'float'
    );

    public static function swaggerTypes()
    {
        return self::$swaggerTypes;
    }

    /**
     * Array of attributes where the key is the local name, and the value is the original name
     * @var string[]
     */
    protected static $attributeMap = array(
        'artist_credits' => 'artist_credits',
        'artist_mbid' => 'artist_mbid',
        'artist_name' => 'artist_name',
        'secondary_genres' => 'secondary_genres',
        'artist_alias_list' => 'artist_alias_list',
        'artist_vanity_id' => 'artist_vanity_id',
        'restricted' => 'restricted',
        'artist_country' => 'artist_country',
        'artist_comment' => 'artist_comment',
        'artist_name_translation_list' => 'artist_name_translation_list',
        'artist_edit_url' => 'artist_edit_url',
        'artist_share_url' => 'artist_share_url',
        'artist_id' => 'artist_id',
        'updated_time' => 'updated_time',
        'managed' => 'managed',
        'primary_genres' => 'primary_genres',
        'artist_twitter_url' => 'artist_twitter_url',
        'artist_rating' => 'artist_rating'
    );

    public static function attributeMap()
    {
        return self::$attributeMap;
    }

    /**
     * Array of attributes to setter functions (for deserialization of responses)
     * @var string[]
     */
    protected static $setters = array(
        'artist_credits' => 'setArtistCredits',
        'artist_mbid' => 'setArtistMbid',
        'artist_name' => 'setArtistName',
        'secondary_genres' => 'setSecondaryGenres',
        'artist_alias_list' => 'setArtistAliasList',
        'artist_vanity_id' => 'setArtistVanityId',
        'restricted' => 'setRestricted',
        'artist_country' => 'setArtistCountry',
        'artist_comment' => 'setArtistComment',
        'artist_name_translation_list' => 'setArtistNameTranslationList',
        'artist_edit_url' => 'setArtistEditUrl',
        'artist_share_url' => 'setArtistShareUrl',
        'artist_id' => 'setArtistId',
        'updated_time' => 'setUpdatedTime',
        'managed' => 'setManaged',
        'primary_genres' => 'setPrimaryGenres',
        'artist_twitter_url' => 'setArtistTwitterUrl',
        'artist_rating' => 'setArtistRating'
    );

    public static function setters()
    {
        return self::$setters;
    }

    /**
     * Array of attributes to getter functions (for serialization of requests)
     * @var string[]
     */
    protected static $getters = array(
        'artist_credits' => 'getArtistCredits',
        'artist_mbid' => 'getArtistMbid',
        'artist_name' => 'getArtistName',
        'secondary_genres' => 'getSecondaryGenres',
        'artist_alias_list' => 'getArtistAliasList',
        'artist_vanity_id' => 'getArtistVanityId',
        'restricted' => 'getRestricted',
        'artist_country' => 'getArtistCountry',
        'artist_comment' => 'getArtistComment',
        'artist_name_translation_list' => 'getArtistNameTranslationList',
        'artist_edit_url' => 'getArtistEditUrl',
        'artist_share_url' => 'getArtistShareUrl',
        'artist_id' => 'getArtistId',
        'updated_time' => 'getUpdatedTime',
        'managed' => 'getManaged',
        'primary_genres' => 'getPrimaryGenres',
        'artist_twitter_url' => 'getArtistTwitterUrl',
        'artist_rating' => 'getArtistRating'
    );

    public static function getters()
    {
        return self::$getters;
    }

    

    

    /**
     * Associative array for storing property values
     * @var mixed[]
     */
    protected $container = array();

    /**
     * Constructor
     * @param mixed[] $data Associated array of property value initalizing the model
     */
    public function __construct(array $data = null)
    {
        $this->container['artist_credits'] = isset($data['artist_credits']) ? $data['artist_credits'] : null;
        $this->container['artist_mbid'] = isset($data['artist_mbid']) ? $data['artist_mbid'] : null;
        $this->container['artist_name'] = isset($data['artist_name']) ? $data['artist_name'] : null;
        $this->container['secondary_genres'] = isset($data['secondary_genres']) ? $data['secondary_genres'] : null;
        $this->container['artist_alias_list'] = isset($data['artist_alias_list']) ? $data['artist_alias_list'] : null;
        $this->container['artist_vanity_id'] = isset($data['artist_vanity_id']) ? $data['artist_vanity_id'] : null;
        $this->container['restricted'] = isset($data['restricted']) ? $data['restricted'] : null;
        $this->container['artist_country'] = isset($data['artist_country']) ? $data['artist_country'] : null;
        $this->container['artist_comment'] = isset($data['artist_comment']) ? $data['artist_comment'] : null;
        $this->container['artist_name_translation_list'] = isset($data['artist_name_translation_list']) ? $data['artist_name_translation_list'] : null;
        $this->container['artist_edit_url'] = isset($data['artist_edit_url']) ? $data['artist_edit_url'] : null;
        $this->container['artist_share_url'] = isset($data['artist_share_url']) ? $data['artist_share_url'] : null;
        $this->container['artist_id'] = isset($data['artist_id']) ? $data['artist_id'] : null;
        $this->container['updated_time'] = isset($data['updated_time']) ? $data['updated_time'] : null;
        $this->container['managed'] = isset($data['managed']) ? $data['managed'] : null;
        $this->container['primary_genres'] = isset($data['primary_genres']) ? $data['primary_genres'] : null;
        $this->container['artist_twitter_url'] = isset($data['artist_twitter_url']) ? $data['artist_twitter_url'] : null;
        $this->container['artist_rating'] = isset($data['artist_rating']) ? $data['artist_rating'] : null;
    }

    /**
     * show all the invalid properties with reasons.
     *
     * @return array invalid properties with reasons
     */
    public function listInvalidProperties()
    {
        $invalid_properties = array();
        return $invalid_properties;
    }

    /**
     * validate all the properties in the model
     * return true if all passed
     *
     * @return bool True if all properteis are valid
     */
    public function valid()
    {
        return true;
    }


    /**
     * Gets artist_credits
     * @return \Swagger\Client\Model\ArtistArtistCredits
     */
    public function getArtistCredits()
    {
        return $this->container['artist_credits'];
    }

    /**
     * Sets artist_credits
     * @param \Swagger\Client\Model\ArtistArtistCredits $artist_credits
     * @return $this
     */
    public function setArtistCredits($artist_credits)
    {
        $this->container['artist_credits'] = $artist_credits;

        return $this;
    }

    /**
     * Gets artist_mbid
     * @return string
     */
    public function getArtistMbid()
    {
        return $this->container['artist_mbid'];
    }

    /**
     * Sets artist_mbid
     * @param string $artist_mbid 
     * @return $this
     */
    public function setArtistMbid($artist_mbid)
    {
        $this->container['artist_mbid'] = $artist_mbid;

        return $this;
    }

    /**
     * Gets artist_name
     * @return string
     */
    public function getArtistName()
    {
        return $this->container['artist_name'];
    }

    /**
     * Sets artist_name
     * @param string $artist_name 
     * @return $this
     */
    public function setArtistName($artist_name)
    {
        $this->container['artist_name'] = $artist_name;

        return $this;
    }

    /**
     * Gets secondary_genres
     * @return \Swagger\Client\Model\ArtistSecondaryGenres
     */
    public function getSecondaryGenres()
    {
        return $this->container['secondary_genres'];
    }

    /**
     * Sets secondary_genres
     * @param \Swagger\Client\Model\ArtistSecondaryGenres $secondary_genres
     * @return $this
     */
    public function setSecondaryGenres($secondary_genres)
    {
        $this->container['secondary_genres'] = $secondary_genres;

        return $this;
    }

    /**
     * Gets artist_alias_list
     * @return \Swagger\Client\Model\ArtistArtistAliasList[]
     */
    public function getArtistAliasList()
    {
        return $this->container['artist_alias_list'];
    }

    /**
     * Sets artist_alias_list
     * @param \Swagger\Client\Model\ArtistArtistAliasList[] $artist_alias_list
     * @return $this
     */
    public function setArtistAliasList($artist_alias_list)
    {
        $this->container['artist_alias_list'] = $artist_alias_list;

        return $this;
    }

    /**
     * Gets artist_vanity_id
     * @return string
     */
    public function getArtistVanityId()
    {
        return $this->container['artist_vanity_id'];
    }

    /**
     * Sets artist_vanity_id
     * @param string $artist_vanity_id 
     * @return $this
     */
    public function setArtistVanityId($artist_vanity_id)
    {
        $this->container['artist_vanity_id'] = $artist_vanity_id;

        return $this;
    }

    /**
     * Gets restricted
     * @return float
     */
    public function getRestricted()
    {
        return $this->container['restricted'];
    }

    /**
     * Sets restricted
     * @param float $restricted 
     * @return $this
     */
    public function setRestricted($restricted)
    {
        $this->container['restricted'] = $restricted;

        return $this;
    }

    /**
     * Gets artist_country
     * @return string
     */
    public function getArtistCountry()
    {
        return $this->container['artist_country'];
    }

    /**
     * Sets artist_country
     * @param string $artist_country 
     * @return $this
     */
    public function setArtistCountry($artist_country)
    {
        $this->container['artist_country'] = $artist_country;

        return $this;
    }

    /**
     * Gets artist_comment
     * @return string
     */
    public function getArtistComment()
    {
        return $this->container['artist_comment'];
    }

    /**
     * Sets artist_comment
     * @param string $artist_comment 
     * @return $this
     */
    public function setArtistComment($artist_comment)
    {
        $this->container['artist_comment'] = $artist_comment;

        return $this;
    }

    /**
     * Gets artist_name_translation_list
     * @return \Swagger\Client\Model\ArtistArtistNameTranslationList[]
     */
    public function getArtistNameTranslationList()
    {
        return $this->container['artist_name_translation_list'];
    }

    /**
     * Sets artist_name_translation_list
     * @param \Swagger\Client\Model\ArtistArtistNameTranslationList[] $artist_name_translation_list
     * @return $this
     */
    public function setArtistNameTranslationList($artist_name_translation_list)
    {
        $this->container['artist_name_translation_list'] = $artist_name_translation_list;

        return $this;
    }

    /**
     * Gets artist_edit_url
     * @return string
     */
    public function getArtistEditUrl()
    {
        return $this->container['artist_edit_url'];
    }

    /**
     * Sets artist_edit_url
     * @param string $artist_edit_url 
     * @return $this
     */
    public function setArtistEditUrl($artist_edit_url)
    {
        $this->container['artist_edit_url'] = $artist_edit_url;

        return $this;
    }

    /**
     * Gets artist_share_url
     * @return string
     */
    public function getArtistShareUrl()
    {
        return $this->container['artist_share_url'];
    }

    /**
     * Sets artist_share_url
     * @param string $artist_share_url 
     * @return $this
     */
    public function setArtistShareUrl($artist_share_url)
    {
        $this->container['artist_share_url'] = $artist_share_url;

        return $this;
    }

    /**
     * Gets artist_id
     * @return float
     */
    public function getArtistId()
    {
        return $this->container['artist_id'];
    }

    /**
     * Sets artist_id
     * @param float $artist_id 
     * @return $this
     */
    public function setArtistId($artist_id)
    {
        $this->container['artist_id'] = $artist_id;

        return $this;
    }

    /**
     * Gets updated_time
     * @return string
     */
    public function getUpdatedTime()
    {
        return $this->container['updated_time'];
    }

    /**
     * Sets updated_time
     * @param string $updated_time 
     * @return $this
     */
    public function setUpdatedTime($updated_time)
    {
        $this->container['updated_time'] = $updated_time;

        return $this;
    }

    /**
     * Gets managed
     * @return float
     */
    public function getManaged()
    {
        return $this->container['managed'];
    }

    /**
     * Sets managed
     * @param float $managed 
     * @return $this
     */
    public function setManaged($managed)
    {
        $this->container['managed'] = $managed;

        return $this;
    }

    /**
     * Gets primary_genres
     * @return \Swagger\Client\Model\ArtistPrimaryGenres
     */
    public function getPrimaryGenres()
    {
        return $this->container['primary_genres'];
    }

    /**
     * Sets primary_genres
     * @param \Swagger\Client\Model\ArtistPrimaryGenres $primary_genres
     * @return $this
     */
    public function setPrimaryGenres($primary_genres)
    {
        $this->container['primary_genres'] = $primary_genres;

        return $this;
    }

    /**
     * Gets artist_twitter_url
     * @return string
     */
    public function getArtistTwitterUrl()
    {
        return $this->container['artist_twitter_url'];
    }

    /**
     * Sets artist_twitter_url
     * @param string $artist_twitter_url 
     * @return $this
     */
    public function setArtistTwitterUrl($artist_twitter_url)
    {
        $this->container['artist_twitter_url'] = $artist_twitter_url;

        return $this;
    }

    /**
     * Gets artist_rating
     * @return float
     */
    public function getArtistRating()
    {
        return $this->container['artist_rating'];
    }

    /**
     * Sets artist_rating
     * @param float $artist_rating 
     * @return $this
     */
    public function setArtistRating($artist_rating)
    {
        $this->container['artist_rating'] = $artist_rating;

        return $this;
    }
    /**
     * Returns true if offset exists. False otherwise.
     * @param  integer $offset Offset
     * @return boolean
     */
    public function offsetExists($offset)
    {
        return isset($this->container[$offset]);
    }

    /**
     * Gets offset.
     * @param  integer $offset Offset
     * @return mixed
     */
    public function offsetGet($offset)
    {
        return isset($this->container[$offset]) ? $this->container[$offset] : null;
    }

    /**
     * Sets value based on offset.
     * @param  integer $offset Offset
     * @param  mixed   $value  Value to be set
     * @return void
     */
    public function offsetSet($offset, $value)
    {
        if (is_null($offset)) {
            $this->container[] = $value;
        } else {
            $this->container[$offset] = $value;
        }
    }

    /**
     * Unsets offset.
     * @param  integer $offset Offset
     * @return void
     */
    public function offsetUnset($offset)
    {
        unset($this->container[$offset]);
    }

    /**
     * Gets the string presentation of the object
     * @return string
     */
    public function __toString()
    {
        if (defined('JSON_PRETTY_PRINT')) { // use JSON pretty print
            return json_encode(\Swagger\Client\ObjectSerializer::sanitizeForSerialization($this), JSON_PRETTY_PRINT);
        }

        return json_encode(\Swagger\Client\ObjectSerializer::sanitizeForSerialization($this));
    }
}


