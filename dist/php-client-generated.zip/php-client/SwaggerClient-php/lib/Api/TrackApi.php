<?php
/**
 * TrackApi
 * PHP version 5
 *
 * @category Class
 * @package  Swagger\Client
 * @author   http://github.com/swagger-api/swagger-codegen
 * @license  http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link     https://github.com/swagger-api/swagger-codegen
 */

/**
 * Musixmatch API
 *
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen
 * Do not edit the class manually.
 */

namespace Swagger\Client\Api;

use \Swagger\Client\Configuration;
use \Swagger\Client\ApiClient;
use \Swagger\Client\ApiException;
use \Swagger\Client\ObjectSerializer;

/**
 * TrackApi Class Doc Comment
 *
 * @category Class
 * @package  Swagger\Client
 * @author   http://github.com/swagger-api/swagger-codegen
 * @license  http://www.apache.org/licenses/LICENSE-2.0 Apache Licene v2
 * @link     https://github.com/swagger-api/swagger-codegen
 */
class TrackApi
{

    /**
     * API Client
     *
     * @var \Swagger\Client\ApiClient instance of the ApiClient
     */
    protected $apiClient;

    /**
     * Constructor
     *
     * @param \Swagger\Client\ApiClient|null $apiClient The api client to use
     */
    public function __construct(\Swagger\Client\ApiClient $apiClient = null)
    {
        if ($apiClient == null) {
            $apiClient = new ApiClient();
            $apiClient->getConfig()->setHost('https://api.musixmatch.com/ws/1.1');
        }

        $this->apiClient = $apiClient;
    }

    /**
     * Get API client
     *
     * @return \Swagger\Client\ApiClient get the API client
     */
    public function getApiClient()
    {
        return $this->apiClient;
    }

    /**
     * Set the API client
     *
     * @param \Swagger\Client\ApiClient $apiClient set the API client
     *
     * @return TrackApi
     */
    public function setApiClient(\Swagger\Client\ApiClient $apiClient)
    {
        $this->apiClient = $apiClient;
        return $this;
    }

    /**
     * Operation albumTracksGetGet
     *
     * 
     *
     * @param string $album_id The musiXmatch album id (required)
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @param string $f_has_lyrics When set, filter only contents with lyrics (optional)
     * @param float $page Define the page number for paginated results (optional)
     * @param float $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
     * @return \Swagger\Client\Model\InlineResponse2001
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function albumTracksGetGet($album_id, $format = null, $callback = null, $f_has_lyrics = null, $page = null, $page_size = null)
    {
        list($response) = $this->albumTracksGetGetWithHttpInfo($album_id, $format, $callback, $f_has_lyrics, $page, $page_size);
        return $response;
    }

    /**
     * Operation albumTracksGetGetWithHttpInfo
     *
     * 
     *
     * @param string $album_id The musiXmatch album id (required)
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @param string $f_has_lyrics When set, filter only contents with lyrics (optional)
     * @param float $page Define the page number for paginated results (optional)
     * @param float $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
     * @return Array of \Swagger\Client\Model\InlineResponse2001, HTTP status code, HTTP response headers (array of strings)
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function albumTracksGetGetWithHttpInfo($album_id, $format = null, $callback = null, $f_has_lyrics = null, $page = null, $page_size = null)
    {
        // verify the required parameter 'album_id' is set
        if ($album_id === null) {
            throw new \InvalidArgumentException('Missing the required parameter $album_id when calling albumTracksGetGet');
        }
        // parse inputs
        $resourcePath = "/album.tracks.get";
        $httpBody = '';
        $queryParams = array();
        $headerParams = array();
        $formParams = array();
        $_header_accept = $this->apiClient->selectHeaderAccept(array('application/json'));
        if (!is_null($_header_accept)) {
            $headerParams['Accept'] = $_header_accept;
        }
        $headerParams['Content-Type'] = $this->apiClient->selectHeaderContentType(array('application/json'));

        // query params
        if ($format !== null) {
            $queryParams['format'] = $this->apiClient->getSerializer()->toQueryValue($format);
        }
        // query params
        if ($callback !== null) {
            $queryParams['callback'] = $this->apiClient->getSerializer()->toQueryValue($callback);
        }
        // query params
        if ($album_id !== null) {
            $queryParams['album_id'] = $this->apiClient->getSerializer()->toQueryValue($album_id);
        }
        // query params
        if ($f_has_lyrics !== null) {
            $queryParams['f_has_lyrics'] = $this->apiClient->getSerializer()->toQueryValue($f_has_lyrics);
        }
        // query params
        if ($page !== null) {
            $queryParams['page'] = $this->apiClient->getSerializer()->toQueryValue($page);
        }
        // query params
        if ($page_size !== null) {
            $queryParams['page_size'] = $this->apiClient->getSerializer()->toQueryValue($page_size);
        }
        // default format to json
        $resourcePath = str_replace("{format}", "json", $resourcePath);

        
        // for model (json/xml)
        if (isset($_tempBody)) {
            $httpBody = $_tempBody; // $_tempBody is the method argument, if present
        } elseif (count($formParams) > 0) {
            $httpBody = $formParams; // for HTTP post (form)
        }
        // this endpoint requires API key authentication
        $apiKey = $this->apiClient->getApiKeyWithPrefix('apikey');
        if (strlen($apiKey) !== 0) {
            $queryParams['apikey'] = $apiKey;
        }
        // make the API Call
        try {
            list($response, $statusCode, $httpHeader) = $this->apiClient->callApi(
                $resourcePath,
                'GET',
                $queryParams,
                $httpBody,
                $headerParams,
                '\Swagger\Client\Model\InlineResponse2001',
                '/album.tracks.get'
            );

            return array($this->apiClient->getSerializer()->deserialize($response, '\Swagger\Client\Model\InlineResponse2001', $httpHeader), $statusCode, $httpHeader);
        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = $this->apiClient->getSerializer()->deserialize($e->getResponseBody(), '\Swagger\Client\Model\InlineResponse2001', $e->getResponseHeaders());
                    $e->setResponseObject($data);
                    break;
            }

            throw $e;
        }
    }

    /**
     * Operation chartTracksGetGet
     *
     * 
     *
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @param float $page Define the page number for paginated results (optional)
     * @param float $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param string $country A valid ISO 3166 country code (optional, default to us)
     * @param string $f_has_lyrics When set, filter only contents with lyrics (optional)
     * @return \Swagger\Client\Model\InlineResponse2006
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function chartTracksGetGet($format = null, $callback = null, $page = null, $page_size = null, $country = null, $f_has_lyrics = null)
    {
        list($response) = $this->chartTracksGetGetWithHttpInfo($format, $callback, $page, $page_size, $country, $f_has_lyrics);
        return $response;
    }

    /**
     * Operation chartTracksGetGetWithHttpInfo
     *
     * 
     *
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @param float $page Define the page number for paginated results (optional)
     * @param float $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param string $country A valid ISO 3166 country code (optional, default to us)
     * @param string $f_has_lyrics When set, filter only contents with lyrics (optional)
     * @return Array of \Swagger\Client\Model\InlineResponse2006, HTTP status code, HTTP response headers (array of strings)
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function chartTracksGetGetWithHttpInfo($format = null, $callback = null, $page = null, $page_size = null, $country = null, $f_has_lyrics = null)
    {
        // parse inputs
        $resourcePath = "/chart.tracks.get";
        $httpBody = '';
        $queryParams = array();
        $headerParams = array();
        $formParams = array();
        $_header_accept = $this->apiClient->selectHeaderAccept(array('application/json'));
        if (!is_null($_header_accept)) {
            $headerParams['Accept'] = $_header_accept;
        }
        $headerParams['Content-Type'] = $this->apiClient->selectHeaderContentType(array('application/json'));

        // query params
        if ($format !== null) {
            $queryParams['format'] = $this->apiClient->getSerializer()->toQueryValue($format);
        }
        // query params
        if ($callback !== null) {
            $queryParams['callback'] = $this->apiClient->getSerializer()->toQueryValue($callback);
        }
        // query params
        if ($page !== null) {
            $queryParams['page'] = $this->apiClient->getSerializer()->toQueryValue($page);
        }
        // query params
        if ($page_size !== null) {
            $queryParams['page_size'] = $this->apiClient->getSerializer()->toQueryValue($page_size);
        }
        // query params
        if ($country !== null) {
            $queryParams['country'] = $this->apiClient->getSerializer()->toQueryValue($country);
        }
        // query params
        if ($f_has_lyrics !== null) {
            $queryParams['f_has_lyrics'] = $this->apiClient->getSerializer()->toQueryValue($f_has_lyrics);
        }
        // default format to json
        $resourcePath = str_replace("{format}", "json", $resourcePath);

        
        // for model (json/xml)
        if (isset($_tempBody)) {
            $httpBody = $_tempBody; // $_tempBody is the method argument, if present
        } elseif (count($formParams) > 0) {
            $httpBody = $formParams; // for HTTP post (form)
        }
        // this endpoint requires API key authentication
        $apiKey = $this->apiClient->getApiKeyWithPrefix('apikey');
        if (strlen($apiKey) !== 0) {
            $queryParams['apikey'] = $apiKey;
        }
        // make the API Call
        try {
            list($response, $statusCode, $httpHeader) = $this->apiClient->callApi(
                $resourcePath,
                'GET',
                $queryParams,
                $httpBody,
                $headerParams,
                '\Swagger\Client\Model\InlineResponse2006',
                '/chart.tracks.get'
            );

            return array($this->apiClient->getSerializer()->deserialize($response, '\Swagger\Client\Model\InlineResponse2006', $httpHeader), $statusCode, $httpHeader);
        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = $this->apiClient->getSerializer()->deserialize($e->getResponseBody(), '\Swagger\Client\Model\InlineResponse2006', $e->getResponseHeaders());
                    $e->setResponseObject($data);
                    break;
            }

            throw $e;
        }
    }

    /**
     * Operation matcherTrackGetGet
     *
     * 
     *
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @param string $q_artist The song artist (optional)
     * @param string $q_track The song title (optional)
     * @param float $f_has_lyrics When set, filter only contents with lyrics (optional)
     * @param float $f_has_subtitle When set, filter only contents with subtitles (optional)
     * @return \Swagger\Client\Model\InlineResponse2009
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function matcherTrackGetGet($format = null, $callback = null, $q_artist = null, $q_track = null, $f_has_lyrics = null, $f_has_subtitle = null)
    {
        list($response) = $this->matcherTrackGetGetWithHttpInfo($format, $callback, $q_artist, $q_track, $f_has_lyrics, $f_has_subtitle);
        return $response;
    }

    /**
     * Operation matcherTrackGetGetWithHttpInfo
     *
     * 
     *
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @param string $q_artist The song artist (optional)
     * @param string $q_track The song title (optional)
     * @param float $f_has_lyrics When set, filter only contents with lyrics (optional)
     * @param float $f_has_subtitle When set, filter only contents with subtitles (optional)
     * @return Array of \Swagger\Client\Model\InlineResponse2009, HTTP status code, HTTP response headers (array of strings)
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function matcherTrackGetGetWithHttpInfo($format = null, $callback = null, $q_artist = null, $q_track = null, $f_has_lyrics = null, $f_has_subtitle = null)
    {
        // parse inputs
        $resourcePath = "/matcher.track.get";
        $httpBody = '';
        $queryParams = array();
        $headerParams = array();
        $formParams = array();
        $_header_accept = $this->apiClient->selectHeaderAccept(array('application/json'));
        if (!is_null($_header_accept)) {
            $headerParams['Accept'] = $_header_accept;
        }
        $headerParams['Content-Type'] = $this->apiClient->selectHeaderContentType(array('application/json'));

        // query params
        if ($format !== null) {
            $queryParams['format'] = $this->apiClient->getSerializer()->toQueryValue($format);
        }
        // query params
        if ($callback !== null) {
            $queryParams['callback'] = $this->apiClient->getSerializer()->toQueryValue($callback);
        }
        // query params
        if ($q_artist !== null) {
            $queryParams['q_artist'] = $this->apiClient->getSerializer()->toQueryValue($q_artist);
        }
        // query params
        if ($q_track !== null) {
            $queryParams['q_track'] = $this->apiClient->getSerializer()->toQueryValue($q_track);
        }
        // query params
        if ($f_has_lyrics !== null) {
            $queryParams['f_has_lyrics'] = $this->apiClient->getSerializer()->toQueryValue($f_has_lyrics);
        }
        // query params
        if ($f_has_subtitle !== null) {
            $queryParams['f_has_subtitle'] = $this->apiClient->getSerializer()->toQueryValue($f_has_subtitle);
        }
        // default format to json
        $resourcePath = str_replace("{format}", "json", $resourcePath);

        
        // for model (json/xml)
        if (isset($_tempBody)) {
            $httpBody = $_tempBody; // $_tempBody is the method argument, if present
        } elseif (count($formParams) > 0) {
            $httpBody = $formParams; // for HTTP post (form)
        }
        // this endpoint requires API key authentication
        $apiKey = $this->apiClient->getApiKeyWithPrefix('apikey');
        if (strlen($apiKey) !== 0) {
            $queryParams['apikey'] = $apiKey;
        }
        // make the API Call
        try {
            list($response, $statusCode, $httpHeader) = $this->apiClient->callApi(
                $resourcePath,
                'GET',
                $queryParams,
                $httpBody,
                $headerParams,
                '\Swagger\Client\Model\InlineResponse2009',
                '/matcher.track.get'
            );

            return array($this->apiClient->getSerializer()->deserialize($response, '\Swagger\Client\Model\InlineResponse2009', $httpHeader), $statusCode, $httpHeader);
        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = $this->apiClient->getSerializer()->deserialize($e->getResponseBody(), '\Swagger\Client\Model\InlineResponse2009', $e->getResponseHeaders());
                    $e->setResponseObject($data);
                    break;
            }

            throw $e;
        }
    }

    /**
     * Operation trackGetGet
     *
     * 
     *
     * @param string $track_id The musiXmatch track id (required)
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @return \Swagger\Client\Model\InlineResponse2009
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function trackGetGet($track_id, $format = null, $callback = null)
    {
        list($response) = $this->trackGetGetWithHttpInfo($track_id, $format, $callback);
        return $response;
    }

    /**
     * Operation trackGetGetWithHttpInfo
     *
     * 
     *
     * @param string $track_id The musiXmatch track id (required)
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @return Array of \Swagger\Client\Model\InlineResponse2009, HTTP status code, HTTP response headers (array of strings)
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function trackGetGetWithHttpInfo($track_id, $format = null, $callback = null)
    {
        // verify the required parameter 'track_id' is set
        if ($track_id === null) {
            throw new \InvalidArgumentException('Missing the required parameter $track_id when calling trackGetGet');
        }
        // parse inputs
        $resourcePath = "/track.get";
        $httpBody = '';
        $queryParams = array();
        $headerParams = array();
        $formParams = array();
        $_header_accept = $this->apiClient->selectHeaderAccept(array('application/json'));
        if (!is_null($_header_accept)) {
            $headerParams['Accept'] = $_header_accept;
        }
        $headerParams['Content-Type'] = $this->apiClient->selectHeaderContentType(array('application/json'));

        // query params
        if ($format !== null) {
            $queryParams['format'] = $this->apiClient->getSerializer()->toQueryValue($format);
        }
        // query params
        if ($callback !== null) {
            $queryParams['callback'] = $this->apiClient->getSerializer()->toQueryValue($callback);
        }
        // query params
        if ($track_id !== null) {
            $queryParams['track_id'] = $this->apiClient->getSerializer()->toQueryValue($track_id);
        }
        // default format to json
        $resourcePath = str_replace("{format}", "json", $resourcePath);

        
        // for model (json/xml)
        if (isset($_tempBody)) {
            $httpBody = $_tempBody; // $_tempBody is the method argument, if present
        } elseif (count($formParams) > 0) {
            $httpBody = $formParams; // for HTTP post (form)
        }
        // this endpoint requires API key authentication
        $apiKey = $this->apiClient->getApiKeyWithPrefix('apikey');
        if (strlen($apiKey) !== 0) {
            $queryParams['apikey'] = $apiKey;
        }
        // make the API Call
        try {
            list($response, $statusCode, $httpHeader) = $this->apiClient->callApi(
                $resourcePath,
                'GET',
                $queryParams,
                $httpBody,
                $headerParams,
                '\Swagger\Client\Model\InlineResponse2009',
                '/track.get'
            );

            return array($this->apiClient->getSerializer()->deserialize($response, '\Swagger\Client\Model\InlineResponse2009', $httpHeader), $statusCode, $httpHeader);
        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = $this->apiClient->getSerializer()->deserialize($e->getResponseBody(), '\Swagger\Client\Model\InlineResponse2009', $e->getResponseHeaders());
                    $e->setResponseObject($data);
                    break;
            }

            throw $e;
        }
    }

    /**
     * Operation trackSearchGet
     *
     * 
     *
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @param string $q_track The song title (optional)
     * @param string $q_artist The song artist (optional)
     * @param string $q_lyrics Any word in the lyrics (optional)
     * @param float $f_artist_id When set, filter by this artist id (optional)
     * @param float $f_music_genre_id When set, filter by this music category id (optional)
     * @param float $f_lyrics_language Filter by the lyrics language (en,it,..) (optional)
     * @param float $f_has_lyrics When set, filter only contents with lyrics (optional)
     * @param string $s_artist_rating Sort by our popularity index for artists (asc|desc) (optional)
     * @param string $s_track_rating Sort by our popularity index for tracks (asc|desc) (optional)
     * @param float $quorum_factor Search only a part of the given query string.Allowed range is (0.1 – 0.9) (optional, default to 1)
     * @param float $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param float $page Define the page number for paginated results (optional)
     * @return \Swagger\Client\Model\InlineResponse2006
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function trackSearchGet($format = null, $callback = null, $q_track = null, $q_artist = null, $q_lyrics = null, $f_artist_id = null, $f_music_genre_id = null, $f_lyrics_language = null, $f_has_lyrics = null, $s_artist_rating = null, $s_track_rating = null, $quorum_factor = null, $page_size = null, $page = null)
    {
        list($response) = $this->trackSearchGetWithHttpInfo($format, $callback, $q_track, $q_artist, $q_lyrics, $f_artist_id, $f_music_genre_id, $f_lyrics_language, $f_has_lyrics, $s_artist_rating, $s_track_rating, $quorum_factor, $page_size, $page);
        return $response;
    }

    /**
     * Operation trackSearchGetWithHttpInfo
     *
     * 
     *
     * @param string $format output format: json, jsonp, xml. (optional, default to json)
     * @param string $callback jsonp callback (optional)
     * @param string $q_track The song title (optional)
     * @param string $q_artist The song artist (optional)
     * @param string $q_lyrics Any word in the lyrics (optional)
     * @param float $f_artist_id When set, filter by this artist id (optional)
     * @param float $f_music_genre_id When set, filter by this music category id (optional)
     * @param float $f_lyrics_language Filter by the lyrics language (en,it,..) (optional)
     * @param float $f_has_lyrics When set, filter only contents with lyrics (optional)
     * @param string $s_artist_rating Sort by our popularity index for artists (asc|desc) (optional)
     * @param string $s_track_rating Sort by our popularity index for tracks (asc|desc) (optional)
     * @param float $quorum_factor Search only a part of the given query string.Allowed range is (0.1 – 0.9) (optional, default to 1)
     * @param float $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param float $page Define the page number for paginated results (optional)
     * @return Array of \Swagger\Client\Model\InlineResponse2006, HTTP status code, HTTP response headers (array of strings)
     * @throws \Swagger\Client\ApiException on non-2xx response
     */
    public function trackSearchGetWithHttpInfo($format = null, $callback = null, $q_track = null, $q_artist = null, $q_lyrics = null, $f_artist_id = null, $f_music_genre_id = null, $f_lyrics_language = null, $f_has_lyrics = null, $s_artist_rating = null, $s_track_rating = null, $quorum_factor = null, $page_size = null, $page = null)
    {
        // parse inputs
        $resourcePath = "/track.search";
        $httpBody = '';
        $queryParams = array();
        $headerParams = array();
        $formParams = array();
        $_header_accept = $this->apiClient->selectHeaderAccept(array('application/json'));
        if (!is_null($_header_accept)) {
            $headerParams['Accept'] = $_header_accept;
        }
        $headerParams['Content-Type'] = $this->apiClient->selectHeaderContentType(array('application/json'));

        // query params
        if ($format !== null) {
            $queryParams['format'] = $this->apiClient->getSerializer()->toQueryValue($format);
        }
        // query params
        if ($callback !== null) {
            $queryParams['callback'] = $this->apiClient->getSerializer()->toQueryValue($callback);
        }
        // query params
        if ($q_track !== null) {
            $queryParams['q_track'] = $this->apiClient->getSerializer()->toQueryValue($q_track);
        }
        // query params
        if ($q_artist !== null) {
            $queryParams['q_artist'] = $this->apiClient->getSerializer()->toQueryValue($q_artist);
        }
        // query params
        if ($q_lyrics !== null) {
            $queryParams['q_lyrics'] = $this->apiClient->getSerializer()->toQueryValue($q_lyrics);
        }
        // query params
        if ($f_artist_id !== null) {
            $queryParams['f_artist_id'] = $this->apiClient->getSerializer()->toQueryValue($f_artist_id);
        }
        // query params
        if ($f_music_genre_id !== null) {
            $queryParams['f_music_genre_id'] = $this->apiClient->getSerializer()->toQueryValue($f_music_genre_id);
        }
        // query params
        if ($f_lyrics_language !== null) {
            $queryParams['f_lyrics_language'] = $this->apiClient->getSerializer()->toQueryValue($f_lyrics_language);
        }
        // query params
        if ($f_has_lyrics !== null) {
            $queryParams['f_has_lyrics'] = $this->apiClient->getSerializer()->toQueryValue($f_has_lyrics);
        }
        // query params
        if ($s_artist_rating !== null) {
            $queryParams['s_artist_rating'] = $this->apiClient->getSerializer()->toQueryValue($s_artist_rating);
        }
        // query params
        if ($s_track_rating !== null) {
            $queryParams['s_track_rating'] = $this->apiClient->getSerializer()->toQueryValue($s_track_rating);
        }
        // query params
        if ($quorum_factor !== null) {
            $queryParams['quorum_factor'] = $this->apiClient->getSerializer()->toQueryValue($quorum_factor);
        }
        // query params
        if ($page_size !== null) {
            $queryParams['page_size'] = $this->apiClient->getSerializer()->toQueryValue($page_size);
        }
        // query params
        if ($page !== null) {
            $queryParams['page'] = $this->apiClient->getSerializer()->toQueryValue($page);
        }
        // default format to json
        $resourcePath = str_replace("{format}", "json", $resourcePath);

        
        // for model (json/xml)
        if (isset($_tempBody)) {
            $httpBody = $_tempBody; // $_tempBody is the method argument, if present
        } elseif (count($formParams) > 0) {
            $httpBody = $formParams; // for HTTP post (form)
        }
        // this endpoint requires API key authentication
        $apiKey = $this->apiClient->getApiKeyWithPrefix('apikey');
        if (strlen($apiKey) !== 0) {
            $queryParams['apikey'] = $apiKey;
        }
        // make the API Call
        try {
            list($response, $statusCode, $httpHeader) = $this->apiClient->callApi(
                $resourcePath,
                'GET',
                $queryParams,
                $httpBody,
                $headerParams,
                '\Swagger\Client\Model\InlineResponse2006',
                '/track.search'
            );

            return array($this->apiClient->getSerializer()->deserialize($response, '\Swagger\Client\Model\InlineResponse2006', $httpHeader), $statusCode, $httpHeader);
        } catch (ApiException $e) {
            switch ($e->getCode()) {
                case 200:
                    $data = $this->apiClient->getSerializer()->deserialize($e->getResponseBody(), '\Swagger\Client\Model\InlineResponse2006', $e->getResponseHeaders());
                    $e->setResponseObject($data);
                    break;
            }

            throw $e;
        }
    }

}
