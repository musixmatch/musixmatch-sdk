# MusixmatchApi.InlineResponse2003MessageBodyArtistArtistNameTranslation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **String** |  | [optional] 
**translation** | **String** |  | [optional] 


