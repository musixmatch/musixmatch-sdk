# MusixmatchApi.InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreId** | **Number** |  | [optional] 
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 


