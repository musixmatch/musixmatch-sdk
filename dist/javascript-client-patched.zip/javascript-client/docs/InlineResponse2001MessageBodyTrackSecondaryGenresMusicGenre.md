# MusixmatchApi.InlineResponse2001MessageBodyTrackSecondaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 


