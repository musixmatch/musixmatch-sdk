# MusixmatchApi.InlineResponse2006MessageBodyArtistList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | [**InlineResponse2006MessageBodyArtist**](InlineResponse2006MessageBodyArtist.md) |  | [optional] 


