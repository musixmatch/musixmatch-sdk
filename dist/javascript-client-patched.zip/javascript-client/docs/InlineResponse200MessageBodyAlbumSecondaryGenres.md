# MusixmatchApi.InlineResponse200MessageBodyAlbumSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | **[String]** |  | [optional] 


