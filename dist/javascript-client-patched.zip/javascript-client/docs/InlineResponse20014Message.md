# MusixmatchApi.InlineResponse20014Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse20014MessageBody**](InlineResponse20014MessageBody.md) |  | [optional] 


