# MusixmatchApi.InlineResponse2005MessageBodyArtistArtistCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | [**[InlineResponse2005MessageBodyArtistArtistCreditsArtistList]**](InlineResponse2005MessageBodyArtistArtistCreditsArtistList.md) |  | [optional] 


