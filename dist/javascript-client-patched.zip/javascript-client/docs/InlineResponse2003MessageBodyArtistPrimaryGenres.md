# MusixmatchApi.InlineResponse2003MessageBodyArtistPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenreList]**](InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenreList.md) |  | [optional] 


