# MusixmatchApi.InlineResponse2008MessageBodyLyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lyricsId** | **Number** |  | [optional] 
**pixelTrackingUrl** | **String** |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**instrumental** | **Number** |  | [optional] 
**lyricsBody** | **String** |  | [optional] 
**publisherList** | **[String]** |  | [optional] 
**lyricsCopyright** | **String** |  | [optional] 
**actionRequested** | **String** |  | [optional] 
**writerList** | **[String]** |  | [optional] 
**lyricsLanguage** | **String** |  | [optional] 
**explicit** | **Number** |  | [optional] 
**lyricsLanguageDescription** | **String** |  | [optional] 
**htmlTrackingUrl** | **String** |  | [optional] 
**locked** | **Number** |  | [optional] 
**verified** | **Number** |  | [optional] 
**scriptTrackingUrl** | **String** |  | [optional] 
**canEdit** | **Number** |  | [optional] 
**restricted** | **Number** |  | [optional] 


