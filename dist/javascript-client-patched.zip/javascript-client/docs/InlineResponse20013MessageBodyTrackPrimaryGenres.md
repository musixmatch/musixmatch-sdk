# MusixmatchApi.InlineResponse20013MessageBodyTrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenreList]**](InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenreList.md) |  | [optional] 


