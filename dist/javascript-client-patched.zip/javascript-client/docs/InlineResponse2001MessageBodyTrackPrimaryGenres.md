# MusixmatchApi.InlineResponse2001MessageBodyTrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenreList]**](InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenreList.md) |  | [optional] 


