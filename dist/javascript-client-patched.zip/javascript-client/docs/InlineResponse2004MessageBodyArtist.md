# MusixmatchApi.InlineResponse2004MessageBodyArtist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**managed** | **Number** |  | [optional] 
**artistCredits** | [**InlineResponse2003MessageBodyArtistArtistCredits**](InlineResponse2003MessageBodyArtistArtistCredits.md) |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**primaryGenres** | [**InlineResponse2004MessageBodyArtistPrimaryGenres**](InlineResponse2004MessageBodyArtistPrimaryGenres.md) |  | [optional] 
**artistMbid** | **String** |  | [optional] 
**artistRating** | **Number** |  | [optional] 
**artistTwitterUrl** | **String** |  | [optional] 
**artistComment** | **String** |  | [optional] 
**artistShareUrl** | **String** |  | [optional] 
**secondaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artistVanityId** | **String** |  | [optional] 
**restricted** | **Number** |  | [optional] 
**artistName** | **String** |  | [optional] 
**artistId** | **Number** |  | [optional] 
**artistNameTranslationList** | [**[InlineResponse2004MessageBodyArtistArtistNameTranslationList]**](InlineResponse2004MessageBodyArtistArtistNameTranslationList.md) |  | [optional] 
**artistEditUrl** | **String** |  | [optional] 
**artistAliasList** | [**[InlineResponse2003MessageBodyArtistArtistAliasList]**](InlineResponse2003MessageBodyArtistArtistAliasList.md) |  | [optional] 
**artistCountry** | **String** |  | [optional] 


