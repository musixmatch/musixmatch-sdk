# MusixmatchApi.InlineResponse20013Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**InlineResponse20013MessageBody**](InlineResponse20013MessageBody.md) |  | [optional] 
**header** | [**InlineResponse2004MessageHeader**](InlineResponse2004MessageHeader.md) |  | [optional] 


