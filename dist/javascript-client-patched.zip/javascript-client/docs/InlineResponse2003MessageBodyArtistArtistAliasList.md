# MusixmatchApi.InlineResponse2003MessageBodyArtistArtistAliasList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistAlias** | **String** |  | [optional] 


