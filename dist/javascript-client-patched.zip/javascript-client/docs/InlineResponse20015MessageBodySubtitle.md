# MusixmatchApi.InlineResponse20015MessageBodySubtitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updatedTime** | **String** |  | [optional] 
**publisherList** | **[String]** |  | [optional] 
**restricted** | **Number** |  | [optional] 
**lyricsCopyright** | **String** |  | [optional] 
**subtitleBody** | **String** |  | [optional] 
**subtitleLanguageDescription** | **String** |  | [optional] 
**subtitleLength** | **Number** |  | [optional] 
**subtitleId** | **Number** |  | [optional] 
**subtitleLanguage** | **String** |  | [optional] 
**pixelTrackingUrl** | **String** |  | [optional] 
**htmlTrackingUrl** | **String** |  | [optional] 
**writerList** | **[String]** |  | [optional] 
**scriptTrackingUrl** | **String** |  | [optional] 


