# MusixmatchApi.InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenre**](InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenre.md) |  | [optional] 


