# MusixmatchApi.InlineResponse2008MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lyrics** | [**InlineResponse2008MessageBodyLyrics**](InlineResponse2008MessageBodyLyrics.md) |  | [optional] 


