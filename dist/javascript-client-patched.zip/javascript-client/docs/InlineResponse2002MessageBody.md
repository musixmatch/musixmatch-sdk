# MusixmatchApi.InlineResponse2002MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**albumList** | [**[InlineResponse2002MessageBodyAlbumList]**](InlineResponse2002MessageBodyAlbumList.md) |  | [optional] 


