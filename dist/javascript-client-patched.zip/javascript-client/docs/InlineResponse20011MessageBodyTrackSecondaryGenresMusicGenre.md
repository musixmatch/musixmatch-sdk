# MusixmatchApi.InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 


