# MusixmatchApi.InlineResponse20014MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**snippet** | [**InlineResponse20014MessageBodySnippet**](InlineResponse20014MessageBodySnippet.md) |  | [optional] 


