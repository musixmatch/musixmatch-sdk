# MusixmatchApi.InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenre**](InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenre.md) |  | [optional] 


