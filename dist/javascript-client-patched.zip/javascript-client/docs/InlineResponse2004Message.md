# MusixmatchApi.InlineResponse2004Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2004MessageHeader**](InlineResponse2004MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2004MessageBody**](InlineResponse2004MessageBody.md) |  | [optional] 


