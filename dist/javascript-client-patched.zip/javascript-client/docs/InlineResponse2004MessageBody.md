# MusixmatchApi.InlineResponse2004MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | [**[InlineResponse2004MessageBodyArtistList]**](InlineResponse2004MessageBodyArtistList.md) |  | [optional] 


