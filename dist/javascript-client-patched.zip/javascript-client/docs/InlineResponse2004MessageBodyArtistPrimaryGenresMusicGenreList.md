# MusixmatchApi.InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenre**](InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenre.md) |  | [optional] 


