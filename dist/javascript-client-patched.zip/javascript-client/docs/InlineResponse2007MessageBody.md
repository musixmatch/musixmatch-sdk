# MusixmatchApi.InlineResponse2007MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackList** | [**[InlineResponse2007MessageBodyTrackList]**](InlineResponse2007MessageBodyTrackList.md) |  | [optional] 


