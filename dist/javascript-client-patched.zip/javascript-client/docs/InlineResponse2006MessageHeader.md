# MusixmatchApi.InlineResponse2006MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executeTime** | **Number** |  | [optional] 
**statusCode** | **Number** |  | [optional] 


