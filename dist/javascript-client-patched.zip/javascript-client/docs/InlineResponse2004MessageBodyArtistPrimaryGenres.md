# MusixmatchApi.InlineResponse2004MessageBodyArtistPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenreList]**](InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenreList.md) |  | [optional] 


