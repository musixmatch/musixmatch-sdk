# MusixmatchApi.InlineResponse20012MessageBodyLyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | **Number** |  | [optional] 
**pixelTrackingUrl** | **String** |  | [optional] 
**publisherList** | **[String]** |  | [optional] 
**lyricsLanguageDescription** | **String** |  | [optional] 
**restricted** | **Number** |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**explicit** | **Number** |  | [optional] 
**lyricsCopyright** | **String** |  | [optional] 
**htmlTrackingUrl** | **String** |  | [optional] 
**lyricsLanguage** | **String** |  | [optional] 
**scriptTrackingUrl** | **String** |  | [optional] 
**verified** | **Number** |  | [optional] 
**lyricsBody** | **String** |  | [optional] 
**lyricsId** | **Number** |  | [optional] 
**writerList** | **[String]** |  | [optional] 
**canEdit** | **Number** |  | [optional] 
**actionRequested** | **String** |  | [optional] 
**locked** | **Number** |  | [optional] 


