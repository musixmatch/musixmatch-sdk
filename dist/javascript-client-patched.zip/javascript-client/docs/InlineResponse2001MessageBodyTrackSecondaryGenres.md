# MusixmatchApi.InlineResponse2001MessageBodyTrackSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse2001MessageBodyTrackSecondaryGenresMusicGenreList]**](InlineResponse2001MessageBodyTrackSecondaryGenresMusicGenreList.md) |  | [optional] 


