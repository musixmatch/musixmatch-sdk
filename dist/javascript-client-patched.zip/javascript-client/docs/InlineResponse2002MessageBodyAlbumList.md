# MusixmatchApi.InlineResponse2002MessageBodyAlbumList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**album** | [**InlineResponse2002MessageBodyAlbum**](InlineResponse2002MessageBodyAlbum.md) |  | [optional] 


