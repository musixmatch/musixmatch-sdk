# MusixmatchApi.InlineResponse2004MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executeTime** | **Number** |  | [optional] 
**available** | **Number** |  | [optional] 
**statusCode** | **Number** |  | [optional] 


