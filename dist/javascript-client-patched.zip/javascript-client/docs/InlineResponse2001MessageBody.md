# MusixmatchApi.InlineResponse2001MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackList** | [**[InlineResponse2001MessageBodyTrackList]**](InlineResponse2001MessageBodyTrackList.md) |  | [optional] 


