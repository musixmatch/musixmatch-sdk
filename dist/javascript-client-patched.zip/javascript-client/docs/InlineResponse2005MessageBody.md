# MusixmatchApi.InlineResponse2005MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | [**[InlineResponse2005MessageBodyArtistList]**](InlineResponse2005MessageBodyArtistList.md) |  | [optional] 


