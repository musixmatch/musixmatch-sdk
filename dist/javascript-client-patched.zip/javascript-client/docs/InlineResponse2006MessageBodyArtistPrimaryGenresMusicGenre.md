# MusixmatchApi.InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 


