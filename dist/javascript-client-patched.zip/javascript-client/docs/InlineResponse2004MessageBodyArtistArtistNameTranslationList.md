# MusixmatchApi.InlineResponse2004MessageBodyArtistArtistNameTranslationList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistNameTranslation** | [**InlineResponse2004MessageBodyArtistArtistNameTranslation**](InlineResponse2004MessageBodyArtistArtistNameTranslation.md) |  | [optional] 


