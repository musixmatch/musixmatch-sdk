# MusixmatchApi.InlineResponse2006MessageBodyArtist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistComment** | **String** |  | [optional] 
**artistCredits** | [**InlineResponse2003MessageBodyArtistArtistCredits**](InlineResponse2003MessageBodyArtistArtistCredits.md) |  | [optional] 
**primaryGenres** | [**InlineResponse2006MessageBodyArtistPrimaryGenres**](InlineResponse2006MessageBodyArtistPrimaryGenres.md) |  | [optional] 
**artistAliasList** | [**[InlineResponse2003MessageBodyArtistArtistAliasList]**](InlineResponse2003MessageBodyArtistArtistAliasList.md) |  | [optional] 
**artistShareUrl** | **String** |  | [optional] 
**secondaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artistTwitterUrl** | **String** |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**artistCountry** | **String** |  | [optional] 
**artistId** | **Number** |  | [optional] 
**restricted** | **Number** |  | [optional] 
**artistMbid** | **String** |  | [optional] 
**artistNameTranslationList** | [**[InlineResponse2004MessageBodyArtistArtistNameTranslationList]**](InlineResponse2004MessageBodyArtistArtistNameTranslationList.md) |  | [optional] 
**managed** | **Number** |  | [optional] 
**artistName** | **String** |  | [optional] 
**artistVanityId** | **String** |  | [optional] 
**artistRating** | **Number** |  | [optional] 
**artistEditUrl** | **String** |  | [optional] 


