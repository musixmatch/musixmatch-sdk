# MusixmatchApi.InlineResponse20015MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subtitle** | [**InlineResponse20015MessageBodySubtitle**](InlineResponse20015MessageBodySubtitle.md) |  | [optional] 


