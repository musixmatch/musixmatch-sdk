# MusixmatchApi.InlineResponse20011MessageBodyTrackSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenreList]**](InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenreList.md) |  | [optional] 


