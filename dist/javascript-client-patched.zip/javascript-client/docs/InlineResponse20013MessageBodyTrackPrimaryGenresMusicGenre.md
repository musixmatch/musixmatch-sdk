# MusixmatchApi.InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 


