# MusixmatchApi.InlineResponse2007MessageBodyTrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenreList]**](InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenreList.md) |  | [optional] 


