# MusixmatchApi.InlineResponse2003MessageBodyArtistArtistNameTranslationList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistNameTranslation** | [**InlineResponse2003MessageBodyArtistArtistNameTranslation**](InlineResponse2003MessageBodyArtistArtistNameTranslation.md) |  | [optional] 


