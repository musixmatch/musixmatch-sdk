# MusixmatchApi.InlineResponse2005MessageBodyArtistArtistCreditsArtist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restricted** | **Number** |  | [optional] 
**artistId** | **Number** |  | [optional] 
**artistTwitterUrl** | **String** |  | [optional] 
**artistNameTranslationList** | **[String]** |  | [optional] 
**artistCountry** | **String** |  | [optional] 
**artistName** | **String** |  | [optional] 
**secondaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artistComment** | **String** |  | [optional] 
**artistShareUrl** | **String** |  | [optional] 
**artistAliasList** | **[String]** |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**primaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**managed** | **Number** |  | [optional] 
**artistEditUrl** | **String** |  | [optional] 
**artistCredits** | [**InlineResponse2003MessageBodyArtistArtistCredits**](InlineResponse2003MessageBodyArtistArtistCredits.md) |  | [optional] 
**artistRating** | **Number** |  | [optional] 
**artistMbid** | **String** |  | [optional] 
**artistVanityId** | **String** |  | [optional] 


