# MusixmatchApi.InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenre**](InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenre.md) |  | [optional] 


