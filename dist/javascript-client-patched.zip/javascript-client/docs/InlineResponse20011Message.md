# MusixmatchApi.InlineResponse20011Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**InlineResponse20011MessageBody**](InlineResponse20011MessageBody.md) |  | [optional] 
**header** | [**InlineResponse2006MessageHeader**](InlineResponse2006MessageHeader.md) |  | [optional] 


