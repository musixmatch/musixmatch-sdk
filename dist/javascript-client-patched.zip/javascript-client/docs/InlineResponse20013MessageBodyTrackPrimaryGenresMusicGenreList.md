# MusixmatchApi.InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenre**](InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenre.md) |  | [optional] 


