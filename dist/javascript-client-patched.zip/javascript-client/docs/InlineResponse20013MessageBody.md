# MusixmatchApi.InlineResponse20013MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackList** | [**[InlineResponse20013MessageBodyTrackList]**](InlineResponse20013MessageBodyTrackList.md) |  | [optional] 


