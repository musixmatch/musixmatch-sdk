# MusixmatchApi.InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenre**](InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenre.md) |  | [optional] 


