# MusixmatchApi.InlineResponse200MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**album** | [**InlineResponse200MessageBodyAlbum**](InlineResponse200MessageBodyAlbum.md) |  | [optional] 


