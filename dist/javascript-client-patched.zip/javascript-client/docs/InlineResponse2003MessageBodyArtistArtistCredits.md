# MusixmatchApi.InlineResponse2003MessageBodyArtistArtistCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | **[String]** |  | [optional] 


