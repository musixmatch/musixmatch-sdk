# MusixmatchApi.InlineResponse20011MessageBodyTrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenreList]**](InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenreList.md) |  | [optional] 


