# MusixmatchApi.InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenre**](InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenre.md) |  | [optional] 


