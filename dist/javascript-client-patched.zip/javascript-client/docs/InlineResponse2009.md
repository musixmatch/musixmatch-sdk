# MusixmatchApi.InlineResponse2009

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2009Message**](InlineResponse2009Message.md) |  | [optional] 


