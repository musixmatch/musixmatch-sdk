# MusixmatchApi.InlineResponse200MessageBodyAlbumPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenreList]**](InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenreList.md) |  | [optional] 


