# MusixmatchApi.InlineResponse2006MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | [**[InlineResponse2006MessageBodyArtistList]**](InlineResponse2006MessageBodyArtistList.md) |  | [optional] 


