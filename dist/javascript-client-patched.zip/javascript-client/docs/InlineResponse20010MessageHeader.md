# MusixmatchApi.InlineResponse20010MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**executeTime** | **Number** |  | [optional] 
**statusCode** | **Number** |  | [optional] 
**confidence** | **Number** |  | [optional] 
**mode** | **String** |  | [optional] 
**cached** | **Number** |  | [optional] 


