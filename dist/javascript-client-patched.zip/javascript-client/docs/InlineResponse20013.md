# MusixmatchApi.InlineResponse20013

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse20013Message**](InlineResponse20013Message.md) |  | [optional] 


