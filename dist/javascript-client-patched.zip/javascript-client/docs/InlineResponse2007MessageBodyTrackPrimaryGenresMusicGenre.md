# MusixmatchApi.InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreName** | **String** |  | [optional] 
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 


