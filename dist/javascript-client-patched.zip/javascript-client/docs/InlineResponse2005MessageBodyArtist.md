# MusixmatchApi.InlineResponse2005MessageBodyArtist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistEditUrl** | **String** |  | [optional] 
**artistAliasList** | **[String]** |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**managed** | **Number** |  | [optional] 
**primaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artistShareUrl** | **String** |  | [optional] 
**artistComment** | **String** |  | [optional] 
**artistMbid** | **String** |  | [optional] 
**artistVanityId** | **String** |  | [optional] 
**artistCredits** | [**InlineResponse2005MessageBodyArtistArtistCredits**](InlineResponse2005MessageBodyArtistArtistCredits.md) |  | [optional] 
**artistRating** | **Number** |  | [optional] 
**artistId** | **Number** |  | [optional] 
**restricted** | **Number** |  | [optional] 
**secondaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artistTwitterUrl** | **String** |  | [optional] 
**artistCountry** | **String** |  | [optional] 
**artistName** | **String** |  | [optional] 
**artistNameTranslationList** | **[String]** |  | [optional] 


