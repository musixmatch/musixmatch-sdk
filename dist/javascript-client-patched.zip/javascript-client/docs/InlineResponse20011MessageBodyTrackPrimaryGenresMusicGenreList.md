# MusixmatchApi.InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenre**](InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenre.md) |  | [optional] 


