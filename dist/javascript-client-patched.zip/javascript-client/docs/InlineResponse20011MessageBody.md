# MusixmatchApi.InlineResponse20011MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track** | [**InlineResponse20011MessageBodyTrack**](InlineResponse20011MessageBodyTrack.md) |  | [optional] 


