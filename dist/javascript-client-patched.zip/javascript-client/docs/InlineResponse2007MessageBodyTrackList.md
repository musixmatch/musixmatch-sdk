# MusixmatchApi.InlineResponse2007MessageBodyTrackList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track** | [**InlineResponse2007MessageBodyTrack**](InlineResponse2007MessageBodyTrack.md) |  | [optional] 


