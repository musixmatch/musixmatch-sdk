# MusixmatchApi.InlineResponse2002MessageBodyAlbum

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**albumRating** | **Number** |  | [optional] 
**albumPline** | **String** |  | [optional] 
**albumCopyright** | **String** |  | [optional] 
**albumEditUrl** | **String** |  | [optional] 
**albumName** | **String** |  | [optional] 
**artistName** | **String** |  | [optional] 
**albumCoverart800x800** | **String** |  | [optional] 
**albumId** | **Number** |  | [optional] 
**albumMbid** | **String** |  | [optional] 
**albumCoverart100x100** | **String** |  | [optional] 
**albumVanityId** | **String** |  | [optional] 
**albumReleaseDate** | **String** |  | [optional] 
**albumLabel** | **String** |  | [optional] 
**albumCoverart350x350** | **String** |  | [optional] 
**albumCoverart500x500** | **String** |  | [optional] 
**primaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**albumTrackCount** | **Number** |  | [optional] 
**albumReleaseType** | **String** |  | [optional] 
**artistId** | **Number** |  | [optional] 
**secondaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**restricted** | **Number** |  | [optional] 


