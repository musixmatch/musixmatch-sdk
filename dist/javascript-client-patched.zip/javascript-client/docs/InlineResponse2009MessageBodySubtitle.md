# MusixmatchApi.InlineResponse2009MessageBodySubtitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subtitleBody** | **String** |  | [optional] 
**publisherList** | **[String]** |  | [optional] 
**subtitleLanguage** | **String** |  | [optional] 
**subtitleLanguageDescription** | **String** |  | [optional] 
**subtitleId** | **Number** |  | [optional] 
**pixelTrackingUrl** | **String** |  | [optional] 
**htmlTrackingUrl** | **String** |  | [optional] 
**restricted** | **Number** |  | [optional] 
**lyricsCopyright** | **String** |  | [optional] 
**scriptTrackingUrl** | **String** |  | [optional] 
**subtitleLength** | **Number** |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**writerList** | **[String]** |  | [optional] 


