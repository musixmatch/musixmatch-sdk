# MusixmatchApi.InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreName** | **String** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreVanity** | **String** |  | [optional] 


