# MusixmatchApi.InlineResponse2006Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2006MessageHeader**](InlineResponse2006MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2006MessageBody**](InlineResponse2006MessageBody.md) |  | [optional] 


