# MusixmatchApi.InlineResponse2003MessageBodyArtist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistCredits** | [**InlineResponse2003MessageBodyArtistArtistCredits**](InlineResponse2003MessageBodyArtistArtistCredits.md) |  | [optional] 
**artistMbid** | **String** |  | [optional] 
**artistName** | **String** |  | [optional] 
**secondaryGenres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artistAliasList** | [**[InlineResponse2003MessageBodyArtistArtistAliasList]**](InlineResponse2003MessageBodyArtistArtistAliasList.md) |  | [optional] 
**artistVanityId** | **String** |  | [optional] 
**restricted** | **Number** |  | [optional] 
**artistCountry** | **String** |  | [optional] 
**artistComment** | **String** |  | [optional] 
**artistNameTranslationList** | [**[InlineResponse2003MessageBodyArtistArtistNameTranslationList]**](InlineResponse2003MessageBodyArtistArtistNameTranslationList.md) |  | [optional] 
**artistEditUrl** | **String** |  | [optional] 
**artistShareUrl** | **String** |  | [optional] 
**artistId** | **Number** |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**managed** | **Number** |  | [optional] 
**primaryGenres** | [**InlineResponse2003MessageBodyArtistPrimaryGenres**](InlineResponse2003MessageBodyArtistPrimaryGenres.md) |  | [optional] 
**artistTwitterUrl** | **String** |  | [optional] 
**artistRating** | **Number** |  | [optional] 


