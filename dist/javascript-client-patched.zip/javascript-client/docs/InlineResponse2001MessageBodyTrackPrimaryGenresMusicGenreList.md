# MusixmatchApi.InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenre**](InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenre.md) |  | [optional] 


