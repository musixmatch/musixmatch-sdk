# MusixmatchApi.InlineResponse2006MessageBodyArtistPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenreList]**](InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenreList.md) |  | [optional] 


