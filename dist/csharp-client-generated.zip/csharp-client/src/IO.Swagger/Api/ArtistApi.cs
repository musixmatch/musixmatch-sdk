/* 
 * Musixmatch API
 *
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop 
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IArtistApi : IApiAccessor
    {
        #region Synchronous Operations
        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId"> The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <returns>InlineResponse2003</returns>
        InlineResponse2003 ArtistGetGet (string artistId, string format = null, string callback = null);

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId"> The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <returns>ApiResponse of InlineResponse2003</returns>
        ApiResponse<InlineResponse2003> ArtistGetGetWithHttpInfo (string artistId, string format = null, string callback = null);
        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId">The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <returns>InlineResponse2004</returns>
        InlineResponse2004 ArtistRelatedGetGet (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null);

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId">The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <returns>ApiResponse of InlineResponse2004</returns>
        ApiResponse<InlineResponse2004> ArtistRelatedGetGetWithHttpInfo (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null);
        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="qArtist">The song artist (optional)</param>
        /// <param name="fArtistId">When set, filter by this artist id (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <returns>InlineResponse2004</returns>
        InlineResponse2004 ArtistSearchGet (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null);

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="qArtist">The song artist (optional)</param>
        /// <param name="fArtistId">When set, filter by this artist id (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <returns>ApiResponse of InlineResponse2004</returns>
        ApiResponse<InlineResponse2004> ArtistSearchGetWithHttpInfo (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null);
        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="country">A valid ISO 3166 country code (optional, default to us)</param>
        /// <returns>InlineResponse2005</returns>
        InlineResponse2005 ChartArtistsGetGet (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null);

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="country">A valid ISO 3166 country code (optional, default to us)</param>
        /// <returns>ApiResponse of InlineResponse2005</returns>
        ApiResponse<InlineResponse2005> ChartArtistsGetGetWithHttpInfo (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null);
        #endregion Synchronous Operations
        #region Asynchronous Operations
        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId"> The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <returns>Task of InlineResponse2003</returns>
        System.Threading.Tasks.Task<InlineResponse2003> ArtistGetGetAsync (string artistId, string format = null, string callback = null);

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId"> The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <returns>Task of ApiResponse (InlineResponse2003)</returns>
        System.Threading.Tasks.Task<ApiResponse<InlineResponse2003>> ArtistGetGetAsyncWithHttpInfo (string artistId, string format = null, string callback = null);
        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId">The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <returns>Task of InlineResponse2004</returns>
        System.Threading.Tasks.Task<InlineResponse2004> ArtistRelatedGetGetAsync (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null);

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId">The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <returns>Task of ApiResponse (InlineResponse2004)</returns>
        System.Threading.Tasks.Task<ApiResponse<InlineResponse2004>> ArtistRelatedGetGetAsyncWithHttpInfo (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null);
        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="qArtist">The song artist (optional)</param>
        /// <param name="fArtistId">When set, filter by this artist id (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <returns>Task of InlineResponse2004</returns>
        System.Threading.Tasks.Task<InlineResponse2004> ArtistSearchGetAsync (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null);

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="qArtist">The song artist (optional)</param>
        /// <param name="fArtistId">When set, filter by this artist id (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <returns>Task of ApiResponse (InlineResponse2004)</returns>
        System.Threading.Tasks.Task<ApiResponse<InlineResponse2004>> ArtistSearchGetAsyncWithHttpInfo (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null);
        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="country">A valid ISO 3166 country code (optional, default to us)</param>
        /// <returns>Task of InlineResponse2005</returns>
        System.Threading.Tasks.Task<InlineResponse2005> ChartArtistsGetGetAsync (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null);

        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="country">A valid ISO 3166 country code (optional, default to us)</param>
        /// <returns>Task of ApiResponse (InlineResponse2005)</returns>
        System.Threading.Tasks.Task<ApiResponse<InlineResponse2005>> ChartArtistsGetGetAsyncWithHttpInfo (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null);
        #endregion Asynchronous Operations
    }

    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public partial class ArtistApi : IArtistApi
    {
        private IO.Swagger.Client.ExceptionFactory _exceptionFactory = (name, response) => null;

        /// <summary>
        /// Initializes a new instance of the <see cref="ArtistApi"/> class.
        /// </summary>
        /// <returns></returns>
        public ArtistApi(String basePath)
        {
            this.Configuration = new Configuration(new ApiClient(basePath));

            ExceptionFactory = IO.Swagger.Client.Configuration.DefaultExceptionFactory;

            // ensure API client has configuration ready
            if (Configuration.ApiClient.Configuration == null)
            {
                this.Configuration.ApiClient.Configuration = this.Configuration;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ArtistApi"/> class
        /// using Configuration object
        /// </summary>
        /// <param name="configuration">An instance of Configuration</param>
        /// <returns></returns>
        public ArtistApi(Configuration configuration = null)
        {
            if (configuration == null) // use the default one in Configuration
                this.Configuration = Configuration.Default;
            else
                this.Configuration = configuration;

            ExceptionFactory = IO.Swagger.Client.Configuration.DefaultExceptionFactory;

            // ensure API client has configuration ready
            if (Configuration.ApiClient.Configuration == null)
            {
                this.Configuration.ApiClient.Configuration = this.Configuration;
            }
        }

        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <value>The base path</value>
        public String GetBasePath()
        {
            return this.Configuration.ApiClient.RestClient.BaseUrl.ToString();
        }

        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <value>The base path</value>
        [Obsolete("SetBasePath is deprecated, please do 'Configuration.ApiClient = new ApiClient(\"http://new-path\")' instead.")]
        public void SetBasePath(String basePath)
        {
            // do nothing
        }

        /// <summary>
        /// Gets or sets the configuration object
        /// </summary>
        /// <value>An instance of the Configuration</value>
        public Configuration Configuration {get; set;}

        /// <summary>
        /// Provides a factory method hook for the creation of exceptions.
        /// </summary>
        public IO.Swagger.Client.ExceptionFactory ExceptionFactory
        {
            get
            {
                if (_exceptionFactory != null && _exceptionFactory.GetInvocationList().Length > 1)
                {
                    throw new InvalidOperationException("Multicast delegate for ExceptionFactory is unsupported.");
                }
                return _exceptionFactory;
            }
            set { _exceptionFactory = value; }
        }

        /// <summary>
        /// Gets the default header.
        /// </summary>
        /// <returns>Dictionary of HTTP header</returns>
        [Obsolete("DefaultHeader is deprecated, please use Configuration.DefaultHeader instead.")]
        public Dictionary<String, String> DefaultHeader()
        {
            return this.Configuration.DefaultHeader;
        }

        /// <summary>
        /// Add default header.
        /// </summary>
        /// <param name="key">Header field name.</param>
        /// <param name="value">Header field value.</param>
        /// <returns></returns>
        [Obsolete("AddDefaultHeader is deprecated, please use Configuration.AddDefaultHeader instead.")]
        public void AddDefaultHeader(string key, string value)
        {
            this.Configuration.AddDefaultHeader(key, value);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId"> The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <returns>InlineResponse2003</returns>
        public InlineResponse2003 ArtistGetGet (string artistId, string format = null, string callback = null)
        {
             ApiResponse<InlineResponse2003> localVarResponse = ArtistGetGetWithHttpInfo(artistId, format, callback);
             return localVarResponse.Data;
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId"> The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <returns>ApiResponse of InlineResponse2003</returns>
        public ApiResponse< InlineResponse2003 > ArtistGetGetWithHttpInfo (string artistId, string format = null, string callback = null)
        {
            // verify the required parameter 'artistId' is set
            if (artistId == null)
                throw new ApiException(400, "Missing required parameter 'artistId' when calling ArtistApi->ArtistGetGet");

            var localVarPath = "/artist.get";
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/json"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            if (format != null) localVarQueryParams.Add("format", Configuration.ApiClient.ParameterToString(format)); // query parameter
            if (callback != null) localVarQueryParams.Add("callback", Configuration.ApiClient.ParameterToString(callback)); // query parameter
            if (artistId != null) localVarQueryParams.Add("artist_id", Configuration.ApiClient.ParameterToString(artistId)); // query parameter

            // authentication (key) required
            if (!String.IsNullOrEmpty(Configuration.GetApiKeyWithPrefix("apikey")))
            {
                localVarQueryParams["apikey"] = Configuration.GetApiKeyWithPrefix("apikey");
            }


            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) Configuration.ApiClient.CallApi(localVarPath,
                Method.GET, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;

            if (ExceptionFactory != null)
            {
                Exception exception = ExceptionFactory("ArtistGetGet", localVarResponse);
                if (exception != null) throw exception;
            }

            return new ApiResponse<InlineResponse2003>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (InlineResponse2003) Configuration.ApiClient.Deserialize(localVarResponse, typeof(InlineResponse2003)));
            
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId"> The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <returns>Task of InlineResponse2003</returns>
        public async System.Threading.Tasks.Task<InlineResponse2003> ArtistGetGetAsync (string artistId, string format = null, string callback = null)
        {
             ApiResponse<InlineResponse2003> localVarResponse = await ArtistGetGetAsyncWithHttpInfo(artistId, format, callback);
             return localVarResponse.Data;

        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId"> The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <returns>Task of ApiResponse (InlineResponse2003)</returns>
        public async System.Threading.Tasks.Task<ApiResponse<InlineResponse2003>> ArtistGetGetAsyncWithHttpInfo (string artistId, string format = null, string callback = null)
        {
            // verify the required parameter 'artistId' is set
            if (artistId == null)
                throw new ApiException(400, "Missing required parameter 'artistId' when calling ArtistApi->ArtistGetGet");

            var localVarPath = "/artist.get";
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/json"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            if (format != null) localVarQueryParams.Add("format", Configuration.ApiClient.ParameterToString(format)); // query parameter
            if (callback != null) localVarQueryParams.Add("callback", Configuration.ApiClient.ParameterToString(callback)); // query parameter
            if (artistId != null) localVarQueryParams.Add("artist_id", Configuration.ApiClient.ParameterToString(artistId)); // query parameter

            // authentication (key) required
            if (!String.IsNullOrEmpty(Configuration.GetApiKeyWithPrefix("apikey")))
            {
                localVarQueryParams["apikey"] = Configuration.GetApiKeyWithPrefix("apikey");
            }

            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) await Configuration.ApiClient.CallApiAsync(localVarPath,
                Method.GET, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;

            if (ExceptionFactory != null)
            {
                Exception exception = ExceptionFactory("ArtistGetGet", localVarResponse);
                if (exception != null) throw exception;
            }

            return new ApiResponse<InlineResponse2003>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (InlineResponse2003) Configuration.ApiClient.Deserialize(localVarResponse, typeof(InlineResponse2003)));
            
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId">The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <returns>InlineResponse2004</returns>
        public InlineResponse2004 ArtistRelatedGetGet (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null)
        {
             ApiResponse<InlineResponse2004> localVarResponse = ArtistRelatedGetGetWithHttpInfo(artistId, format, callback, pageSize, page);
             return localVarResponse.Data;
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId">The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <returns>ApiResponse of InlineResponse2004</returns>
        public ApiResponse< InlineResponse2004 > ArtistRelatedGetGetWithHttpInfo (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null)
        {
            // verify the required parameter 'artistId' is set
            if (artistId == null)
                throw new ApiException(400, "Missing required parameter 'artistId' when calling ArtistApi->ArtistRelatedGetGet");

            var localVarPath = "/artist.related.get";
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/json"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            if (format != null) localVarQueryParams.Add("format", Configuration.ApiClient.ParameterToString(format)); // query parameter
            if (callback != null) localVarQueryParams.Add("callback", Configuration.ApiClient.ParameterToString(callback)); // query parameter
            if (artistId != null) localVarQueryParams.Add("artist_id", Configuration.ApiClient.ParameterToString(artistId)); // query parameter
            if (pageSize != null) localVarQueryParams.Add("page_size", Configuration.ApiClient.ParameterToString(pageSize)); // query parameter
            if (page != null) localVarQueryParams.Add("page", Configuration.ApiClient.ParameterToString(page)); // query parameter

            // authentication (key) required
            if (!String.IsNullOrEmpty(Configuration.GetApiKeyWithPrefix("apikey")))
            {
                localVarQueryParams["apikey"] = Configuration.GetApiKeyWithPrefix("apikey");
            }


            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) Configuration.ApiClient.CallApi(localVarPath,
                Method.GET, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;

            if (ExceptionFactory != null)
            {
                Exception exception = ExceptionFactory("ArtistRelatedGetGet", localVarResponse);
                if (exception != null) throw exception;
            }

            return new ApiResponse<InlineResponse2004>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (InlineResponse2004) Configuration.ApiClient.Deserialize(localVarResponse, typeof(InlineResponse2004)));
            
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId">The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <returns>Task of InlineResponse2004</returns>
        public async System.Threading.Tasks.Task<InlineResponse2004> ArtistRelatedGetGetAsync (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null)
        {
             ApiResponse<InlineResponse2004> localVarResponse = await ArtistRelatedGetGetAsyncWithHttpInfo(artistId, format, callback, pageSize, page);
             return localVarResponse.Data;

        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="artistId">The musiXmatch artist id</param>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <returns>Task of ApiResponse (InlineResponse2004)</returns>
        public async System.Threading.Tasks.Task<ApiResponse<InlineResponse2004>> ArtistRelatedGetGetAsyncWithHttpInfo (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null)
        {
            // verify the required parameter 'artistId' is set
            if (artistId == null)
                throw new ApiException(400, "Missing required parameter 'artistId' when calling ArtistApi->ArtistRelatedGetGet");

            var localVarPath = "/artist.related.get";
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/json"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            if (format != null) localVarQueryParams.Add("format", Configuration.ApiClient.ParameterToString(format)); // query parameter
            if (callback != null) localVarQueryParams.Add("callback", Configuration.ApiClient.ParameterToString(callback)); // query parameter
            if (artistId != null) localVarQueryParams.Add("artist_id", Configuration.ApiClient.ParameterToString(artistId)); // query parameter
            if (pageSize != null) localVarQueryParams.Add("page_size", Configuration.ApiClient.ParameterToString(pageSize)); // query parameter
            if (page != null) localVarQueryParams.Add("page", Configuration.ApiClient.ParameterToString(page)); // query parameter

            // authentication (key) required
            if (!String.IsNullOrEmpty(Configuration.GetApiKeyWithPrefix("apikey")))
            {
                localVarQueryParams["apikey"] = Configuration.GetApiKeyWithPrefix("apikey");
            }

            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) await Configuration.ApiClient.CallApiAsync(localVarPath,
                Method.GET, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;

            if (ExceptionFactory != null)
            {
                Exception exception = ExceptionFactory("ArtistRelatedGetGet", localVarResponse);
                if (exception != null) throw exception;
            }

            return new ApiResponse<InlineResponse2004>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (InlineResponse2004) Configuration.ApiClient.Deserialize(localVarResponse, typeof(InlineResponse2004)));
            
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="qArtist">The song artist (optional)</param>
        /// <param name="fArtistId">When set, filter by this artist id (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <returns>InlineResponse2004</returns>
        public InlineResponse2004 ArtistSearchGet (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null)
        {
             ApiResponse<InlineResponse2004> localVarResponse = ArtistSearchGetWithHttpInfo(format, callback, qArtist, fArtistId, page, pageSize);
             return localVarResponse.Data;
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="qArtist">The song artist (optional)</param>
        /// <param name="fArtistId">When set, filter by this artist id (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <returns>ApiResponse of InlineResponse2004</returns>
        public ApiResponse< InlineResponse2004 > ArtistSearchGetWithHttpInfo (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null)
        {

            var localVarPath = "/artist.search";
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/json"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            if (format != null) localVarQueryParams.Add("format", Configuration.ApiClient.ParameterToString(format)); // query parameter
            if (callback != null) localVarQueryParams.Add("callback", Configuration.ApiClient.ParameterToString(callback)); // query parameter
            if (qArtist != null) localVarQueryParams.Add("q_artist", Configuration.ApiClient.ParameterToString(qArtist)); // query parameter
            if (fArtistId != null) localVarQueryParams.Add("f_artist_id", Configuration.ApiClient.ParameterToString(fArtistId)); // query parameter
            if (page != null) localVarQueryParams.Add("page", Configuration.ApiClient.ParameterToString(page)); // query parameter
            if (pageSize != null) localVarQueryParams.Add("page_size", Configuration.ApiClient.ParameterToString(pageSize)); // query parameter

            // authentication (key) required
            if (!String.IsNullOrEmpty(Configuration.GetApiKeyWithPrefix("apikey")))
            {
                localVarQueryParams["apikey"] = Configuration.GetApiKeyWithPrefix("apikey");
            }


            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) Configuration.ApiClient.CallApi(localVarPath,
                Method.GET, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;

            if (ExceptionFactory != null)
            {
                Exception exception = ExceptionFactory("ArtistSearchGet", localVarResponse);
                if (exception != null) throw exception;
            }

            return new ApiResponse<InlineResponse2004>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (InlineResponse2004) Configuration.ApiClient.Deserialize(localVarResponse, typeof(InlineResponse2004)));
            
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="qArtist">The song artist (optional)</param>
        /// <param name="fArtistId">When set, filter by this artist id (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <returns>Task of InlineResponse2004</returns>
        public async System.Threading.Tasks.Task<InlineResponse2004> ArtistSearchGetAsync (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null)
        {
             ApiResponse<InlineResponse2004> localVarResponse = await ArtistSearchGetAsyncWithHttpInfo(format, callback, qArtist, fArtistId, page, pageSize);
             return localVarResponse.Data;

        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="qArtist">The song artist (optional)</param>
        /// <param name="fArtistId">When set, filter by this artist id (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <returns>Task of ApiResponse (InlineResponse2004)</returns>
        public async System.Threading.Tasks.Task<ApiResponse<InlineResponse2004>> ArtistSearchGetAsyncWithHttpInfo (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null)
        {

            var localVarPath = "/artist.search";
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/json"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            if (format != null) localVarQueryParams.Add("format", Configuration.ApiClient.ParameterToString(format)); // query parameter
            if (callback != null) localVarQueryParams.Add("callback", Configuration.ApiClient.ParameterToString(callback)); // query parameter
            if (qArtist != null) localVarQueryParams.Add("q_artist", Configuration.ApiClient.ParameterToString(qArtist)); // query parameter
            if (fArtistId != null) localVarQueryParams.Add("f_artist_id", Configuration.ApiClient.ParameterToString(fArtistId)); // query parameter
            if (page != null) localVarQueryParams.Add("page", Configuration.ApiClient.ParameterToString(page)); // query parameter
            if (pageSize != null) localVarQueryParams.Add("page_size", Configuration.ApiClient.ParameterToString(pageSize)); // query parameter

            // authentication (key) required
            if (!String.IsNullOrEmpty(Configuration.GetApiKeyWithPrefix("apikey")))
            {
                localVarQueryParams["apikey"] = Configuration.GetApiKeyWithPrefix("apikey");
            }

            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) await Configuration.ApiClient.CallApiAsync(localVarPath,
                Method.GET, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;

            if (ExceptionFactory != null)
            {
                Exception exception = ExceptionFactory("ArtistSearchGet", localVarResponse);
                if (exception != null) throw exception;
            }

            return new ApiResponse<InlineResponse2004>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (InlineResponse2004) Configuration.ApiClient.Deserialize(localVarResponse, typeof(InlineResponse2004)));
            
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="country">A valid ISO 3166 country code (optional, default to us)</param>
        /// <returns>InlineResponse2005</returns>
        public InlineResponse2005 ChartArtistsGetGet (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null)
        {
             ApiResponse<InlineResponse2005> localVarResponse = ChartArtistsGetGetWithHttpInfo(format, callback, page, pageSize, country);
             return localVarResponse.Data;
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="country">A valid ISO 3166 country code (optional, default to us)</param>
        /// <returns>ApiResponse of InlineResponse2005</returns>
        public ApiResponse< InlineResponse2005 > ChartArtistsGetGetWithHttpInfo (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null)
        {

            var localVarPath = "/chart.artists.get";
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/json"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            if (format != null) localVarQueryParams.Add("format", Configuration.ApiClient.ParameterToString(format)); // query parameter
            if (callback != null) localVarQueryParams.Add("callback", Configuration.ApiClient.ParameterToString(callback)); // query parameter
            if (page != null) localVarQueryParams.Add("page", Configuration.ApiClient.ParameterToString(page)); // query parameter
            if (pageSize != null) localVarQueryParams.Add("page_size", Configuration.ApiClient.ParameterToString(pageSize)); // query parameter
            if (country != null) localVarQueryParams.Add("country", Configuration.ApiClient.ParameterToString(country)); // query parameter

            // authentication (key) required
            if (!String.IsNullOrEmpty(Configuration.GetApiKeyWithPrefix("apikey")))
            {
                localVarQueryParams["apikey"] = Configuration.GetApiKeyWithPrefix("apikey");
            }


            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) Configuration.ApiClient.CallApi(localVarPath,
                Method.GET, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;

            if (ExceptionFactory != null)
            {
                Exception exception = ExceptionFactory("ChartArtistsGetGet", localVarResponse);
                if (exception != null) throw exception;
            }

            return new ApiResponse<InlineResponse2005>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (InlineResponse2005) Configuration.ApiClient.Deserialize(localVarResponse, typeof(InlineResponse2005)));
            
        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="country">A valid ISO 3166 country code (optional, default to us)</param>
        /// <returns>Task of InlineResponse2005</returns>
        public async System.Threading.Tasks.Task<InlineResponse2005> ChartArtistsGetGetAsync (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null)
        {
             ApiResponse<InlineResponse2005> localVarResponse = await ChartArtistsGetGetAsyncWithHttpInfo(format, callback, page, pageSize, country);
             return localVarResponse.Data;

        }

        /// <summary>
        ///  
        /// </summary>
        /// <exception cref="IO.Swagger.Client.ApiException">Thrown when fails to make API call</exception>
        /// <param name="format">output format: json, jsonp, xml. (optional, default to json)</param>
        /// <param name="callback">jsonp callback (optional)</param>
        /// <param name="page">Define the page number for paginated results (optional)</param>
        /// <param name="pageSize">Define the page size for paginated results.Range is 1 to 100. (optional)</param>
        /// <param name="country">A valid ISO 3166 country code (optional, default to us)</param>
        /// <returns>Task of ApiResponse (InlineResponse2005)</returns>
        public async System.Threading.Tasks.Task<ApiResponse<InlineResponse2005>> ChartArtistsGetGetAsyncWithHttpInfo (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null)
        {

            var localVarPath = "/chart.artists.get";
            var localVarPathParams = new Dictionary<String, String>();
            var localVarQueryParams = new Dictionary<String, String>();
            var localVarHeaderParams = new Dictionary<String, String>(Configuration.DefaultHeader);
            var localVarFormParams = new Dictionary<String, String>();
            var localVarFileParams = new Dictionary<String, FileParameter>();
            Object localVarPostBody = null;

            // to determine the Content-Type header
            String[] localVarHttpContentTypes = new String[] {
                "application/json"
            };
            String localVarHttpContentType = Configuration.ApiClient.SelectHeaderContentType(localVarHttpContentTypes);

            // to determine the Accept header
            String[] localVarHttpHeaderAccepts = new String[] {
                "application/json"
            };
            String localVarHttpHeaderAccept = Configuration.ApiClient.SelectHeaderAccept(localVarHttpHeaderAccepts);
            if (localVarHttpHeaderAccept != null)
                localVarHeaderParams.Add("Accept", localVarHttpHeaderAccept);

            // set "format" to json by default
            // e.g. /pet/{petId}.{format} becomes /pet/{petId}.json
            localVarPathParams.Add("format", "json");
            if (format != null) localVarQueryParams.Add("format", Configuration.ApiClient.ParameterToString(format)); // query parameter
            if (callback != null) localVarQueryParams.Add("callback", Configuration.ApiClient.ParameterToString(callback)); // query parameter
            if (page != null) localVarQueryParams.Add("page", Configuration.ApiClient.ParameterToString(page)); // query parameter
            if (pageSize != null) localVarQueryParams.Add("page_size", Configuration.ApiClient.ParameterToString(pageSize)); // query parameter
            if (country != null) localVarQueryParams.Add("country", Configuration.ApiClient.ParameterToString(country)); // query parameter

            // authentication (key) required
            if (!String.IsNullOrEmpty(Configuration.GetApiKeyWithPrefix("apikey")))
            {
                localVarQueryParams["apikey"] = Configuration.GetApiKeyWithPrefix("apikey");
            }

            // make the HTTP request
            IRestResponse localVarResponse = (IRestResponse) await Configuration.ApiClient.CallApiAsync(localVarPath,
                Method.GET, localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarFileParams,
                localVarPathParams, localVarHttpContentType);

            int localVarStatusCode = (int) localVarResponse.StatusCode;

            if (ExceptionFactory != null)
            {
                Exception exception = ExceptionFactory("ChartArtistsGetGet", localVarResponse);
                if (exception != null) throw exception;
            }

            return new ApiResponse<InlineResponse2005>(localVarStatusCode,
                localVarResponse.Headers.ToDictionary(x => x.Name, x => x.Value.ToString()),
                (InlineResponse2005) Configuration.ApiClient.Deserialize(localVarResponse, typeof(InlineResponse2005)));
            
        }

    }
}
