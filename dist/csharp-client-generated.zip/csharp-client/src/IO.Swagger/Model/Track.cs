/* 
 * Musixmatch API
 *
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop 
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 * Generated by: https://github.com/swagger-api/swagger-codegen.git
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

using System;
using System.Linq;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace IO.Swagger.Model
{
    /// <summary>
    /// a song in the Musixmatch database
    /// </summary>
    [DataContract]
    public partial class Track :  IEquatable<Track>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Track" /> class.
        /// </summary>
        /// <param name="Instrumental">.</param>
        /// <param name="AlbumCoverart350x350">.</param>
        /// <param name="FirstReleaseDate">.</param>
        /// <param name="TrackIsrc">.</param>
        /// <param name="_Explicit">.</param>
        /// <param name="TrackEditUrl">.</param>
        /// <param name="NumFavourite">.</param>
        /// <param name="AlbumCoverart500x500">.</param>
        /// <param name="AlbumName">.</param>
        /// <param name="TrackRating">.</param>
        /// <param name="TrackShareUrl">.</param>
        /// <param name="TrackSoundcloudId">.</param>
        /// <param name="ArtistName">.</param>
        /// <param name="AlbumCoverart800x800">.</param>
        /// <param name="AlbumCoverart100x100">.</param>
        /// <param name="TrackNameTranslationList">TrackNameTranslationList.</param>
        /// <param name="TrackName">.</param>
        /// <param name="Restricted">.</param>
        /// <param name="HasSubtitles">.</param>
        /// <param name="UpdatedTime">.</param>
        /// <param name="SubtitleId">.</param>
        /// <param name="LyricsId">.</param>
        /// <param name="TrackSpotifyId">.</param>
        /// <param name="HasLyrics">.</param>
        /// <param name="ArtistId">.</param>
        /// <param name="AlbumId">.</param>
        /// <param name="ArtistMbid">.</param>
        /// <param name="SecondaryGenres">SecondaryGenres.</param>
        /// <param name="CommontrackVanityId">.</param>
        /// <param name="TrackId">.</param>
        /// <param name="TrackXboxmusicId">.</param>
        /// <param name="PrimaryGenres">PrimaryGenres.</param>
        /// <param name="TrackLength">.</param>
        /// <param name="TrackMbid">.</param>
        /// <param name="CommontrackId">.</param>
        public Track(decimal? Instrumental = null, string AlbumCoverart350x350 = null, string FirstReleaseDate = null, string TrackIsrc = null, decimal? _Explicit = null, string TrackEditUrl = null, decimal? NumFavourite = null, string AlbumCoverart500x500 = null, string AlbumName = null, decimal? TrackRating = null, string TrackShareUrl = null, decimal? TrackSoundcloudId = null, string ArtistName = null, string AlbumCoverart800x800 = null, string AlbumCoverart100x100 = null, List<string> TrackNameTranslationList = null, string TrackName = null, decimal? Restricted = null, decimal? HasSubtitles = null, string UpdatedTime = null, decimal? SubtitleId = null, decimal? LyricsId = null, string TrackSpotifyId = null, decimal? HasLyrics = null, decimal? ArtistId = null, decimal? AlbumId = null, string ArtistMbid = null, TrackSecondaryGenres SecondaryGenres = null, string CommontrackVanityId = null, decimal? TrackId = null, string TrackXboxmusicId = null, TrackPrimaryGenres PrimaryGenres = null, decimal? TrackLength = null, string TrackMbid = null, decimal? CommontrackId = null)
        {
            this.Instrumental = Instrumental;
            this.AlbumCoverart350x350 = AlbumCoverart350x350;
            this.FirstReleaseDate = FirstReleaseDate;
            this.TrackIsrc = TrackIsrc;
            this._Explicit = _Explicit;
            this.TrackEditUrl = TrackEditUrl;
            this.NumFavourite = NumFavourite;
            this.AlbumCoverart500x500 = AlbumCoverart500x500;
            this.AlbumName = AlbumName;
            this.TrackRating = TrackRating;
            this.TrackShareUrl = TrackShareUrl;
            this.TrackSoundcloudId = TrackSoundcloudId;
            this.ArtistName = ArtistName;
            this.AlbumCoverart800x800 = AlbumCoverart800x800;
            this.AlbumCoverart100x100 = AlbumCoverart100x100;
            this.TrackNameTranslationList = TrackNameTranslationList;
            this.TrackName = TrackName;
            this.Restricted = Restricted;
            this.HasSubtitles = HasSubtitles;
            this.UpdatedTime = UpdatedTime;
            this.SubtitleId = SubtitleId;
            this.LyricsId = LyricsId;
            this.TrackSpotifyId = TrackSpotifyId;
            this.HasLyrics = HasLyrics;
            this.ArtistId = ArtistId;
            this.AlbumId = AlbumId;
            this.ArtistMbid = ArtistMbid;
            this.SecondaryGenres = SecondaryGenres;
            this.CommontrackVanityId = CommontrackVanityId;
            this.TrackId = TrackId;
            this.TrackXboxmusicId = TrackXboxmusicId;
            this.PrimaryGenres = PrimaryGenres;
            this.TrackLength = TrackLength;
            this.TrackMbid = TrackMbid;
            this.CommontrackId = CommontrackId;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="instrumental", EmitDefaultValue=false)]
        public decimal? Instrumental { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="album_coverart_350x350", EmitDefaultValue=false)]
        public string AlbumCoverart350x350 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="first_release_date", EmitDefaultValue=false)]
        public string FirstReleaseDate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_isrc", EmitDefaultValue=false)]
        public string TrackIsrc { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="explicit", EmitDefaultValue=false)]
        public decimal? _Explicit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_edit_url", EmitDefaultValue=false)]
        public string TrackEditUrl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="num_favourite", EmitDefaultValue=false)]
        public decimal? NumFavourite { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="album_coverart_500x500", EmitDefaultValue=false)]
        public string AlbumCoverart500x500 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="album_name", EmitDefaultValue=false)]
        public string AlbumName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_rating", EmitDefaultValue=false)]
        public decimal? TrackRating { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_share_url", EmitDefaultValue=false)]
        public string TrackShareUrl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_soundcloud_id", EmitDefaultValue=false)]
        public decimal? TrackSoundcloudId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="artist_name", EmitDefaultValue=false)]
        public string ArtistName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="album_coverart_800x800", EmitDefaultValue=false)]
        public string AlbumCoverart800x800 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="album_coverart_100x100", EmitDefaultValue=false)]
        public string AlbumCoverart100x100 { get; set; }
        /// <summary>
        /// Gets or Sets TrackNameTranslationList
        /// </summary>
        [DataMember(Name="track_name_translation_list", EmitDefaultValue=false)]
        public List<string> TrackNameTranslationList { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_name", EmitDefaultValue=false)]
        public string TrackName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="restricted", EmitDefaultValue=false)]
        public decimal? Restricted { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="has_subtitles", EmitDefaultValue=false)]
        public decimal? HasSubtitles { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="updated_time", EmitDefaultValue=false)]
        public string UpdatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="subtitle_id", EmitDefaultValue=false)]
        public decimal? SubtitleId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="lyrics_id", EmitDefaultValue=false)]
        public decimal? LyricsId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_spotify_id", EmitDefaultValue=false)]
        public string TrackSpotifyId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="has_lyrics", EmitDefaultValue=false)]
        public decimal? HasLyrics { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="artist_id", EmitDefaultValue=false)]
        public decimal? ArtistId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="album_id", EmitDefaultValue=false)]
        public decimal? AlbumId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="artist_mbid", EmitDefaultValue=false)]
        public string ArtistMbid { get; set; }
        /// <summary>
        /// Gets or Sets SecondaryGenres
        /// </summary>
        [DataMember(Name="secondary_genres", EmitDefaultValue=false)]
        public TrackSecondaryGenres SecondaryGenres { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="commontrack_vanity_id", EmitDefaultValue=false)]
        public string CommontrackVanityId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_id", EmitDefaultValue=false)]
        public decimal? TrackId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_xboxmusic_id", EmitDefaultValue=false)]
        public string TrackXboxmusicId { get; set; }
        /// <summary>
        /// Gets or Sets PrimaryGenres
        /// </summary>
        [DataMember(Name="primary_genres", EmitDefaultValue=false)]
        public TrackPrimaryGenres PrimaryGenres { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_length", EmitDefaultValue=false)]
        public decimal? TrackLength { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="track_mbid", EmitDefaultValue=false)]
        public string TrackMbid { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <value></value>
        [DataMember(Name="commontrack_id", EmitDefaultValue=false)]
        public decimal? CommontrackId { get; set; }
        /// <summary>
        /// Returns the string presentation of the object
        /// </summary>
        /// <returns>String presentation of the object</returns>
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append("class Track {\n");
            sb.Append("  Instrumental: ").Append(Instrumental).Append("\n");
            sb.Append("  AlbumCoverart350x350: ").Append(AlbumCoverart350x350).Append("\n");
            sb.Append("  FirstReleaseDate: ").Append(FirstReleaseDate).Append("\n");
            sb.Append("  TrackIsrc: ").Append(TrackIsrc).Append("\n");
            sb.Append("  _Explicit: ").Append(_Explicit).Append("\n");
            sb.Append("  TrackEditUrl: ").Append(TrackEditUrl).Append("\n");
            sb.Append("  NumFavourite: ").Append(NumFavourite).Append("\n");
            sb.Append("  AlbumCoverart500x500: ").Append(AlbumCoverart500x500).Append("\n");
            sb.Append("  AlbumName: ").Append(AlbumName).Append("\n");
            sb.Append("  TrackRating: ").Append(TrackRating).Append("\n");
            sb.Append("  TrackShareUrl: ").Append(TrackShareUrl).Append("\n");
            sb.Append("  TrackSoundcloudId: ").Append(TrackSoundcloudId).Append("\n");
            sb.Append("  ArtistName: ").Append(ArtistName).Append("\n");
            sb.Append("  AlbumCoverart800x800: ").Append(AlbumCoverart800x800).Append("\n");
            sb.Append("  AlbumCoverart100x100: ").Append(AlbumCoverart100x100).Append("\n");
            sb.Append("  TrackNameTranslationList: ").Append(TrackNameTranslationList).Append("\n");
            sb.Append("  TrackName: ").Append(TrackName).Append("\n");
            sb.Append("  Restricted: ").Append(Restricted).Append("\n");
            sb.Append("  HasSubtitles: ").Append(HasSubtitles).Append("\n");
            sb.Append("  UpdatedTime: ").Append(UpdatedTime).Append("\n");
            sb.Append("  SubtitleId: ").Append(SubtitleId).Append("\n");
            sb.Append("  LyricsId: ").Append(LyricsId).Append("\n");
            sb.Append("  TrackSpotifyId: ").Append(TrackSpotifyId).Append("\n");
            sb.Append("  HasLyrics: ").Append(HasLyrics).Append("\n");
            sb.Append("  ArtistId: ").Append(ArtistId).Append("\n");
            sb.Append("  AlbumId: ").Append(AlbumId).Append("\n");
            sb.Append("  ArtistMbid: ").Append(ArtistMbid).Append("\n");
            sb.Append("  SecondaryGenres: ").Append(SecondaryGenres).Append("\n");
            sb.Append("  CommontrackVanityId: ").Append(CommontrackVanityId).Append("\n");
            sb.Append("  TrackId: ").Append(TrackId).Append("\n");
            sb.Append("  TrackXboxmusicId: ").Append(TrackXboxmusicId).Append("\n");
            sb.Append("  PrimaryGenres: ").Append(PrimaryGenres).Append("\n");
            sb.Append("  TrackLength: ").Append(TrackLength).Append("\n");
            sb.Append("  TrackMbid: ").Append(TrackMbid).Append("\n");
            sb.Append("  CommontrackId: ").Append(CommontrackId).Append("\n");
            sb.Append("}\n");
            return sb.ToString();
        }
  
        /// <summary>
        /// Returns the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public string ToJson()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }

        /// <summary>
        /// Returns true if objects are equal
        /// </summary>
        /// <param name="obj">Object to be compared</param>
        /// <returns>Boolean</returns>
        public override bool Equals(object obj)
        {
            // credit: http://stackoverflow.com/a/10454552/677735
            return this.Equals(obj as Track);
        }

        /// <summary>
        /// Returns true if Track instances are equal
        /// </summary>
        /// <param name="other">Instance of Track to be compared</param>
        /// <returns>Boolean</returns>
        public bool Equals(Track other)
        {
            // credit: http://stackoverflow.com/a/10454552/677735
            if (other == null)
                return false;

            return 
                (
                    this.Instrumental == other.Instrumental ||
                    this.Instrumental != null &&
                    this.Instrumental.Equals(other.Instrumental)
                ) && 
                (
                    this.AlbumCoverart350x350 == other.AlbumCoverart350x350 ||
                    this.AlbumCoverart350x350 != null &&
                    this.AlbumCoverart350x350.Equals(other.AlbumCoverart350x350)
                ) && 
                (
                    this.FirstReleaseDate == other.FirstReleaseDate ||
                    this.FirstReleaseDate != null &&
                    this.FirstReleaseDate.Equals(other.FirstReleaseDate)
                ) && 
                (
                    this.TrackIsrc == other.TrackIsrc ||
                    this.TrackIsrc != null &&
                    this.TrackIsrc.Equals(other.TrackIsrc)
                ) && 
                (
                    this._Explicit == other._Explicit ||
                    this._Explicit != null &&
                    this._Explicit.Equals(other._Explicit)
                ) && 
                (
                    this.TrackEditUrl == other.TrackEditUrl ||
                    this.TrackEditUrl != null &&
                    this.TrackEditUrl.Equals(other.TrackEditUrl)
                ) && 
                (
                    this.NumFavourite == other.NumFavourite ||
                    this.NumFavourite != null &&
                    this.NumFavourite.Equals(other.NumFavourite)
                ) && 
                (
                    this.AlbumCoverart500x500 == other.AlbumCoverart500x500 ||
                    this.AlbumCoverart500x500 != null &&
                    this.AlbumCoverart500x500.Equals(other.AlbumCoverart500x500)
                ) && 
                (
                    this.AlbumName == other.AlbumName ||
                    this.AlbumName != null &&
                    this.AlbumName.Equals(other.AlbumName)
                ) && 
                (
                    this.TrackRating == other.TrackRating ||
                    this.TrackRating != null &&
                    this.TrackRating.Equals(other.TrackRating)
                ) && 
                (
                    this.TrackShareUrl == other.TrackShareUrl ||
                    this.TrackShareUrl != null &&
                    this.TrackShareUrl.Equals(other.TrackShareUrl)
                ) && 
                (
                    this.TrackSoundcloudId == other.TrackSoundcloudId ||
                    this.TrackSoundcloudId != null &&
                    this.TrackSoundcloudId.Equals(other.TrackSoundcloudId)
                ) && 
                (
                    this.ArtistName == other.ArtistName ||
                    this.ArtistName != null &&
                    this.ArtistName.Equals(other.ArtistName)
                ) && 
                (
                    this.AlbumCoverart800x800 == other.AlbumCoverart800x800 ||
                    this.AlbumCoverart800x800 != null &&
                    this.AlbumCoverart800x800.Equals(other.AlbumCoverart800x800)
                ) && 
                (
                    this.AlbumCoverart100x100 == other.AlbumCoverart100x100 ||
                    this.AlbumCoverart100x100 != null &&
                    this.AlbumCoverart100x100.Equals(other.AlbumCoverart100x100)
                ) && 
                (
                    this.TrackNameTranslationList == other.TrackNameTranslationList ||
                    this.TrackNameTranslationList != null &&
                    this.TrackNameTranslationList.SequenceEqual(other.TrackNameTranslationList)
                ) && 
                (
                    this.TrackName == other.TrackName ||
                    this.TrackName != null &&
                    this.TrackName.Equals(other.TrackName)
                ) && 
                (
                    this.Restricted == other.Restricted ||
                    this.Restricted != null &&
                    this.Restricted.Equals(other.Restricted)
                ) && 
                (
                    this.HasSubtitles == other.HasSubtitles ||
                    this.HasSubtitles != null &&
                    this.HasSubtitles.Equals(other.HasSubtitles)
                ) && 
                (
                    this.UpdatedTime == other.UpdatedTime ||
                    this.UpdatedTime != null &&
                    this.UpdatedTime.Equals(other.UpdatedTime)
                ) && 
                (
                    this.SubtitleId == other.SubtitleId ||
                    this.SubtitleId != null &&
                    this.SubtitleId.Equals(other.SubtitleId)
                ) && 
                (
                    this.LyricsId == other.LyricsId ||
                    this.LyricsId != null &&
                    this.LyricsId.Equals(other.LyricsId)
                ) && 
                (
                    this.TrackSpotifyId == other.TrackSpotifyId ||
                    this.TrackSpotifyId != null &&
                    this.TrackSpotifyId.Equals(other.TrackSpotifyId)
                ) && 
                (
                    this.HasLyrics == other.HasLyrics ||
                    this.HasLyrics != null &&
                    this.HasLyrics.Equals(other.HasLyrics)
                ) && 
                (
                    this.ArtistId == other.ArtistId ||
                    this.ArtistId != null &&
                    this.ArtistId.Equals(other.ArtistId)
                ) && 
                (
                    this.AlbumId == other.AlbumId ||
                    this.AlbumId != null &&
                    this.AlbumId.Equals(other.AlbumId)
                ) && 
                (
                    this.ArtistMbid == other.ArtistMbid ||
                    this.ArtistMbid != null &&
                    this.ArtistMbid.Equals(other.ArtistMbid)
                ) && 
                (
                    this.SecondaryGenres == other.SecondaryGenres ||
                    this.SecondaryGenres != null &&
                    this.SecondaryGenres.Equals(other.SecondaryGenres)
                ) && 
                (
                    this.CommontrackVanityId == other.CommontrackVanityId ||
                    this.CommontrackVanityId != null &&
                    this.CommontrackVanityId.Equals(other.CommontrackVanityId)
                ) && 
                (
                    this.TrackId == other.TrackId ||
                    this.TrackId != null &&
                    this.TrackId.Equals(other.TrackId)
                ) && 
                (
                    this.TrackXboxmusicId == other.TrackXboxmusicId ||
                    this.TrackXboxmusicId != null &&
                    this.TrackXboxmusicId.Equals(other.TrackXboxmusicId)
                ) && 
                (
                    this.PrimaryGenres == other.PrimaryGenres ||
                    this.PrimaryGenres != null &&
                    this.PrimaryGenres.Equals(other.PrimaryGenres)
                ) && 
                (
                    this.TrackLength == other.TrackLength ||
                    this.TrackLength != null &&
                    this.TrackLength.Equals(other.TrackLength)
                ) && 
                (
                    this.TrackMbid == other.TrackMbid ||
                    this.TrackMbid != null &&
                    this.TrackMbid.Equals(other.TrackMbid)
                ) && 
                (
                    this.CommontrackId == other.CommontrackId ||
                    this.CommontrackId != null &&
                    this.CommontrackId.Equals(other.CommontrackId)
                );
        }

        /// <summary>
        /// Gets the hash code
        /// </summary>
        /// <returns>Hash code</returns>
        public override int GetHashCode()
        {
            // credit: http://stackoverflow.com/a/263416/677735
            unchecked // Overflow is fine, just wrap
            {
                int hash = 41;
                // Suitable nullity checks etc, of course :)
                if (this.Instrumental != null)
                    hash = hash * 59 + this.Instrumental.GetHashCode();
                if (this.AlbumCoverart350x350 != null)
                    hash = hash * 59 + this.AlbumCoverart350x350.GetHashCode();
                if (this.FirstReleaseDate != null)
                    hash = hash * 59 + this.FirstReleaseDate.GetHashCode();
                if (this.TrackIsrc != null)
                    hash = hash * 59 + this.TrackIsrc.GetHashCode();
                if (this._Explicit != null)
                    hash = hash * 59 + this._Explicit.GetHashCode();
                if (this.TrackEditUrl != null)
                    hash = hash * 59 + this.TrackEditUrl.GetHashCode();
                if (this.NumFavourite != null)
                    hash = hash * 59 + this.NumFavourite.GetHashCode();
                if (this.AlbumCoverart500x500 != null)
                    hash = hash * 59 + this.AlbumCoverart500x500.GetHashCode();
                if (this.AlbumName != null)
                    hash = hash * 59 + this.AlbumName.GetHashCode();
                if (this.TrackRating != null)
                    hash = hash * 59 + this.TrackRating.GetHashCode();
                if (this.TrackShareUrl != null)
                    hash = hash * 59 + this.TrackShareUrl.GetHashCode();
                if (this.TrackSoundcloudId != null)
                    hash = hash * 59 + this.TrackSoundcloudId.GetHashCode();
                if (this.ArtistName != null)
                    hash = hash * 59 + this.ArtistName.GetHashCode();
                if (this.AlbumCoverart800x800 != null)
                    hash = hash * 59 + this.AlbumCoverart800x800.GetHashCode();
                if (this.AlbumCoverart100x100 != null)
                    hash = hash * 59 + this.AlbumCoverart100x100.GetHashCode();
                if (this.TrackNameTranslationList != null)
                    hash = hash * 59 + this.TrackNameTranslationList.GetHashCode();
                if (this.TrackName != null)
                    hash = hash * 59 + this.TrackName.GetHashCode();
                if (this.Restricted != null)
                    hash = hash * 59 + this.Restricted.GetHashCode();
                if (this.HasSubtitles != null)
                    hash = hash * 59 + this.HasSubtitles.GetHashCode();
                if (this.UpdatedTime != null)
                    hash = hash * 59 + this.UpdatedTime.GetHashCode();
                if (this.SubtitleId != null)
                    hash = hash * 59 + this.SubtitleId.GetHashCode();
                if (this.LyricsId != null)
                    hash = hash * 59 + this.LyricsId.GetHashCode();
                if (this.TrackSpotifyId != null)
                    hash = hash * 59 + this.TrackSpotifyId.GetHashCode();
                if (this.HasLyrics != null)
                    hash = hash * 59 + this.HasLyrics.GetHashCode();
                if (this.ArtistId != null)
                    hash = hash * 59 + this.ArtistId.GetHashCode();
                if (this.AlbumId != null)
                    hash = hash * 59 + this.AlbumId.GetHashCode();
                if (this.ArtistMbid != null)
                    hash = hash * 59 + this.ArtistMbid.GetHashCode();
                if (this.SecondaryGenres != null)
                    hash = hash * 59 + this.SecondaryGenres.GetHashCode();
                if (this.CommontrackVanityId != null)
                    hash = hash * 59 + this.CommontrackVanityId.GetHashCode();
                if (this.TrackId != null)
                    hash = hash * 59 + this.TrackId.GetHashCode();
                if (this.TrackXboxmusicId != null)
                    hash = hash * 59 + this.TrackXboxmusicId.GetHashCode();
                if (this.PrimaryGenres != null)
                    hash = hash * 59 + this.PrimaryGenres.GetHashCode();
                if (this.TrackLength != null)
                    hash = hash * 59 + this.TrackLength.GetHashCode();
                if (this.TrackMbid != null)
                    hash = hash * 59 + this.TrackMbid.GetHashCode();
                if (this.CommontrackId != null)
                    hash = hash * 59 + this.CommontrackId.GetHashCode();
                return hash;
            }
        }
    }

}
