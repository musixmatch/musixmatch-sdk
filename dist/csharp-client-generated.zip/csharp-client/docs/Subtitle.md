# IO.Swagger.Model.Subtitle
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SubtitleBody** | **string** |  | [optional] 
**PublisherList** | **List&lt;string&gt;** |  | [optional] 
**SubtitleLanguage** | **string** |  | [optional] 
**SubtitleLanguageDescription** | **string** |  | [optional] 
**SubtitleId** | **decimal?** |  | [optional] 
**PixelTrackingUrl** | **string** |  | [optional] 
**HtmlTrackingUrl** | **string** |  | [optional] 
**Restricted** | **decimal?** |  | [optional] 
**LyricsCopyright** | **string** |  | [optional] 
**ScriptTrackingUrl** | **string** |  | [optional] 
**SubtitleLength** | **decimal?** |  | [optional] 
**UpdatedTime** | **string** |  | [optional] 
**WriterList** | **List&lt;string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

