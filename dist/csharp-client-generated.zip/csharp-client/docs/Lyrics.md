# IO.Swagger.Model.Lyrics
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Instrumental** | **decimal?** |  | [optional] 
**PixelTrackingUrl** | **string** |  | [optional] 
**PublisherList** | **List&lt;string&gt;** |  | [optional] 
**LyricsLanguageDescription** | **string** |  | [optional] 
**Restricted** | **decimal?** |  | [optional] 
**UpdatedTime** | **string** |  | [optional] 
**_Explicit** | **decimal?** |  | [optional] 
**LyricsCopyright** | **string** |  | [optional] 
**HtmlTrackingUrl** | **string** |  | [optional] 
**LyricsLanguage** | **string** |  | [optional] 
**ScriptTrackingUrl** | **string** |  | [optional] 
**Verified** | **decimal?** |  | [optional] 
**LyricsBody** | **string** |  | [optional] 
**LyricsId** | **decimal?** |  | [optional] 
**WriterList** | **List&lt;string&gt;** |  | [optional] 
**CanEdit** | **decimal?** |  | [optional] 
**ActionRequested** | **string** |  | [optional] 
**Locked** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

