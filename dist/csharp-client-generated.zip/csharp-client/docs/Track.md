# IO.Swagger.Model.Track
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Instrumental** | **decimal?** |  | [optional] 
**AlbumCoverart350x350** | **string** |  | [optional] 
**FirstReleaseDate** | **string** |  | [optional] 
**TrackIsrc** | **string** |  | [optional] 
**_Explicit** | **decimal?** |  | [optional] 
**TrackEditUrl** | **string** |  | [optional] 
**NumFavourite** | **decimal?** |  | [optional] 
**AlbumCoverart500x500** | **string** |  | [optional] 
**AlbumName** | **string** |  | [optional] 
**TrackRating** | **decimal?** |  | [optional] 
**TrackShareUrl** | **string** |  | [optional] 
**TrackSoundcloudId** | **decimal?** |  | [optional] 
**ArtistName** | **string** |  | [optional] 
**AlbumCoverart800x800** | **string** |  | [optional] 
**AlbumCoverart100x100** | **string** |  | [optional] 
**TrackNameTranslationList** | **List&lt;string&gt;** |  | [optional] 
**TrackName** | **string** |  | [optional] 
**Restricted** | **decimal?** |  | [optional] 
**HasSubtitles** | **decimal?** |  | [optional] 
**UpdatedTime** | **string** |  | [optional] 
**SubtitleId** | **decimal?** |  | [optional] 
**LyricsId** | **decimal?** |  | [optional] 
**TrackSpotifyId** | **string** |  | [optional] 
**HasLyrics** | **decimal?** |  | [optional] 
**ArtistId** | **decimal?** |  | [optional] 
**AlbumId** | **decimal?** |  | [optional] 
**ArtistMbid** | **string** |  | [optional] 
**SecondaryGenres** | [**TrackSecondaryGenres**](TrackSecondaryGenres.md) |  | [optional] 
**CommontrackVanityId** | **string** |  | [optional] 
**TrackId** | **decimal?** |  | [optional] 
**TrackXboxmusicId** | **string** |  | [optional] 
**PrimaryGenres** | [**TrackPrimaryGenres**](TrackPrimaryGenres.md) |  | [optional] 
**TrackLength** | **decimal?** |  | [optional] 
**TrackMbid** | **string** |  | [optional] 
**CommontrackId** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

