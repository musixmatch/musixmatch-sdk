# IO.Swagger.Model.InlineResponse2001MessageBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TrackList** | [**List&lt;Track&gt;**](Track.md) | A list of tracks | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

