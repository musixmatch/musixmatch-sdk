# IO.Swagger.Model.InlineResponse2001MessageHeader
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StatusCode** | **decimal?** |  | [optional] 
**Available** | **decimal?** |  | [optional] 
**ExecuteTime** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

