# IO.Swagger.Model.AlbumPrimaryGenresMusicGenre
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MusicGenreNameExtended** | **string** |  | [optional] 
**MusicGenreVanity** | **string** |  | [optional] 
**MusicGenreParentId** | **decimal?** |  | [optional] 
**MusicGenreId** | **decimal?** |  | [optional] 
**MusicGenreName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

