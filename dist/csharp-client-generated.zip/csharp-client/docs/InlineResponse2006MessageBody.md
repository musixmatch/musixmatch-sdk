# IO.Swagger.Model.InlineResponse2006MessageBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TrackList** | [**List&lt;InlineResponse2006MessageBodyTrackList&gt;**](InlineResponse2006MessageBodyTrackList.md) | A list of tracks | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

