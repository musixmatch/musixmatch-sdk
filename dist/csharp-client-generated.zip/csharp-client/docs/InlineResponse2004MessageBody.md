# IO.Swagger.Model.InlineResponse2004MessageBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArtistList** | [**List&lt;InlineResponse2003MessageBody&gt;**](InlineResponse2003MessageBody.md) | A list of artists | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

