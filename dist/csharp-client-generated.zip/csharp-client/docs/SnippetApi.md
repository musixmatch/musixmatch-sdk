# IO.Swagger.Api.SnippetApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**TrackSnippetGetGet**](SnippetApi.md#tracksnippetgetget) | **GET** /track.snippet.get | 


<a name="tracksnippetgetget"></a>
# **TrackSnippetGetGet**
> InlineResponse20010 TrackSnippetGetGet (string trackId, string format = null, string callback = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TrackSnippetGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new SnippetApi();
            var trackId = trackId_example;  // string | The musiXmatch track id
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 

            try
            {
                // 
                InlineResponse20010 result = apiInstance.TrackSnippetGetGet(trackId, format, callback);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SnippetApi.TrackSnippetGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trackId** | **string**| The musiXmatch track id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse20010**](InlineResponse20010.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

