# IO.Swagger.Model.Album
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlbumCoverart500x500** | **string** |  | [optional] 
**Restricted** | **decimal?** |  | [optional] 
**ArtistId** | **decimal?** |  | [optional] 
**AlbumName** | **string** |  | [optional] 
**AlbumCoverart800x800** | **string** |  | [optional] 
**AlbumCopyright** | **string** |  | [optional] 
**AlbumCoverart350x350** | **string** |  | [optional] 
**ArtistName** | **string** |  | [optional] 
**PrimaryGenres** | [**AlbumPrimaryGenres**](AlbumPrimaryGenres.md) |  | [optional] 
**AlbumId** | **decimal?** |  | [optional] 
**AlbumRating** | **decimal?** |  | [optional] 
**AlbumPline** | **string** |  | [optional] 
**AlbumTrackCount** | **decimal?** |  | [optional] 
**AlbumReleaseType** | **string** |  | [optional] 
**AlbumReleaseDate** | **string** |  | [optional] 
**AlbumEditUrl** | **string** |  | [optional] 
**UpdatedTime** | **string** |  | [optional] 
**SecondaryGenres** | [**ArtistSecondaryGenres**](ArtistSecondaryGenres.md) |  | [optional] 
**AlbumMbid** | **string** |  | [optional] 
**AlbumVanityId** | **string** |  | [optional] 
**AlbumCoverart100x100** | **string** |  | [optional] 
**AlbumLabel** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

