# IO.Swagger.Model.InlineResponse2002MessageBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlbumList** | [**List&lt;InlineResponse200MessageBody&gt;**](InlineResponse200MessageBody.md) | A list of albums | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

