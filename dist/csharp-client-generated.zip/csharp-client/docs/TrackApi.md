# IO.Swagger.Api.TrackApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AlbumTracksGetGet**](TrackApi.md#albumtracksgetget) | **GET** /album.tracks.get | 
[**ChartTracksGetGet**](TrackApi.md#charttracksgetget) | **GET** /chart.tracks.get | 
[**MatcherTrackGetGet**](TrackApi.md#matchertrackgetget) | **GET** /matcher.track.get | 
[**TrackGetGet**](TrackApi.md#trackgetget) | **GET** /track.get | 
[**TrackSearchGet**](TrackApi.md#tracksearchget) | **GET** /track.search | 


<a name="albumtracksgetget"></a>
# **AlbumTracksGetGet**
> InlineResponse2001 AlbumTracksGetGet (string albumId, string format = null, string callback = null, string fHasLyrics = null, decimal? page = null, decimal? pageSize = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AlbumTracksGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new TrackApi();
            var albumId = albumId_example;  // string | The musiXmatch album id
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var fHasLyrics = fHasLyrics_example;  // string | When set, filter only contents with lyrics (optional) 
            var page = 3.4;  // decimal? | Define the page number for paginated results (optional) 
            var pageSize = 3.4;  // decimal? | Define the page size for paginated results.Range is 1 to 100. (optional) 

            try
            {
                // 
                InlineResponse2001 result = apiInstance.AlbumTracksGetGet(albumId, format, callback, fHasLyrics, page, pageSize);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TrackApi.AlbumTracksGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **albumId** | **string**| The musiXmatch album id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **fHasLyrics** | **string**| When set, filter only contents with lyrics | [optional] 
 **page** | **decimal?**| Define the page number for paginated results | [optional] 
 **pageSize** | **decimal?**| Define the page size for paginated results.Range is 1 to 100. | [optional] 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="charttracksgetget"></a>
# **ChartTracksGetGet**
> InlineResponse2006 ChartTracksGetGet (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null, string fHasLyrics = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ChartTracksGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new TrackApi();
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var page = 3.4;  // decimal? | Define the page number for paginated results (optional) 
            var pageSize = 3.4;  // decimal? | Define the page size for paginated results.Range is 1 to 100. (optional) 
            var country = country_example;  // string | A valid ISO 3166 country code (optional)  (default to us)
            var fHasLyrics = fHasLyrics_example;  // string | When set, filter only contents with lyrics (optional) 

            try
            {
                // 
                InlineResponse2006 result = apiInstance.ChartTracksGetGet(format, callback, page, pageSize, country, fHasLyrics);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TrackApi.ChartTracksGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **page** | **decimal?**| Define the page number for paginated results | [optional] 
 **pageSize** | **decimal?**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **country** | **string**| A valid ISO 3166 country code | [optional] [default to us]
 **fHasLyrics** | **string**| When set, filter only contents with lyrics | [optional] 

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="matchertrackgetget"></a>
# **MatcherTrackGetGet**
> InlineResponse2009 MatcherTrackGetGet (string format = null, string callback = null, string qArtist = null, string qTrack = null, decimal? fHasLyrics = null, decimal? fHasSubtitle = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MatcherTrackGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new TrackApi();
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var qArtist = qArtist_example;  // string | The song artist (optional) 
            var qTrack = qTrack_example;  // string | The song title (optional) 
            var fHasLyrics = 3.4;  // decimal? | When set, filter only contents with lyrics (optional) 
            var fHasSubtitle = 3.4;  // decimal? | When set, filter only contents with subtitles (optional) 

            try
            {
                // 
                InlineResponse2009 result = apiInstance.MatcherTrackGetGet(format, callback, qArtist, qTrack, fHasLyrics, fHasSubtitle);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TrackApi.MatcherTrackGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **qArtist** | **string**| The song artist | [optional] 
 **qTrack** | **string**| The song title | [optional] 
 **fHasLyrics** | **decimal?**| When set, filter only contents with lyrics | [optional] 
 **fHasSubtitle** | **decimal?**| When set, filter only contents with subtitles | [optional] 

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="trackgetget"></a>
# **TrackGetGet**
> InlineResponse2009 TrackGetGet (string trackId, string format = null, string callback = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TrackGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new TrackApi();
            var trackId = trackId_example;  // string | The musiXmatch track id
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 

            try
            {
                // 
                InlineResponse2009 result = apiInstance.TrackGetGet(trackId, format, callback);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TrackApi.TrackGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trackId** | **string**| The musiXmatch track id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="tracksearchget"></a>
# **TrackSearchGet**
> InlineResponse2006 TrackSearchGet (string format = null, string callback = null, string qTrack = null, string qArtist = null, string qLyrics = null, decimal? fArtistId = null, decimal? fMusicGenreId = null, decimal? fLyricsLanguage = null, decimal? fHasLyrics = null, string sArtistRating = null, string sTrackRating = null, decimal? quorumFactor = null, decimal? pageSize = null, decimal? page = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TrackSearchGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new TrackApi();
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var qTrack = qTrack_example;  // string | The song title (optional) 
            var qArtist = qArtist_example;  // string | The song artist (optional) 
            var qLyrics = qLyrics_example;  // string | Any word in the lyrics (optional) 
            var fArtistId = 3.4;  // decimal? | When set, filter by this artist id (optional) 
            var fMusicGenreId = 3.4;  // decimal? | When set, filter by this music category id (optional) 
            var fLyricsLanguage = 3.4;  // decimal? | Filter by the lyrics language (en,it,..) (optional) 
            var fHasLyrics = 3.4;  // decimal? | When set, filter only contents with lyrics (optional) 
            var sArtistRating = sArtistRating_example;  // string | Sort by our popularity index for artists (asc|desc) (optional) 
            var sTrackRating = sTrackRating_example;  // string | Sort by our popularity index for tracks (asc|desc) (optional) 
            var quorumFactor = 3.4;  // decimal? | Search only a part of the given query string.Allowed range is (0.1 – 0.9) (optional)  (default to 1)
            var pageSize = 3.4;  // decimal? | Define the page size for paginated results.Range is 1 to 100. (optional) 
            var page = 3.4;  // decimal? | Define the page number for paginated results (optional) 

            try
            {
                // 
                InlineResponse2006 result = apiInstance.TrackSearchGet(format, callback, qTrack, qArtist, qLyrics, fArtistId, fMusicGenreId, fLyricsLanguage, fHasLyrics, sArtistRating, sTrackRating, quorumFactor, pageSize, page);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling TrackApi.TrackSearchGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **qTrack** | **string**| The song title | [optional] 
 **qArtist** | **string**| The song artist | [optional] 
 **qLyrics** | **string**| Any word in the lyrics | [optional] 
 **fArtistId** | **decimal?**| When set, filter by this artist id | [optional] 
 **fMusicGenreId** | **decimal?**| When set, filter by this music category id | [optional] 
 **fLyricsLanguage** | **decimal?**| Filter by the lyrics language (en,it,..) | [optional] 
 **fHasLyrics** | **decimal?**| When set, filter only contents with lyrics | [optional] 
 **sArtistRating** | **string**| Sort by our popularity index for artists (asc|desc) | [optional] 
 **sTrackRating** | **string**| Sort by our popularity index for tracks (asc|desc) | [optional] 
 **quorumFactor** | **decimal?**| Search only a part of the given query string.Allowed range is (0.1 – 0.9) | [optional] [default to 1]
 **pageSize** | **decimal?**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **decimal?**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

