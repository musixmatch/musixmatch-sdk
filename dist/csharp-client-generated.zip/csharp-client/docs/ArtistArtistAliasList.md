# IO.Swagger.Model.ArtistArtistAliasList
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArtistAlias** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

