# IO.Swagger.Model.InlineResponse2004
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Message** | [**InlineResponse2004Message**](InlineResponse2004Message.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

