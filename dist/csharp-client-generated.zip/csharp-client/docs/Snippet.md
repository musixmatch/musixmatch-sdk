# IO.Swagger.Model.Snippet
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HtmlTrackingUrl** | **string** |  | [optional] 
**Instrumental** | **decimal?** |  | [optional] 
**Restricted** | **decimal?** |  | [optional] 
**UpdatedTime** | **string** |  | [optional] 
**SnippetBody** | **string** |  | [optional] 
**PixelTrackingUrl** | **string** |  | [optional] 
**SnippetId** | **decimal?** |  | [optional] 
**ScriptTrackingUrl** | **string** |  | [optional] 
**SnippetLanguage** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

