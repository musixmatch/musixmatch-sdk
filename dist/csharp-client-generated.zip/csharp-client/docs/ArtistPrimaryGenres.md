# IO.Swagger.Model.ArtistPrimaryGenres
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MusicGenreList** | [**List&lt;ArtistPrimaryGenresMusicGenreList&gt;**](ArtistPrimaryGenresMusicGenreList.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

