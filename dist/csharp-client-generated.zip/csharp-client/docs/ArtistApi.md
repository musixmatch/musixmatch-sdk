# IO.Swagger.Api.ArtistApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ArtistGetGet**](ArtistApi.md#artistgetget) | **GET** /artist.get | 
[**ArtistRelatedGetGet**](ArtistApi.md#artistrelatedgetget) | **GET** /artist.related.get | 
[**ArtistSearchGet**](ArtistApi.md#artistsearchget) | **GET** /artist.search | 
[**ChartArtistsGetGet**](ArtistApi.md#chartartistsgetget) | **GET** /chart.artists.get | 


<a name="artistgetget"></a>
# **ArtistGetGet**
> InlineResponse2003 ArtistGetGet (string artistId, string format = null, string callback = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArtistGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new ArtistApi();
            var artistId = artistId_example;  // string |  The musiXmatch artist id
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 

            try
            {
                // 
                InlineResponse2003 result = apiInstance.ArtistGetGet(artistId, format, callback);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArtistApi.ArtistGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artistId** | **string**|  The musiXmatch artist id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="artistrelatedgetget"></a>
# **ArtistRelatedGetGet**
> InlineResponse2004 ArtistRelatedGetGet (string artistId, string format = null, string callback = null, decimal? pageSize = null, decimal? page = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArtistRelatedGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new ArtistApi();
            var artistId = artistId_example;  // string | The musiXmatch artist id
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var pageSize = 3.4;  // decimal? | Define the page size for paginated results.Range is 1 to 100. (optional) 
            var page = 3.4;  // decimal? | Define the page number for paginated results (optional) 

            try
            {
                // 
                InlineResponse2004 result = apiInstance.ArtistRelatedGetGet(artistId, format, callback, pageSize, page);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArtistApi.ArtistRelatedGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artistId** | **string**| The musiXmatch artist id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **pageSize** | **decimal?**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **decimal?**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="artistsearchget"></a>
# **ArtistSearchGet**
> InlineResponse2004 ArtistSearchGet (string format = null, string callback = null, string qArtist = null, decimal? fArtistId = null, decimal? page = null, decimal? pageSize = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArtistSearchGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new ArtistApi();
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var qArtist = qArtist_example;  // string | The song artist (optional) 
            var fArtistId = 3.4;  // decimal? | When set, filter by this artist id (optional) 
            var page = 3.4;  // decimal? | Define the page number for paginated results (optional) 
            var pageSize = 3.4;  // decimal? | Define the page size for paginated results.Range is 1 to 100. (optional) 

            try
            {
                // 
                InlineResponse2004 result = apiInstance.ArtistSearchGet(format, callback, qArtist, fArtistId, page, pageSize);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArtistApi.ArtistSearchGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **qArtist** | **string**| The song artist | [optional] 
 **fArtistId** | **decimal?**| When set, filter by this artist id | [optional] 
 **page** | **decimal?**| Define the page number for paginated results | [optional] 
 **pageSize** | **decimal?**| Define the page size for paginated results.Range is 1 to 100. | [optional] 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="chartartistsgetget"></a>
# **ChartArtistsGetGet**
> InlineResponse2005 ChartArtistsGetGet (string format = null, string callback = null, decimal? page = null, decimal? pageSize = null, string country = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ChartArtistsGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new ArtistApi();
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var page = 3.4;  // decimal? | Define the page number for paginated results (optional) 
            var pageSize = 3.4;  // decimal? | Define the page size for paginated results.Range is 1 to 100. (optional) 
            var country = country_example;  // string | A valid ISO 3166 country code (optional)  (default to us)

            try
            {
                // 
                InlineResponse2005 result = apiInstance.ChartArtistsGetGet(format, callback, page, pageSize, country);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ArtistApi.ChartArtistsGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **page** | **decimal?**| Define the page number for paginated results | [optional] 
 **pageSize** | **decimal?**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **country** | **string**| A valid ISO 3166 country code | [optional] [default to us]

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

