# IO.Swagger.Model.TrackPrimaryGenresMusicGenre
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MusicGenreVanity** | **string** |  | [optional] 
**MusicGenreNameExtended** | **string** |  | [optional] 
**MusicGenreName** | **string** |  | [optional] 
**MusicGenreParentId** | **decimal?** |  | [optional] 
**MusicGenreId** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

