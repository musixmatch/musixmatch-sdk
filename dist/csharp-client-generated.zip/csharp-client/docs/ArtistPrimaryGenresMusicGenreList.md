# IO.Swagger.Model.ArtistPrimaryGenresMusicGenreList
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MusicGenre** | [**ArtistPrimaryGenresMusicGenre**](ArtistPrimaryGenresMusicGenre.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

