# IO.Swagger.Api.AlbumApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AlbumGetGet**](AlbumApi.md#albumgetget) | **GET** /album.get | 
[**ArtistAlbumsGetGet**](AlbumApi.md#artistalbumsgetget) | **GET** /artist.albums.get | 


<a name="albumgetget"></a>
# **AlbumGetGet**
> InlineResponse200 AlbumGetGet (string albumId, string format = null, string callback = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class AlbumGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new AlbumApi();
            var albumId = albumId_example;  // string | The musiXmatch album id
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 

            try
            {
                // 
                InlineResponse200 result = apiInstance.AlbumGetGet(albumId, format, callback);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlbumApi.AlbumGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **albumId** | **string**| The musiXmatch album id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="artistalbumsgetget"></a>
# **ArtistAlbumsGetGet**
> InlineResponse2002 ArtistAlbumsGetGet (string artistId, string format = null, string callback = null, string sReleaseDate = null, string gAlbumName = null, decimal? pageSize = null, decimal? page = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ArtistAlbumsGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new AlbumApi();
            var artistId = artistId_example;  // string | The musiXmatch artist id
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var sReleaseDate = sReleaseDate_example;  // string | Sort by release date (asc|desc) (optional) 
            var gAlbumName = gAlbumName_example;  // string | Group by Album Name (optional) 
            var pageSize = 3.4;  // decimal? | Define the page size for paginated results.Range is 1 to 100. (optional) 
            var page = 3.4;  // decimal? | Define the page number for paginated results (optional) 

            try
            {
                // 
                InlineResponse2002 result = apiInstance.ArtistAlbumsGetGet(artistId, format, callback, sReleaseDate, gAlbumName, pageSize, page);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AlbumApi.ArtistAlbumsGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artistId** | **string**| The musiXmatch artist id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **sReleaseDate** | **string**| Sort by release date (asc|desc) | [optional] 
 **gAlbumName** | **string**| Group by Album Name | [optional] 
 **pageSize** | **decimal?**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **decimal?**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

