# IO.Swagger.Model.InlineResponse2002MessageHeader
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Available** | **decimal?** |  | [optional] 
**StatusCode** | **decimal?** |  | [optional] 
**ExecuteTime** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

