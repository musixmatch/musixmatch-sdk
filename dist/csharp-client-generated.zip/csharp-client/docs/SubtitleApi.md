# IO.Swagger.Api.SubtitleApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**MatcherSubtitleGetGet**](SubtitleApi.md#matchersubtitlegetget) | **GET** /matcher.subtitle.get | 
[**TrackSubtitleGetGet**](SubtitleApi.md#tracksubtitlegetget) | **GET** /track.subtitle.get | 


<a name="matchersubtitlegetget"></a>
# **MatcherSubtitleGetGet**
> InlineResponse2008 MatcherSubtitleGetGet (string format = null, string callback = null, string qTrack = null, string qArtist = null, decimal? fSubtitleLength = null, decimal? fSubtitleLengthMaxDeviation = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class MatcherSubtitleGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new SubtitleApi();
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 
            var qTrack = qTrack_example;  // string | The song title (optional) 
            var qArtist = qArtist_example;  // string |  The song artist (optional) 
            var fSubtitleLength = 3.4;  // decimal? | Filter by subtitle length in seconds (optional) 
            var fSubtitleLengthMaxDeviation = 3.4;  // decimal? | Max deviation for a subtitle length in seconds (optional) 

            try
            {
                // 
                InlineResponse2008 result = apiInstance.MatcherSubtitleGetGet(format, callback, qTrack, qArtist, fSubtitleLength, fSubtitleLengthMaxDeviation);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SubtitleApi.MatcherSubtitleGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **qTrack** | **string**| The song title | [optional] 
 **qArtist** | **string**|  The song artist | [optional] 
 **fSubtitleLength** | **decimal?**| Filter by subtitle length in seconds | [optional] 
 **fSubtitleLengthMaxDeviation** | **decimal?**| Max deviation for a subtitle length in seconds | [optional] 

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="tracksubtitlegetget"></a>
# **TrackSubtitleGetGet**
> InlineResponse2008 TrackSubtitleGetGet (string trackId, string format = null, string callback = null)





### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TrackSubtitleGetGetExample
    {
        public void main()
        {
            
            // Configure API key authorization: key
            Configuration.Default.ApiKey.Add("apikey", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.ApiKeyPrefix.Add("apikey", "Bearer");

            var apiInstance = new SubtitleApi();
            var trackId = trackId_example;  // string | The musiXmatch track id
            var format = format_example;  // string | output format: json, jsonp, xml. (optional)  (default to json)
            var callback = callback_example;  // string | jsonp callback (optional) 

            try
            {
                // 
                InlineResponse2008 result = apiInstance.TrackSubtitleGetGet(trackId, format, callback);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling SubtitleApi.TrackSubtitleGetGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **trackId** | **string**| The musiXmatch track id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

