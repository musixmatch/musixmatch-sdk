# IO.Swagger.Model.InlineResponse2009Message
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**Body** | [**InlineResponse2006MessageBodyTrackList**](InlineResponse2006MessageBodyTrackList.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

