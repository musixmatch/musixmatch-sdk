# IO.Swagger.Model.Artist
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArtistCredits** | [**ArtistArtistCredits**](ArtistArtistCredits.md) |  | [optional] 
**ArtistMbid** | **string** |  | [optional] 
**ArtistName** | **string** |  | [optional] 
**SecondaryGenres** | [**ArtistSecondaryGenres**](ArtistSecondaryGenres.md) |  | [optional] 
**ArtistAliasList** | [**List&lt;ArtistArtistAliasList&gt;**](ArtistArtistAliasList.md) |  | [optional] 
**ArtistVanityId** | **string** |  | [optional] 
**Restricted** | **decimal?** |  | [optional] 
**ArtistCountry** | **string** |  | [optional] 
**ArtistComment** | **string** |  | [optional] 
**ArtistNameTranslationList** | [**List&lt;ArtistArtistNameTranslationList&gt;**](ArtistArtistNameTranslationList.md) |  | [optional] 
**ArtistEditUrl** | **string** |  | [optional] 
**ArtistShareUrl** | **string** |  | [optional] 
**ArtistId** | **decimal?** |  | [optional] 
**UpdatedTime** | **string** |  | [optional] 
**Managed** | **decimal?** |  | [optional] 
**PrimaryGenres** | [**ArtistPrimaryGenres**](ArtistPrimaryGenres.md) |  | [optional] 
**ArtistTwitterUrl** | **string** |  | [optional] 
**ArtistRating** | **decimal?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

