# Snippet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HtmlTrackingUrl** | **string** |  | [optional] [default to null]
**Instrumental** | **float32** |  | [optional] [default to null]
**Restricted** | **float32** |  | [optional] [default to null]
**UpdatedTime** | **string** |  | [optional] [default to null]
**SnippetBody** | **string** |  | [optional] [default to null]
**PixelTrackingUrl** | **string** |  | [optional] [default to null]
**SnippetId** | **float32** |  | [optional] [default to null]
**ScriptTrackingUrl** | **string** |  | [optional] [default to null]
**SnippetLanguage** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


