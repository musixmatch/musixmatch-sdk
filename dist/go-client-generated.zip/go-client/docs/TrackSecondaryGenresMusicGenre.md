# TrackSecondaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MusicGenreVanity** | **string** |  | [optional] [default to null]
**MusicGenreNameExtended** | **string** |  | [optional] [default to null]
**MusicGenreParentId** | **float32** |  | [optional] [default to null]
**MusicGenreName** | **string** |  | [optional] [default to null]
**MusicGenreId** | **float32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


