# InlineResponse2001MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StatusCode** | **float32** |  | [optional] [default to null]
**Available** | **float32** |  | [optional] [default to null]
**ExecuteTime** | **float32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


