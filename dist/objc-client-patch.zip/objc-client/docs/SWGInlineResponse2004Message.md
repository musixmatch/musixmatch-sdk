# SWGInlineResponse2004Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**SWGInlineResponse2002MessageHeader***](SWGInlineResponse2002MessageHeader.md) |  | [optional] 
**body** | [**SWGInlineResponse2004MessageBody***](SWGInlineResponse2004MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


