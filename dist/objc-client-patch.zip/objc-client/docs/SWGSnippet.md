# SWGSnippet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**htmlTrackingUrl** | **NSString*** |  | [optional] 
**instrumental** | **NSNumber*** |  | [optional] 
**restricted** | **NSNumber*** |  | [optional] 
**updatedTime** | **NSString*** |  | [optional] 
**snippetBody** | **NSString*** |  | [optional] 
**pixelTrackingUrl** | **NSString*** |  | [optional] 
**snippetId** | **NSNumber*** |  | [optional] 
**scriptTrackingUrl** | **NSString*** |  | [optional] 
**snippetLanguage** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


