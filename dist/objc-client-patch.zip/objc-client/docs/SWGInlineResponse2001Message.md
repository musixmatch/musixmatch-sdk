# SWGInlineResponse2001Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**SWGInlineResponse2001MessageHeader***](SWGInlineResponse2001MessageHeader.md) |  | [optional] 
**body** | [**SWGInlineResponse2001MessageBody***](SWGInlineResponse2001MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


