# SWGAlbumPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreNameExtended** | **NSString*** |  | [optional] 
**musicGenreVanity** | **NSString*** |  | [optional] 
**musicGenreParentId** | **NSNumber*** |  | [optional] 
**musicGenreId** | **NSNumber*** |  | [optional] 
**musicGenreName** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


