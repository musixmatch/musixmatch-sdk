# SWGLyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | **NSNumber*** |  | [optional] 
**pixelTrackingUrl** | **NSString*** |  | [optional] 
**publisherList** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**lyricsLanguageDescription** | **NSString*** |  | [optional] 
**restricted** | **NSNumber*** |  | [optional] 
**updatedTime** | **NSString*** |  | [optional] 
**explicit** | **NSNumber*** |  | [optional] 
**lyricsCopyright** | **NSString*** |  | [optional] 
**htmlTrackingUrl** | **NSString*** |  | [optional] 
**lyricsLanguage** | **NSString*** |  | [optional] 
**scriptTrackingUrl** | **NSString*** |  | [optional] 
**verified** | **NSNumber*** |  | [optional] 
**lyricsBody** | **NSString*** |  | [optional] 
**lyricsId** | **NSNumber*** |  | [optional] 
**writerList** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**canEdit** | **NSNumber*** |  | [optional] 
**actionRequested** | **NSString*** |  | [optional] 
**locked** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


