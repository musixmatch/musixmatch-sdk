# SWGTrackPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreVanity** | **NSString*** |  | [optional] 
**musicGenreNameExtended** | **NSString*** |  | [optional] 
**musicGenreName** | **NSString*** |  | [optional] 
**musicGenreParentId** | **NSNumber*** |  | [optional] 
**musicGenreId** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


