# SWGArtistPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreParentId** | **NSNumber*** |  | [optional] 
**musicGenreName** | **NSString*** |  | [optional] 
**musicGenreVanity** | **NSString*** |  | [optional] 
**musicGenreId** | **NSNumber*** |  | [optional] 
**musicGenreNameExtended** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


