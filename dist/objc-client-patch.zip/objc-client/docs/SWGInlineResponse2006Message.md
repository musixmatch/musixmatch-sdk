# SWGInlineResponse2006Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**SWGInlineResponse2005MessageHeader***](SWGInlineResponse2005MessageHeader.md) |  | [optional] 
**body** | [**SWGInlineResponse2006MessageBody***](SWGInlineResponse2006MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


