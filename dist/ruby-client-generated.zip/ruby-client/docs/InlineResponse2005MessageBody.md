# SwaggerClient::InlineResponse2005MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_list** | [**Array&lt;InlineResponse2005MessageBodyArtistList&gt;**](InlineResponse2005MessageBodyArtistList.md) |  | [optional] 


