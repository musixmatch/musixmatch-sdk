# SwaggerClient::InlineResponse2002MessageBodyAlbum

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**album_rating** | **Float** |  | [optional] 
**album_pline** | **String** |  | [optional] 
**album_copyright** | **String** |  | [optional] 
**album_edit_url** | **String** |  | [optional] 
**album_name** | **String** |  | [optional] 
**artist_name** | **String** |  | [optional] 
**album_coverart_800x800** | **String** |  | [optional] 
**album_id** | **Float** |  | [optional] 
**album_mbid** | **String** |  | [optional] 
**album_coverart_100x100** | **String** |  | [optional] 
**album_vanity_id** | **String** |  | [optional] 
**album_release_date** | **String** |  | [optional] 
**album_label** | **String** |  | [optional] 
**album_coverart_350x350** | **String** |  | [optional] 
**album_coverart_500x500** | **String** |  | [optional] 
**primary_genres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**album_track_count** | **Float** |  | [optional] 
**album_release_type** | **String** |  | [optional] 
**artist_id** | **Float** |  | [optional] 
**secondary_genres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**updated_time** | **String** |  | [optional] 
**restricted** | **Float** |  | [optional] 


