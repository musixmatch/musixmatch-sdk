# SwaggerClient::InlineResponse20013MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track_list** | [**Array&lt;InlineResponse20013MessageBodyTrackList&gt;**](InlineResponse20013MessageBodyTrackList.md) |  | [optional] 


