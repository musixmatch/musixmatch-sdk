# SwaggerClient::InlineResponse2005MessageBodyArtistArtistCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_list** | [**Array&lt;InlineResponse2005MessageBodyArtistArtistCreditsArtistList&gt;**](InlineResponse2005MessageBodyArtistArtistCreditsArtistList.md) |  | [optional] 


