# SwaggerClient::SubtitleApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**matcher_subtitle_get_get**](SubtitleApi.md#matcher_subtitle_get_get) | **GET** /matcher.subtitle.get | 
[**track_subtitle_get_get**](SubtitleApi.md#track_subtitle_get_get) | **GET** /track.subtitle.get | 


# **matcher_subtitle_get_get**
> InlineResponse2009 matcher_subtitle_get_get(opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::SubtitleApi.new

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  q_track: "q_track_example", # String | The song title
  q_artist: "q_artist_example", # String |  The song artist
  f_subtitle_length: 3.4, # Float | Filter by subtitle length in seconds
  f_subtitle_length_max_deviation: 3.4 # Float | Max deviation for a subtitle length in seconds
}

begin
  #
  result = api_instance.matcher_subtitle_get_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SubtitleApi->matcher_subtitle_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **q_track** | **String**| The song title | [optional] 
 **q_artist** | **String**|  The song artist | [optional] 
 **f_subtitle_length** | **Float**| Filter by subtitle length in seconds | [optional] 
 **f_subtitle_length_max_deviation** | **Float**| Max deviation for a subtitle length in seconds | [optional] 

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **track_subtitle_get_get**
> InlineResponse20015 track_subtitle_get_get(track_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::SubtitleApi.new

track_id = "track_id_example" # String | The musiXmatch track id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example" # String | jsonp callback
}

begin
  #
  result = api_instance.track_subtitle_get_get(track_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SubtitleApi->track_subtitle_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **String**| The musiXmatch track id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 

### Return type

[**InlineResponse20015**](InlineResponse20015.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



