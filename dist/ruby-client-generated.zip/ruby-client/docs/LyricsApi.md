# SwaggerClient::LyricsApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**matcher_lyrics_get_get**](LyricsApi.md#matcher_lyrics_get_get) | **GET** /matcher.lyrics.get | 
[**track_lyrics_get_get**](LyricsApi.md#track_lyrics_get_get) | **GET** /track.lyrics.get | 


# **matcher_lyrics_get_get**
> InlineResponse2008 matcher_lyrics_get_get(opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::LyricsApi.new

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  q_track: "q_track_example", # String | The song title
  q_artist: "q_artist_example" # String | The song artist
}

begin
  #
  result = api_instance.matcher_lyrics_get_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling LyricsApi->matcher_lyrics_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **q_track** | **String**| The song title | [optional] 
 **q_artist** | **String**| The song artist | [optional] 

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **track_lyrics_get_get**
> InlineResponse20012 track_lyrics_get_get(track_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::LyricsApi.new

track_id = "track_id_example" # String | The musiXmatch track id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example" # String | jsonp callback
}

begin
  #
  result = api_instance.track_lyrics_get_get(track_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling LyricsApi->track_lyrics_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **String**| The musiXmatch track id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 

### Return type

[**InlineResponse20012**](InlineResponse20012.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



