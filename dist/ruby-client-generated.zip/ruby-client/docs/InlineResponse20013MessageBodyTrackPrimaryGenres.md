# SwaggerClient::InlineResponse20013MessageBodyTrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenreList&gt;**](InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenreList.md) |  | [optional] 


