# SwaggerClient::InlineResponse20011MessageBodyTrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenreList&gt;**](InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenreList.md) |  | [optional] 


