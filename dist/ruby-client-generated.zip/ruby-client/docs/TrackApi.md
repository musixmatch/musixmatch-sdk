# SwaggerClient::TrackApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**album_tracks_get_get**](TrackApi.md#album_tracks_get_get) | **GET** /album.tracks.get | 
[**chart_tracks_get_get**](TrackApi.md#chart_tracks_get_get) | **GET** /chart.tracks.get | 
[**matcher_track_get_get**](TrackApi.md#matcher_track_get_get) | **GET** /matcher.track.get | 
[**track_get_get**](TrackApi.md#track_get_get) | **GET** /track.get | 
[**track_search_get**](TrackApi.md#track_search_get) | **GET** /track.search | 


# **album_tracks_get_get**
> InlineResponse2001 album_tracks_get_get(album_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::TrackApi.new

album_id = "album_id_example" # String | The musiXmatch album id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  f_has_lyrics: "f_has_lyrics_example", # String | When set, filter only contents with lyrics
  page: 3.4, # Float | Define the page number for paginated results
  page_size: 3.4 # Float | Define the page size for paginated results.Range is 1 to 100.
}

begin
  #
  result = api_instance.album_tracks_get_get(album_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TrackApi->album_tracks_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **album_id** | **String**| The musiXmatch album id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **f_has_lyrics** | **String**| When set, filter only contents with lyrics | [optional] 
 **page** | **Float**| Define the page number for paginated results | [optional] 
 **page_size** | **Float**| Define the page size for paginated results.Range is 1 to 100. | [optional] 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **chart_tracks_get_get**
> InlineResponse2007 chart_tracks_get_get(opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::TrackApi.new

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  page: 3.4, # Float | Define the page number for paginated results
  page_size: 3.4, # Float | Define the page size for paginated results.Range is 1 to 100.
  country: "us", # String | A valid ISO 3166 country code
  f_has_lyrics: "f_has_lyrics_example" # String | When set, filter only contents with lyrics
}

begin
  #
  result = api_instance.chart_tracks_get_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TrackApi->chart_tracks_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **page** | **Float**| Define the page number for paginated results | [optional] 
 **page_size** | **Float**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **country** | **String**| A valid ISO 3166 country code | [optional] [default to us]
 **f_has_lyrics** | **String**| When set, filter only contents with lyrics | [optional] 

### Return type

[**InlineResponse2007**](InlineResponse2007.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **matcher_track_get_get**
> InlineResponse20010 matcher_track_get_get(opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::TrackApi.new

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  q_artist: "q_artist_example", # String | The song artist
  q_track: "q_track_example", # String | The song title
  f_has_lyrics: 3.4, # Float | When set, filter only contents with lyrics
  f_has_subtitle: 3.4 # Float | When set, filter only contents with subtitles
}

begin
  #
  result = api_instance.matcher_track_get_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TrackApi->matcher_track_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **q_artist** | **String**| The song artist | [optional] 
 **q_track** | **String**| The song title | [optional] 
 **f_has_lyrics** | **Float**| When set, filter only contents with lyrics | [optional] 
 **f_has_subtitle** | **Float**| When set, filter only contents with subtitles | [optional] 

### Return type

[**InlineResponse20010**](InlineResponse20010.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **track_get_get**
> InlineResponse20011 track_get_get(track_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::TrackApi.new

track_id = "track_id_example" # String | The musiXmatch track id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example" # String | jsonp callback
}

begin
  #
  result = api_instance.track_get_get(track_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TrackApi->track_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **String**| The musiXmatch track id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 

### Return type

[**InlineResponse20011**](InlineResponse20011.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **track_search_get**
> InlineResponse20013 track_search_get(opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::TrackApi.new

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  q_track: "q_track_example", # String | The song title
  q_artist: "q_artist_example", # String | The song artist
  q_lyrics: "q_lyrics_example", # String | Any word in the lyrics
  f_artist_id: 3.4, # Float | When set, filter by this artist id
  f_music_genre_id: 3.4, # Float | When set, filter by this music category id
  f_lyrics_language: 3.4, # Float | Filter by the lyrics language (en,it,..)
  f_has_lyrics: 3.4, # Float | When set, filter only contents with lyrics
  s_artist_rating: "s_artist_rating_example", # String | Sort by our popularity index for artists (asc|desc)
  s_track_rating: "s_track_rating_example", # String | Sort by our popularity index for tracks (asc|desc)
  quorum_factor: 1, # Float | Search only a part of the given query string.Allowed range is (0.1 – 0.9)
  page_size: 3.4, # Float | Define the page size for paginated results.Range is 1 to 100.
  page: 3.4 # Float | Define the page number for paginated results
}

begin
  #
  result = api_instance.track_search_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling TrackApi->track_search_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **q_track** | **String**| The song title | [optional] 
 **q_artist** | **String**| The song artist | [optional] 
 **q_lyrics** | **String**| Any word in the lyrics | [optional] 
 **f_artist_id** | **Float**| When set, filter by this artist id | [optional] 
 **f_music_genre_id** | **Float**| When set, filter by this music category id | [optional] 
 **f_lyrics_language** | **Float**| Filter by the lyrics language (en,it,..) | [optional] 
 **f_has_lyrics** | **Float**| When set, filter only contents with lyrics | [optional] 
 **s_artist_rating** | **String**| Sort by our popularity index for artists (asc|desc) | [optional] 
 **s_track_rating** | **String**| Sort by our popularity index for tracks (asc|desc) | [optional] 
 **quorum_factor** | **Float**| Search only a part of the given query string.Allowed range is (0.1 – 0.9) | [optional] [default to 1]
 **page_size** | **Float**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **Float**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse20013**](InlineResponse20013.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



