# SwaggerClient::InlineResponse20012

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse20012Message**](InlineResponse20012Message.md) |  | [optional] 


