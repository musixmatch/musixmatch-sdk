# SwaggerClient::InlineResponse2001MessageBodyTrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenreList&gt;**](InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenreList.md) |  | [optional] 


