# SwaggerClient::InlineResponse20010MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**execute_time** | **Float** |  | [optional] 
**status_code** | **Float** |  | [optional] 
**confidence** | **Float** |  | [optional] 
**mode** | **String** |  | [optional] 
**cached** | **Float** |  | [optional] 


