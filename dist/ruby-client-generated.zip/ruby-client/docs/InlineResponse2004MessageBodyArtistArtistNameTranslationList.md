# SwaggerClient::InlineResponse2004MessageBodyArtistArtistNameTranslationList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_name_translation** | [**InlineResponse2004MessageBodyArtistArtistNameTranslation**](InlineResponse2004MessageBodyArtistArtistNameTranslation.md) |  | [optional] 


