# SwaggerClient::InlineResponse2001MessageBodyTrackSecondaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse2001MessageBodyTrackSecondaryGenresMusicGenre**](InlineResponse2001MessageBodyTrackSecondaryGenresMusicGenre.md) |  | [optional] 


