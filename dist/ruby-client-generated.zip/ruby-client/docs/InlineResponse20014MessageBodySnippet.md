# SwaggerClient::InlineResponse20014MessageBodySnippet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**html_tracking_url** | **String** |  | [optional] 
**instrumental** | **Float** |  | [optional] 
**restricted** | **Float** |  | [optional] 
**updated_time** | **String** |  | [optional] 
**snippet_body** | **String** |  | [optional] 
**pixel_tracking_url** | **String** |  | [optional] 
**snippet_id** | **Float** |  | [optional] 
**script_tracking_url** | **String** |  | [optional] 
**snippet_language** | **String** |  | [optional] 


