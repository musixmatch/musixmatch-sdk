# SwaggerClient::InlineResponse20015Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2006MessageHeader**](InlineResponse2006MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse20015MessageBody**](InlineResponse20015MessageBody.md) |  | [optional] 


