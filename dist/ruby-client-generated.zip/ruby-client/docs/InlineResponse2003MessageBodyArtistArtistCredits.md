# SwaggerClient::InlineResponse2003MessageBodyArtistArtistCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_list** | **Array&lt;String&gt;** |  | [optional] 


