# SwaggerClient::InlineResponse2002Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2002MessageHeader**](InlineResponse2002MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2002MessageBody**](InlineResponse2002MessageBody.md) |  | [optional] 


