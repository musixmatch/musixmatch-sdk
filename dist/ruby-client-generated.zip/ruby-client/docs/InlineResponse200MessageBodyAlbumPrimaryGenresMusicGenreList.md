# SwaggerClient::InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenre**](InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenre.md) |  | [optional] 


