# SwaggerClient::InlineResponse2003MessageBodyArtistArtistNameTranslationList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_name_translation** | [**InlineResponse2003MessageBodyArtistArtistNameTranslation**](InlineResponse2003MessageBodyArtistArtistNameTranslation.md) |  | [optional] 


