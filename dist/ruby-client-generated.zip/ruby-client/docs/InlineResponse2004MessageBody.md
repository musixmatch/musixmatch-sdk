# SwaggerClient::InlineResponse2004MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_list** | [**Array&lt;InlineResponse2004MessageBodyArtistList&gt;**](InlineResponse2004MessageBodyArtistList.md) |  | [optional] 


