# SwaggerClient::InlineResponse2004MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**execute_time** | **Float** |  | [optional] 
**available** | **Float** |  | [optional] 
**status_code** | **Float** |  | [optional] 


