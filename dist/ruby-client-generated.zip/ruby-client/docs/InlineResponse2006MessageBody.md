# SwaggerClient::InlineResponse2006MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_list** | [**Array&lt;InlineResponse2006MessageBodyArtistList&gt;**](InlineResponse2006MessageBodyArtistList.md) |  | [optional] 


