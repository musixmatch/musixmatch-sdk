# SwaggerClient::InlineResponse20011

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse20011Message**](InlineResponse20011Message.md) |  | [optional] 


