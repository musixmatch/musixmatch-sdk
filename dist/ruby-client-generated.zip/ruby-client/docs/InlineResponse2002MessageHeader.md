# SwaggerClient::InlineResponse2002MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **Float** |  | [optional] 
**status_code** | **Float** |  | [optional] 
**execute_time** | **Float** |  | [optional] 


