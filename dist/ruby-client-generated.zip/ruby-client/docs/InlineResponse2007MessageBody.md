# SwaggerClient::InlineResponse2007MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track_list** | [**Array&lt;InlineResponse2007MessageBodyTrackList&gt;**](InlineResponse2007MessageBodyTrackList.md) |  | [optional] 


