# SwaggerClient::InlineResponse2005MessageBodyArtistArtistCreditsArtist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restricted** | **Float** |  | [optional] 
**artist_id** | **Float** |  | [optional] 
**artist_twitter_url** | **String** |  | [optional] 
**artist_name_translation_list** | **Array&lt;String&gt;** |  | [optional] 
**artist_country** | **String** |  | [optional] 
**artist_name** | **String** |  | [optional] 
**secondary_genres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artist_comment** | **String** |  | [optional] 
**artist_share_url** | **String** |  | [optional] 
**artist_alias_list** | **Array&lt;String&gt;** |  | [optional] 
**updated_time** | **String** |  | [optional] 
**primary_genres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**managed** | **Float** |  | [optional] 
**artist_edit_url** | **String** |  | [optional] 
**artist_credits** | [**InlineResponse2003MessageBodyArtistArtistCredits**](InlineResponse2003MessageBodyArtistArtistCredits.md) |  | [optional] 
**artist_rating** | **Float** |  | [optional] 
**artist_mbid** | **String** |  | [optional] 
**artist_vanity_id** | **String** |  | [optional] 


