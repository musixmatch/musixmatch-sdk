# SwaggerClient::InlineResponse2001MessageBodyTrackList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track** | [**InlineResponse2001MessageBodyTrack**](InlineResponse2001MessageBodyTrack.md) |  | [optional] 


