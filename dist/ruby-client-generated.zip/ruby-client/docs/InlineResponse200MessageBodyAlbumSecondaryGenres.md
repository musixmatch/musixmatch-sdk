# SwaggerClient::InlineResponse200MessageBodyAlbumSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | **Array&lt;String&gt;** |  | [optional] 


