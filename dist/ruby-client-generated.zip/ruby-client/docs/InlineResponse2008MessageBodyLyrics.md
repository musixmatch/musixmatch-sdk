# SwaggerClient::InlineResponse2008MessageBodyLyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lyrics_id** | **Float** |  | [optional] 
**pixel_tracking_url** | **String** |  | [optional] 
**updated_time** | **String** |  | [optional] 
**instrumental** | **Float** |  | [optional] 
**lyrics_body** | **String** |  | [optional] 
**publisher_list** | **Array&lt;String&gt;** |  | [optional] 
**lyrics_copyright** | **String** |  | [optional] 
**action_requested** | **String** |  | [optional] 
**writer_list** | **Array&lt;String&gt;** |  | [optional] 
**lyrics_language** | **String** |  | [optional] 
**explicit** | **Float** |  | [optional] 
**lyrics_language_description** | **String** |  | [optional] 
**html_tracking_url** | **String** |  | [optional] 
**locked** | **Float** |  | [optional] 
**verified** | **Float** |  | [optional] 
**script_tracking_url** | **String** |  | [optional] 
**can_edit** | **Float** |  | [optional] 
**restricted** | **Float** |  | [optional] 


