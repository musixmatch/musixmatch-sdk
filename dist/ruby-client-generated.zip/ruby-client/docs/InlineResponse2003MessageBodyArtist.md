# SwaggerClient::InlineResponse2003MessageBodyArtist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_credits** | [**InlineResponse2003MessageBodyArtistArtistCredits**](InlineResponse2003MessageBodyArtistArtistCredits.md) |  | [optional] 
**artist_mbid** | **String** |  | [optional] 
**artist_name** | **String** |  | [optional] 
**secondary_genres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artist_alias_list** | [**Array&lt;InlineResponse2003MessageBodyArtistArtistAliasList&gt;**](InlineResponse2003MessageBodyArtistArtistAliasList.md) |  | [optional] 
**artist_vanity_id** | **String** |  | [optional] 
**restricted** | **Float** |  | [optional] 
**artist_country** | **String** |  | [optional] 
**artist_comment** | **String** |  | [optional] 
**artist_name_translation_list** | [**Array&lt;InlineResponse2003MessageBodyArtistArtistNameTranslationList&gt;**](InlineResponse2003MessageBodyArtistArtistNameTranslationList.md) |  | [optional] 
**artist_edit_url** | **String** |  | [optional] 
**artist_share_url** | **String** |  | [optional] 
**artist_id** | **Float** |  | [optional] 
**updated_time** | **String** |  | [optional] 
**managed** | **Float** |  | [optional] 
**primary_genres** | [**InlineResponse2003MessageBodyArtistPrimaryGenres**](InlineResponse2003MessageBodyArtistPrimaryGenres.md) |  | [optional] 
**artist_twitter_url** | **String** |  | [optional] 
**artist_rating** | **Float** |  | [optional] 


