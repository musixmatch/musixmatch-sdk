# SwaggerClient::InlineResponse2009MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subtitle** | [**InlineResponse2009MessageBodySubtitle**](InlineResponse2009MessageBodySubtitle.md) |  | [optional] 


