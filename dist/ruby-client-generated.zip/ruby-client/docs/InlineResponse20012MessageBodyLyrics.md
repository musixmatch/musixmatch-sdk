# SwaggerClient::InlineResponse20012MessageBodyLyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | **Float** |  | [optional] 
**pixel_tracking_url** | **String** |  | [optional] 
**publisher_list** | **Array&lt;String&gt;** |  | [optional] 
**lyrics_language_description** | **String** |  | [optional] 
**restricted** | **Float** |  | [optional] 
**updated_time** | **String** |  | [optional] 
**explicit** | **Float** |  | [optional] 
**lyrics_copyright** | **String** |  | [optional] 
**html_tracking_url** | **String** |  | [optional] 
**lyrics_language** | **String** |  | [optional] 
**script_tracking_url** | **String** |  | [optional] 
**verified** | **Float** |  | [optional] 
**lyrics_body** | **String** |  | [optional] 
**lyrics_id** | **Float** |  | [optional] 
**writer_list** | **Array&lt;String&gt;** |  | [optional] 
**can_edit** | **Float** |  | [optional] 
**action_requested** | **String** |  | [optional] 
**locked** | **Float** |  | [optional] 


