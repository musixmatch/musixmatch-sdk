# SwaggerClient::InlineResponse20012Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**InlineResponse20012MessageBody**](InlineResponse20012MessageBody.md) |  | [optional] 
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 


