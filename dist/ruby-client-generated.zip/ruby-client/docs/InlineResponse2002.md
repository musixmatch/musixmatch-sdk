# SwaggerClient::InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2002Message**](InlineResponse2002Message.md) |  | [optional] 


