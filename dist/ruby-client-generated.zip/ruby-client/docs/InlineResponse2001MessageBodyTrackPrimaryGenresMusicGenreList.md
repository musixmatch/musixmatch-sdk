# SwaggerClient::InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenre**](InlineResponse2001MessageBodyTrackPrimaryGenresMusicGenre.md) |  | [optional] 


