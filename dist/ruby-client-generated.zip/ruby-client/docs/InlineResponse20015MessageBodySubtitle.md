# SwaggerClient::InlineResponse20015MessageBodySubtitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updated_time** | **String** |  | [optional] 
**publisher_list** | **Array&lt;String&gt;** |  | [optional] 
**restricted** | **Float** |  | [optional] 
**lyrics_copyright** | **String** |  | [optional] 
**subtitle_body** | **String** |  | [optional] 
**subtitle_language_description** | **String** |  | [optional] 
**subtitle_length** | **Float** |  | [optional] 
**subtitle_id** | **Float** |  | [optional] 
**subtitle_language** | **String** |  | [optional] 
**pixel_tracking_url** | **String** |  | [optional] 
**html_tracking_url** | **String** |  | [optional] 
**writer_list** | **Array&lt;String&gt;** |  | [optional] 
**script_tracking_url** | **String** |  | [optional] 


