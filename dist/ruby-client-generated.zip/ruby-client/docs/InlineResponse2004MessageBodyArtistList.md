# SwaggerClient::InlineResponse2004MessageBodyArtistList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | [**InlineResponse2004MessageBodyArtist**](InlineResponse2004MessageBodyArtist.md) |  | [optional] 


