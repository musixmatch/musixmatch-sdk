# SwaggerClient::InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2006Message**](InlineResponse2006Message.md) |  | [optional] 


