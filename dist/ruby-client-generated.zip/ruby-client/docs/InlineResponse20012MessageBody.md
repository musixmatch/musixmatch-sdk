# SwaggerClient::InlineResponse20012MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lyrics** | [**InlineResponse20012MessageBodyLyrics**](InlineResponse20012MessageBodyLyrics.md) |  | [optional] 


