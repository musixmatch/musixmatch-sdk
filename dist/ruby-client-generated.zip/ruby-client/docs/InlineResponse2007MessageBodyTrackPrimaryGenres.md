# SwaggerClient::InlineResponse2007MessageBodyTrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenreList&gt;**](InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenreList.md) |  | [optional] 


