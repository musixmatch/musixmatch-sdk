# SwaggerClient::InlineResponse20014

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse20014Message**](InlineResponse20014Message.md) |  | [optional] 


