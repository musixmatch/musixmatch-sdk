# SwaggerClient::InlineResponse2003MessageBodyArtistPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenreList&gt;**](InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenreList.md) |  | [optional] 


