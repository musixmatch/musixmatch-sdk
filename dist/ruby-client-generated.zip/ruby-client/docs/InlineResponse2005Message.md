# SwaggerClient::InlineResponse2005Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**InlineResponse2005MessageBody**](InlineResponse2005MessageBody.md) |  | [optional] 
**header** | [**InlineResponse2002MessageHeader**](InlineResponse2002MessageHeader.md) |  | [optional] 


