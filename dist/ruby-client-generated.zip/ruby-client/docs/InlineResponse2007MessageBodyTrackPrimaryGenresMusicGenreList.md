# SwaggerClient::InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenre**](InlineResponse2007MessageBodyTrackPrimaryGenresMusicGenre.md) |  | [optional] 


