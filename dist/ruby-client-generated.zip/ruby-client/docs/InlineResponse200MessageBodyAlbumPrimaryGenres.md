# SwaggerClient::InlineResponse200MessageBodyAlbumPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenreList&gt;**](InlineResponse200MessageBodyAlbumPrimaryGenresMusicGenreList.md) |  | [optional] 


