# SwaggerClient::InlineResponse2003MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | [**InlineResponse2003MessageBodyArtist**](InlineResponse2003MessageBodyArtist.md) |  | [optional] 


