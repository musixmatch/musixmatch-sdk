# SwaggerClient::InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenre**](InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenre.md) |  | [optional] 


