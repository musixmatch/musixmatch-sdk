# SwaggerClient::InlineResponse2001MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track_list** | [**Array&lt;InlineResponse2001MessageBodyTrackList&gt;**](InlineResponse2001MessageBodyTrackList.md) |  | [optional] 


