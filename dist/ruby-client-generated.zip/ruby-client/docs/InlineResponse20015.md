# SwaggerClient::InlineResponse20015

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse20015Message**](InlineResponse20015Message.md) |  | [optional] 


