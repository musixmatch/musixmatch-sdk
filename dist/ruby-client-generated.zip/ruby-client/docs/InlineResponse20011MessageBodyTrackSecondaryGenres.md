# SwaggerClient::InlineResponse20011MessageBodyTrackSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenreList&gt;**](InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenreList.md) |  | [optional] 


