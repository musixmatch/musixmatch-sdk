# SwaggerClient::InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenre**](InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenre.md) |  | [optional] 


