# SwaggerClient::InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2003Message**](InlineResponse2003Message.md) |  | [optional] 


