# SwaggerClient::InlineResponse2002MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**album_list** | [**Array&lt;InlineResponse2002MessageBodyAlbumList&gt;**](InlineResponse2002MessageBodyAlbumList.md) |  | [optional] 


