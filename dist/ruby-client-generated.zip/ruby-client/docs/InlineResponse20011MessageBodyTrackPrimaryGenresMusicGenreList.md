# SwaggerClient::InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenre**](InlineResponse20011MessageBodyTrackPrimaryGenresMusicGenre.md) |  | [optional] 


