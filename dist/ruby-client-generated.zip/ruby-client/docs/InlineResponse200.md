# SwaggerClient::InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse200Message**](InlineResponse200Message.md) |  | [optional] 


