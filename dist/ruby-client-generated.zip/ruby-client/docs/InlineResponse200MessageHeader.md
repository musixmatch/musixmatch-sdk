# SwaggerClient::InlineResponse200MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status_code** | **Float** |  | [optional] 
**execute_time** | **Float** |  | [optional] 


