# SwaggerClient::InlineResponse2005MessageBodyArtistList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | [**InlineResponse2005MessageBodyArtist**](InlineResponse2005MessageBodyArtist.md) |  | [optional] 


