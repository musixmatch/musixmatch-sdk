# SwaggerClient::InlineResponse20010Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**InlineResponse20010MessageBody**](InlineResponse20010MessageBody.md) |  | [optional] 
**header** | [**InlineResponse20010MessageHeader**](InlineResponse20010MessageHeader.md) |  | [optional] 


