# SwaggerClient::InlineResponse2003MessageBodyArtistPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_parent_id** | **Float** |  | [optional] 
**music_genre_name** | **String** |  | [optional] 
**music_genre_vanity** | **String** |  | [optional] 
**music_genre_id** | **Float** |  | [optional] 
**music_genre_name_extended** | **String** |  | [optional] 


