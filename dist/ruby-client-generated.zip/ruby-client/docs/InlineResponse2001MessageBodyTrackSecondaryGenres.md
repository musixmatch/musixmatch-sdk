# SwaggerClient::InlineResponse2001MessageBodyTrackSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse2001MessageBodyTrackSecondaryGenresMusicGenreList&gt;**](InlineResponse2001MessageBodyTrackSecondaryGenresMusicGenreList.md) |  | [optional] 


