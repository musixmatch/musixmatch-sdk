# SwaggerClient::InlineResponse2009Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**InlineResponse2009MessageBody**](InlineResponse2009MessageBody.md) |  | [optional] 
**header** | [**InlineResponse2006MessageHeader**](InlineResponse2006MessageHeader.md) |  | [optional] 


