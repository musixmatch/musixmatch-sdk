# SwaggerClient::ArtistApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**artist_get_get**](ArtistApi.md#artist_get_get) | **GET** /artist.get | 
[**artist_related_get_get**](ArtistApi.md#artist_related_get_get) | **GET** /artist.related.get | 
[**artist_search_get**](ArtistApi.md#artist_search_get) | **GET** /artist.search | 
[**chart_artists_get_get**](ArtistApi.md#chart_artists_get_get) | **GET** /chart.artists.get | 


# **artist_get_get**
> InlineResponse2003 artist_get_get(artist_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::ArtistApi.new

artist_id = "artist_id_example" # String |  The musiXmatch artist id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example" # String | jsonp callback
}

begin
  #
  result = api_instance.artist_get_get(artist_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ArtistApi->artist_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **String**|  The musiXmatch artist id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **artist_related_get_get**
> InlineResponse2004 artist_related_get_get(artist_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::ArtistApi.new

artist_id = "artist_id_example" # String | The musiXmatch artist id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  page_size: 3.4, # Float | Define the page size for paginated results.Range is 1 to 100.
  page: 3.4 # Float | Define the page number for paginated results
}

begin
  #
  result = api_instance.artist_related_get_get(artist_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ArtistApi->artist_related_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **String**| The musiXmatch artist id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **page_size** | **Float**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **Float**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **artist_search_get**
> InlineResponse2005 artist_search_get(opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::ArtistApi.new

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  q_artist: "q_artist_example", # String | The song artist
  f_artist_id: 3.4, # Float | When set, filter by this artist id
  page: 3.4, # Float | Define the page number for paginated results
  page_size: 3.4 # Float | Define the page size for paginated results.Range is 1 to 100.
}

begin
  #
  result = api_instance.artist_search_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ArtistApi->artist_search_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **q_artist** | **String**| The song artist | [optional] 
 **f_artist_id** | **Float**| When set, filter by this artist id | [optional] 
 **page** | **Float**| Define the page number for paginated results | [optional] 
 **page_size** | **Float**| Define the page size for paginated results.Range is 1 to 100. | [optional] 

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **chart_artists_get_get**
> InlineResponse2006 chart_artists_get_get(opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::ArtistApi.new

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  page: 3.4, # Float | Define the page number for paginated results
  page_size: 3.4, # Float | Define the page size for paginated results.Range is 1 to 100.
  country: "us" # String | A valid ISO 3166 country code
}

begin
  #
  result = api_instance.chart_artists_get_get(opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ArtistApi->chart_artists_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **page** | **Float**| Define the page number for paginated results | [optional] 
 **page_size** | **Float**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **country** | **String**| A valid ISO 3166 country code | [optional] [default to us]

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



