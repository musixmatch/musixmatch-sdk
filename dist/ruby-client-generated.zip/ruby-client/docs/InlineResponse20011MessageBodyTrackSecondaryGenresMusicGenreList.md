# SwaggerClient::InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenre**](InlineResponse20011MessageBodyTrackSecondaryGenresMusicGenre.md) |  | [optional] 


