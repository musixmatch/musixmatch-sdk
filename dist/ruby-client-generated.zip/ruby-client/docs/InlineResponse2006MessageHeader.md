# SwaggerClient::InlineResponse2006MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**execute_time** | **Float** |  | [optional] 
**status_code** | **Float** |  | [optional] 


