# SwaggerClient::InlineResponse2004MessageBodyArtist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**managed** | **Float** |  | [optional] 
**artist_credits** | [**InlineResponse2003MessageBodyArtistArtistCredits**](InlineResponse2003MessageBodyArtistArtistCredits.md) |  | [optional] 
**updated_time** | **String** |  | [optional] 
**primary_genres** | [**InlineResponse2004MessageBodyArtistPrimaryGenres**](InlineResponse2004MessageBodyArtistPrimaryGenres.md) |  | [optional] 
**artist_mbid** | **String** |  | [optional] 
**artist_rating** | **Float** |  | [optional] 
**artist_twitter_url** | **String** |  | [optional] 
**artist_comment** | **String** |  | [optional] 
**artist_share_url** | **String** |  | [optional] 
**secondary_genres** | [**InlineResponse200MessageBodyAlbumSecondaryGenres**](InlineResponse200MessageBodyAlbumSecondaryGenres.md) |  | [optional] 
**artist_vanity_id** | **String** |  | [optional] 
**restricted** | **Float** |  | [optional] 
**artist_name** | **String** |  | [optional] 
**artist_id** | **Float** |  | [optional] 
**artist_name_translation_list** | [**Array&lt;InlineResponse2004MessageBodyArtistArtistNameTranslationList&gt;**](InlineResponse2004MessageBodyArtistArtistNameTranslationList.md) |  | [optional] 
**artist_edit_url** | **String** |  | [optional] 
**artist_alias_list** | [**Array&lt;InlineResponse2003MessageBodyArtistArtistAliasList&gt;**](InlineResponse2003MessageBodyArtistArtistAliasList.md) |  | [optional] 
**artist_country** | **String** |  | [optional] 


