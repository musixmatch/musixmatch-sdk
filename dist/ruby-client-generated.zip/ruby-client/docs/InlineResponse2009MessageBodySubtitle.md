# SwaggerClient::InlineResponse2009MessageBodySubtitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subtitle_body** | **String** |  | [optional] 
**publisher_list** | **Array&lt;String&gt;** |  | [optional] 
**subtitle_language** | **String** |  | [optional] 
**subtitle_language_description** | **String** |  | [optional] 
**subtitle_id** | **Float** |  | [optional] 
**pixel_tracking_url** | **String** |  | [optional] 
**html_tracking_url** | **String** |  | [optional] 
**restricted** | **Float** |  | [optional] 
**lyrics_copyright** | **String** |  | [optional] 
**script_tracking_url** | **String** |  | [optional] 
**subtitle_length** | **Float** |  | [optional] 
**updated_time** | **String** |  | [optional] 
**writer_list** | **Array&lt;String&gt;** |  | [optional] 


