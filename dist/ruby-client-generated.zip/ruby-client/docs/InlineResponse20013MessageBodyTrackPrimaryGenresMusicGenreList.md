# SwaggerClient::InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenre**](InlineResponse20013MessageBodyTrackPrimaryGenresMusicGenre.md) |  | [optional] 


