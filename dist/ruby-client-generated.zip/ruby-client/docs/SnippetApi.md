# SwaggerClient::SnippetApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**track_snippet_get_get**](SnippetApi.md#track_snippet_get_get) | **GET** /track.snippet.get | 


# **track_snippet_get_get**
> InlineResponse20014 track_snippet_get_get(track_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::SnippetApi.new

track_id = "track_id_example" # String | The musiXmatch track id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example" # String | jsonp callback
}

begin
  #
  result = api_instance.track_snippet_get_get(track_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling SnippetApi->track_snippet_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **String**| The musiXmatch track id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 

### Return type

[**InlineResponse20014**](InlineResponse20014.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



