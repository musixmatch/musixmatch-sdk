# SwaggerClient::InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenre**](InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenre.md) |  | [optional] 


