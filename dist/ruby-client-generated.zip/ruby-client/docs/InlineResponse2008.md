# SwaggerClient::InlineResponse2008

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2008Message**](InlineResponse2008Message.md) |  | [optional] 


