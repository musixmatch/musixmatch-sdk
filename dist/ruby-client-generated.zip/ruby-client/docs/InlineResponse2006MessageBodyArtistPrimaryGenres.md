# SwaggerClient::InlineResponse2006MessageBodyArtistPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenreList&gt;**](InlineResponse2006MessageBodyArtistPrimaryGenresMusicGenreList.md) |  | [optional] 


