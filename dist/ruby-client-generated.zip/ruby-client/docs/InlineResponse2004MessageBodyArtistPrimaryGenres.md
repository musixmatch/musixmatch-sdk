# SwaggerClient::InlineResponse2004MessageBodyArtistPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**Array&lt;InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenreList&gt;**](InlineResponse2004MessageBodyArtistPrimaryGenresMusicGenreList.md) |  | [optional] 


