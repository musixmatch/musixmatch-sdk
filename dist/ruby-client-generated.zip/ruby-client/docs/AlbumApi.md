# SwaggerClient::AlbumApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**album_get_get**](AlbumApi.md#album_get_get) | **GET** /album.get | 
[**artist_albums_get_get**](AlbumApi.md#artist_albums_get_get) | **GET** /artist.albums.get | 


# **album_get_get**
> InlineResponse200 album_get_get(album_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::AlbumApi.new

album_id = "album_id_example" # String | The musiXmatch album id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example" # String | jsonp callback
}

begin
  #
  result = api_instance.album_get_get(album_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AlbumApi->album_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **album_id** | **String**| The musiXmatch album id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **artist_albums_get_get**
> InlineResponse2002 artist_albums_get_get(artist_id, opts)





### Example
```ruby
# load the gem
require 'swagger_client'
# setup authorization
SwaggerClient.configure do |config|
  # Configure API key authorization: key
  config.api_key['apikey'] = 'YOUR API KEY'
  # Uncomment the following line to set a prefix for the API key, e.g. 'Bearer' (defaults to nil)
  #config.api_key_prefix['apikey'] = 'Bearer'
end

api_instance = SwaggerClient::AlbumApi.new

artist_id = "artist_id_example" # String | The musiXmatch artist id

opts = { 
  format: "json", # String | output format: json, jsonp, xml.
  callback: "callback_example", # String | jsonp callback
  s_release_date: "s_release_date_example", # String | Sort by release date (asc|desc)
  g_album_name: "g_album_name_example", # String | Group by Album Name
  page_size: 3.4, # Float | Define the page size for paginated results.Range is 1 to 100.
  page: 3.4 # Float | Define the page number for paginated results
}

begin
  #
  result = api_instance.artist_albums_get_get(artist_id, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling AlbumApi->artist_albums_get_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **String**| The musiXmatch artist id | 
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional] 
 **s_release_date** | **String**| Sort by release date (asc|desc) | [optional] 
 **g_album_name** | **String**| Group by Album Name | [optional] 
 **page_size** | **Float**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **Float**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json



