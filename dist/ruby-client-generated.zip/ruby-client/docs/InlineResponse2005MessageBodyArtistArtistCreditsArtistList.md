# SwaggerClient::InlineResponse2005MessageBodyArtistArtistCreditsArtistList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | [**InlineResponse2005MessageBodyArtistArtistCreditsArtist**](InlineResponse2005MessageBodyArtistArtistCreditsArtist.md) |  | [optional] 


