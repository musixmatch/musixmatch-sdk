# SwaggerClient::InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2001Message**](InlineResponse2001Message.md) |  | [optional] 


