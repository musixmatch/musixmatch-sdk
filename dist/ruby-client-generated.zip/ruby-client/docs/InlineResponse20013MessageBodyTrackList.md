# SwaggerClient::InlineResponse20013MessageBodyTrackList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track** | [**InlineResponse20013MessageBodyTrack**](InlineResponse20013MessageBodyTrack.md) |  | [optional] 


