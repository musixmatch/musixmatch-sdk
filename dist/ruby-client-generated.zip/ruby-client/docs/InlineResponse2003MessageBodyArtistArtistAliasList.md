# SwaggerClient::InlineResponse2003MessageBodyArtistArtistAliasList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_alias** | **String** |  | [optional] 


