# SwaggerClient::InlineResponse2004MessageBodyArtistArtistNameTranslation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**translation** | **String** |  | [optional] 
**language** | **String** |  | [optional] 


