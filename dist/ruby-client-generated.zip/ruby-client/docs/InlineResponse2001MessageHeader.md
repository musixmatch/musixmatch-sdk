# SwaggerClient::InlineResponse2001MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status_code** | **Float** |  | [optional] 
**available** | **Float** |  | [optional] 
**execute_time** | **Float** |  | [optional] 


