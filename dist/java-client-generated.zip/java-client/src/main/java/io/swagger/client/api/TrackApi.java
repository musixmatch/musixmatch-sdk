/**
 * Musixmatch API
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop 
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package io.swagger.client.api;

import io.swagger.client.ApiCallback;
import io.swagger.client.ApiClient;
import io.swagger.client.ApiException;
import io.swagger.client.ApiResponse;
import io.swagger.client.Configuration;
import io.swagger.client.Pair;
import io.swagger.client.ProgressRequestBody;
import io.swagger.client.ProgressResponseBody;

import com.google.gson.reflect.TypeToken;

import java.io.IOException;

import io.swagger.client.model.InlineResponse2001;
import java.math.BigDecimal;
import io.swagger.client.model.InlineResponse2006;
import io.swagger.client.model.InlineResponse2009;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TrackApi {
    private ApiClient apiClient;

    public TrackApi() {
        this(Configuration.getDefaultApiClient());
    }

    public TrackApi(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public ApiClient getApiClient() {
        return apiClient;
    }

    public void setApiClient(ApiClient apiClient) {
        this.apiClient = apiClient;
    }

    /* Build call for albumTracksGetGet */
    private com.squareup.okhttp.Call albumTracksGetGetCall(String albumId, String format, String callback, String fHasLyrics, BigDecimal page, BigDecimal pageSize, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;
        
        // verify the required parameter 'albumId' is set
        if (albumId == null) {
            throw new ApiException("Missing the required parameter 'albumId' when calling albumTracksGetGet(Async)");
        }
        

        // create path and map variables
        String localVarPath = "/album.tracks.get".replaceAll("\\{format\\}","json");

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        if (format != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "format", format));
        if (callback != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "callback", callback));
        if (albumId != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "album_id", albumId));
        if (fHasLyrics != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "f_has_lyrics", fHasLyrics));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "page", page));
        if (pageSize != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "page_size", pageSize));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "key" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    /**
     * 
     * 
     * @param albumId The musiXmatch album id (required)
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param page Define the page number for paginated results (optional)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @return InlineResponse2001
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public InlineResponse2001 albumTracksGetGet(String albumId, String format, String callback, String fHasLyrics, BigDecimal page, BigDecimal pageSize) throws ApiException {
        ApiResponse<InlineResponse2001> resp = albumTracksGetGetWithHttpInfo(albumId, format, callback, fHasLyrics, page, pageSize);
        return resp.getData();
    }

    /**
     * 
     * 
     * @param albumId The musiXmatch album id (required)
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param page Define the page number for paginated results (optional)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @return ApiResponse&lt;InlineResponse2001&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<InlineResponse2001> albumTracksGetGetWithHttpInfo(String albumId, String format, String callback, String fHasLyrics, BigDecimal page, BigDecimal pageSize) throws ApiException {
        com.squareup.okhttp.Call call = albumTracksGetGetCall(albumId, format, callback, fHasLyrics, page, pageSize, null, null);
        Type localVarReturnType = new TypeToken<InlineResponse2001>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     *  (asynchronously)
     * 
     * @param albumId The musiXmatch album id (required)
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param page Define the page number for paginated results (optional)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call albumTracksGetGetAsync(String albumId, String format, String callback, String fHasLyrics, BigDecimal page, BigDecimal pageSize, final ApiCallback<InlineResponse2001> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = albumTracksGetGetCall(albumId, format, callback, fHasLyrics, page, pageSize, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<InlineResponse2001>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /* Build call for chartTracksGetGet */
    private com.squareup.okhttp.Call chartTracksGetGetCall(String format, String callback, BigDecimal page, BigDecimal pageSize, String country, String fHasLyrics, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;
        

        // create path and map variables
        String localVarPath = "/chart.tracks.get".replaceAll("\\{format\\}","json");

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        if (format != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "format", format));
        if (callback != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "callback", callback));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "page", page));
        if (pageSize != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "page_size", pageSize));
        if (country != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "country", country));
        if (fHasLyrics != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "f_has_lyrics", fHasLyrics));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "key" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    /**
     * 
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param page Define the page number for paginated results (optional)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param country A valid ISO 3166 country code (optional, default to us)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @return InlineResponse2006
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public InlineResponse2006 chartTracksGetGet(String format, String callback, BigDecimal page, BigDecimal pageSize, String country, String fHasLyrics) throws ApiException {
        ApiResponse<InlineResponse2006> resp = chartTracksGetGetWithHttpInfo(format, callback, page, pageSize, country, fHasLyrics);
        return resp.getData();
    }

    /**
     * 
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param page Define the page number for paginated results (optional)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param country A valid ISO 3166 country code (optional, default to us)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @return ApiResponse&lt;InlineResponse2006&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<InlineResponse2006> chartTracksGetGetWithHttpInfo(String format, String callback, BigDecimal page, BigDecimal pageSize, String country, String fHasLyrics) throws ApiException {
        com.squareup.okhttp.Call call = chartTracksGetGetCall(format, callback, page, pageSize, country, fHasLyrics, null, null);
        Type localVarReturnType = new TypeToken<InlineResponse2006>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     *  (asynchronously)
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param page Define the page number for paginated results (optional)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param country A valid ISO 3166 country code (optional, default to us)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call chartTracksGetGetAsync(String format, String callback, BigDecimal page, BigDecimal pageSize, String country, String fHasLyrics, final ApiCallback<InlineResponse2006> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = chartTracksGetGetCall(format, callback, page, pageSize, country, fHasLyrics, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<InlineResponse2006>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /* Build call for matcherTrackGetGet */
    private com.squareup.okhttp.Call matcherTrackGetGetCall(String format, String callback, String qArtist, String qTrack, BigDecimal fHasLyrics, BigDecimal fHasSubtitle, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;
        

        // create path and map variables
        String localVarPath = "/matcher.track.get".replaceAll("\\{format\\}","json");

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        if (format != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "format", format));
        if (callback != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "callback", callback));
        if (qArtist != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "q_artist", qArtist));
        if (qTrack != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "q_track", qTrack));
        if (fHasLyrics != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "f_has_lyrics", fHasLyrics));
        if (fHasSubtitle != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "f_has_subtitle", fHasSubtitle));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "key" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    /**
     * 
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param qArtist The song artist (optional)
     * @param qTrack The song title (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param fHasSubtitle When set, filter only contents with subtitles (optional)
     * @return InlineResponse2009
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public InlineResponse2009 matcherTrackGetGet(String format, String callback, String qArtist, String qTrack, BigDecimal fHasLyrics, BigDecimal fHasSubtitle) throws ApiException {
        ApiResponse<InlineResponse2009> resp = matcherTrackGetGetWithHttpInfo(format, callback, qArtist, qTrack, fHasLyrics, fHasSubtitle);
        return resp.getData();
    }

    /**
     * 
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param qArtist The song artist (optional)
     * @param qTrack The song title (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param fHasSubtitle When set, filter only contents with subtitles (optional)
     * @return ApiResponse&lt;InlineResponse2009&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<InlineResponse2009> matcherTrackGetGetWithHttpInfo(String format, String callback, String qArtist, String qTrack, BigDecimal fHasLyrics, BigDecimal fHasSubtitle) throws ApiException {
        com.squareup.okhttp.Call call = matcherTrackGetGetCall(format, callback, qArtist, qTrack, fHasLyrics, fHasSubtitle, null, null);
        Type localVarReturnType = new TypeToken<InlineResponse2009>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     *  (asynchronously)
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param qArtist The song artist (optional)
     * @param qTrack The song title (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param fHasSubtitle When set, filter only contents with subtitles (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call matcherTrackGetGetAsync(String format, String callback, String qArtist, String qTrack, BigDecimal fHasLyrics, BigDecimal fHasSubtitle, final ApiCallback<InlineResponse2009> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = matcherTrackGetGetCall(format, callback, qArtist, qTrack, fHasLyrics, fHasSubtitle, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<InlineResponse2009>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /* Build call for trackGetGet */
    private com.squareup.okhttp.Call trackGetGetCall(String trackId, String format, String callback, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;
        
        // verify the required parameter 'trackId' is set
        if (trackId == null) {
            throw new ApiException("Missing the required parameter 'trackId' when calling trackGetGet(Async)");
        }
        

        // create path and map variables
        String localVarPath = "/track.get".replaceAll("\\{format\\}","json");

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        if (format != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "format", format));
        if (callback != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "callback", callback));
        if (trackId != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "track_id", trackId));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "key" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    /**
     * 
     * 
     * @param trackId The musiXmatch track id (required)
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @return InlineResponse2009
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public InlineResponse2009 trackGetGet(String trackId, String format, String callback) throws ApiException {
        ApiResponse<InlineResponse2009> resp = trackGetGetWithHttpInfo(trackId, format, callback);
        return resp.getData();
    }

    /**
     * 
     * 
     * @param trackId The musiXmatch track id (required)
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @return ApiResponse&lt;InlineResponse2009&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<InlineResponse2009> trackGetGetWithHttpInfo(String trackId, String format, String callback) throws ApiException {
        com.squareup.okhttp.Call call = trackGetGetCall(trackId, format, callback, null, null);
        Type localVarReturnType = new TypeToken<InlineResponse2009>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     *  (asynchronously)
     * 
     * @param trackId The musiXmatch track id (required)
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call trackGetGetAsync(String trackId, String format, String callback, final ApiCallback<InlineResponse2009> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = trackGetGetCall(trackId, format, callback, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<InlineResponse2009>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
    /* Build call for trackSearchGet */
    private com.squareup.okhttp.Call trackSearchGetCall(String format, String callback, String qTrack, String qArtist, String qLyrics, BigDecimal fArtistId, BigDecimal fMusicGenreId, BigDecimal fLyricsLanguage, BigDecimal fHasLyrics, String sArtistRating, String sTrackRating, BigDecimal quorumFactor, BigDecimal pageSize, BigDecimal page, final ProgressResponseBody.ProgressListener progressListener, final ProgressRequestBody.ProgressRequestListener progressRequestListener) throws ApiException {
        Object localVarPostBody = null;
        

        // create path and map variables
        String localVarPath = "/track.search".replaceAll("\\{format\\}","json");

        List<Pair> localVarQueryParams = new ArrayList<Pair>();
        if (format != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "format", format));
        if (callback != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "callback", callback));
        if (qTrack != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "q_track", qTrack));
        if (qArtist != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "q_artist", qArtist));
        if (qLyrics != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "q_lyrics", qLyrics));
        if (fArtistId != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "f_artist_id", fArtistId));
        if (fMusicGenreId != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "f_music_genre_id", fMusicGenreId));
        if (fLyricsLanguage != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "f_lyrics_language", fLyricsLanguage));
        if (fHasLyrics != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "f_has_lyrics", fHasLyrics));
        if (sArtistRating != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "s_artist_rating", sArtistRating));
        if (sTrackRating != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "s_track_rating", sTrackRating));
        if (quorumFactor != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "quorum_factor", quorumFactor));
        if (pageSize != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "page_size", pageSize));
        if (page != null)
        localVarQueryParams.addAll(apiClient.parameterToPairs("", "page", page));

        Map<String, String> localVarHeaderParams = new HashMap<String, String>();

        Map<String, Object> localVarFormParams = new HashMap<String, Object>();

        final String[] localVarAccepts = {
            "application/json"
        };
        final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);
        if (localVarAccept != null) localVarHeaderParams.put("Accept", localVarAccept);

        final String[] localVarContentTypes = {
            "application/json"
        };
        final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);
        localVarHeaderParams.put("Content-Type", localVarContentType);

        if(progressListener != null) {
            apiClient.getHttpClient().networkInterceptors().add(new com.squareup.okhttp.Interceptor() {
                @Override
                public com.squareup.okhttp.Response intercept(com.squareup.okhttp.Interceptor.Chain chain) throws IOException {
                    com.squareup.okhttp.Response originalResponse = chain.proceed(chain.request());
                    return originalResponse.newBuilder()
                    .body(new ProgressResponseBody(originalResponse.body(), progressListener))
                    .build();
                }
            });
        }

        String[] localVarAuthNames = new String[] { "key" };
        return apiClient.buildCall(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAuthNames, progressRequestListener);
    }

    /**
     * 
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param qTrack The song title (optional)
     * @param qArtist The song artist (optional)
     * @param qLyrics Any word in the lyrics (optional)
     * @param fArtistId When set, filter by this artist id (optional)
     * @param fMusicGenreId When set, filter by this music category id (optional)
     * @param fLyricsLanguage Filter by the lyrics language (en,it,..) (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param sArtistRating Sort by our popularity index for artists (asc|desc) (optional)
     * @param sTrackRating Sort by our popularity index for tracks (asc|desc) (optional)
     * @param quorumFactor Search only a part of the given query string.Allowed range is (0.1 – 0.9) (optional, default to 1)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param page Define the page number for paginated results (optional)
     * @return InlineResponse2006
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public InlineResponse2006 trackSearchGet(String format, String callback, String qTrack, String qArtist, String qLyrics, BigDecimal fArtistId, BigDecimal fMusicGenreId, BigDecimal fLyricsLanguage, BigDecimal fHasLyrics, String sArtistRating, String sTrackRating, BigDecimal quorumFactor, BigDecimal pageSize, BigDecimal page) throws ApiException {
        ApiResponse<InlineResponse2006> resp = trackSearchGetWithHttpInfo(format, callback, qTrack, qArtist, qLyrics, fArtistId, fMusicGenreId, fLyricsLanguage, fHasLyrics, sArtistRating, sTrackRating, quorumFactor, pageSize, page);
        return resp.getData();
    }

    /**
     * 
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param qTrack The song title (optional)
     * @param qArtist The song artist (optional)
     * @param qLyrics Any word in the lyrics (optional)
     * @param fArtistId When set, filter by this artist id (optional)
     * @param fMusicGenreId When set, filter by this music category id (optional)
     * @param fLyricsLanguage Filter by the lyrics language (en,it,..) (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param sArtistRating Sort by our popularity index for artists (asc|desc) (optional)
     * @param sTrackRating Sort by our popularity index for tracks (asc|desc) (optional)
     * @param quorumFactor Search only a part of the given query string.Allowed range is (0.1 – 0.9) (optional, default to 1)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param page Define the page number for paginated results (optional)
     * @return ApiResponse&lt;InlineResponse2006&gt;
     * @throws ApiException If fail to call the API, e.g. server error or cannot deserialize the response body
     */
    public ApiResponse<InlineResponse2006> trackSearchGetWithHttpInfo(String format, String callback, String qTrack, String qArtist, String qLyrics, BigDecimal fArtistId, BigDecimal fMusicGenreId, BigDecimal fLyricsLanguage, BigDecimal fHasLyrics, String sArtistRating, String sTrackRating, BigDecimal quorumFactor, BigDecimal pageSize, BigDecimal page) throws ApiException {
        com.squareup.okhttp.Call call = trackSearchGetCall(format, callback, qTrack, qArtist, qLyrics, fArtistId, fMusicGenreId, fLyricsLanguage, fHasLyrics, sArtistRating, sTrackRating, quorumFactor, pageSize, page, null, null);
        Type localVarReturnType = new TypeToken<InlineResponse2006>(){}.getType();
        return apiClient.execute(call, localVarReturnType);
    }

    /**
     *  (asynchronously)
     * 
     * @param format output format: json, jsonp, xml. (optional, default to json)
     * @param callback jsonp callback (optional)
     * @param qTrack The song title (optional)
     * @param qArtist The song artist (optional)
     * @param qLyrics Any word in the lyrics (optional)
     * @param fArtistId When set, filter by this artist id (optional)
     * @param fMusicGenreId When set, filter by this music category id (optional)
     * @param fLyricsLanguage Filter by the lyrics language (en,it,..) (optional)
     * @param fHasLyrics When set, filter only contents with lyrics (optional)
     * @param sArtistRating Sort by our popularity index for artists (asc|desc) (optional)
     * @param sTrackRating Sort by our popularity index for tracks (asc|desc) (optional)
     * @param quorumFactor Search only a part of the given query string.Allowed range is (0.1 – 0.9) (optional, default to 1)
     * @param pageSize Define the page size for paginated results.Range is 1 to 100. (optional)
     * @param page Define the page number for paginated results (optional)
     * @param callback The callback to be executed when the API call finishes
     * @return The request call
     * @throws ApiException If fail to process the API call, e.g. serializing the request body object
     */
    public com.squareup.okhttp.Call trackSearchGetAsync(String format, String callback, String qTrack, String qArtist, String qLyrics, BigDecimal fArtistId, BigDecimal fMusicGenreId, BigDecimal fLyricsLanguage, BigDecimal fHasLyrics, String sArtistRating, String sTrackRating, BigDecimal quorumFactor, BigDecimal pageSize, BigDecimal page, final ApiCallback<InlineResponse2006> callback) throws ApiException {

        ProgressResponseBody.ProgressListener progressListener = null;
        ProgressRequestBody.ProgressRequestListener progressRequestListener = null;

        if (callback != null) {
            progressListener = new ProgressResponseBody.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    callback.onDownloadProgress(bytesRead, contentLength, done);
                }
            };

            progressRequestListener = new ProgressRequestBody.ProgressRequestListener() {
                @Override
                public void onRequestProgress(long bytesWritten, long contentLength, boolean done) {
                    callback.onUploadProgress(bytesWritten, contentLength, done);
                }
            };
        }

        com.squareup.okhttp.Call call = trackSearchGetCall(format, callback, qTrack, qArtist, qLyrics, fArtistId, fMusicGenreId, fLyricsLanguage, fHasLyrics, sArtistRating, sTrackRating, quorumFactor, pageSize, page, progressListener, progressRequestListener);
        Type localVarReturnType = new TypeToken<InlineResponse2006>(){}.getType();
        apiClient.executeAsync(call, localVarReturnType, callback);
        return call;
    }
}
