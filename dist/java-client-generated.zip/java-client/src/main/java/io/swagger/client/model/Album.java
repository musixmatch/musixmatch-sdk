/**
 * Musixmatch API
 * Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop 
 *
 * OpenAPI spec version: 1.1.0
 * Contact: info@musixmatch.com
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package io.swagger.client.model;

import java.util.Objects;
import com.google.gson.annotations.SerializedName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.client.model.AlbumPrimaryGenres;
import io.swagger.client.model.ArtistSecondaryGenres;
import java.math.BigDecimal;


/**
 * a album of songs in the Musixmatch database.
 */
@ApiModel(description = "a album of songs in the Musixmatch database.")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaClientCodegen", date = "2016-09-26T10:57:13.748Z")
public class Album   {
  @SerializedName("album_coverart_500x500")
  private String albumCoverart500x500 = null;

  @SerializedName("restricted")
  private BigDecimal restricted = null;

  @SerializedName("artist_id")
  private BigDecimal artistId = null;

  @SerializedName("album_name")
  private String albumName = null;

  @SerializedName("album_coverart_800x800")
  private String albumCoverart800x800 = null;

  @SerializedName("album_copyright")
  private String albumCopyright = null;

  @SerializedName("album_coverart_350x350")
  private String albumCoverart350x350 = null;

  @SerializedName("artist_name")
  private String artistName = null;

  @SerializedName("primary_genres")
  private AlbumPrimaryGenres primaryGenres = null;

  @SerializedName("album_id")
  private BigDecimal albumId = null;

  @SerializedName("album_rating")
  private BigDecimal albumRating = null;

  @SerializedName("album_pline")
  private String albumPline = null;

  @SerializedName("album_track_count")
  private BigDecimal albumTrackCount = null;

  @SerializedName("album_release_type")
  private String albumReleaseType = null;

  @SerializedName("album_release_date")
  private String albumReleaseDate = null;

  @SerializedName("album_edit_url")
  private String albumEditUrl = null;

  @SerializedName("updated_time")
  private String updatedTime = null;

  @SerializedName("secondary_genres")
  private ArtistSecondaryGenres secondaryGenres = null;

  @SerializedName("album_mbid")
  private String albumMbid = null;

  @SerializedName("album_vanity_id")
  private String albumVanityId = null;

  @SerializedName("album_coverart_100x100")
  private String albumCoverart100x100 = null;

  @SerializedName("album_label")
  private String albumLabel = null;

  public Album albumCoverart500x500(String albumCoverart500x500) {
    this.albumCoverart500x500 = albumCoverart500x500;
    return this;
  }

   /**
   * 
   * @return albumCoverart500x500
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumCoverart500x500() {
    return albumCoverart500x500;
  }

  public void setAlbumCoverart500x500(String albumCoverart500x500) {
    this.albumCoverart500x500 = albumCoverart500x500;
  }

  public Album restricted(BigDecimal restricted) {
    this.restricted = restricted;
    return this;
  }

   /**
   * 
   * @return restricted
  **/
  @ApiModelProperty(example = "null", value = "")
  public BigDecimal getRestricted() {
    return restricted;
  }

  public void setRestricted(BigDecimal restricted) {
    this.restricted = restricted;
  }

  public Album artistId(BigDecimal artistId) {
    this.artistId = artistId;
    return this;
  }

   /**
   * 
   * @return artistId
  **/
  @ApiModelProperty(example = "null", value = "")
  public BigDecimal getArtistId() {
    return artistId;
  }

  public void setArtistId(BigDecimal artistId) {
    this.artistId = artistId;
  }

  public Album albumName(String albumName) {
    this.albumName = albumName;
    return this;
  }

   /**
   * 
   * @return albumName
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumName() {
    return albumName;
  }

  public void setAlbumName(String albumName) {
    this.albumName = albumName;
  }

  public Album albumCoverart800x800(String albumCoverart800x800) {
    this.albumCoverart800x800 = albumCoverart800x800;
    return this;
  }

   /**
   * 
   * @return albumCoverart800x800
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumCoverart800x800() {
    return albumCoverart800x800;
  }

  public void setAlbumCoverart800x800(String albumCoverart800x800) {
    this.albumCoverart800x800 = albumCoverart800x800;
  }

  public Album albumCopyright(String albumCopyright) {
    this.albumCopyright = albumCopyright;
    return this;
  }

   /**
   * 
   * @return albumCopyright
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumCopyright() {
    return albumCopyright;
  }

  public void setAlbumCopyright(String albumCopyright) {
    this.albumCopyright = albumCopyright;
  }

  public Album albumCoverart350x350(String albumCoverart350x350) {
    this.albumCoverart350x350 = albumCoverart350x350;
    return this;
  }

   /**
   * 
   * @return albumCoverart350x350
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumCoverart350x350() {
    return albumCoverart350x350;
  }

  public void setAlbumCoverart350x350(String albumCoverart350x350) {
    this.albumCoverart350x350 = albumCoverart350x350;
  }

  public Album artistName(String artistName) {
    this.artistName = artistName;
    return this;
  }

   /**
   * 
   * @return artistName
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getArtistName() {
    return artistName;
  }

  public void setArtistName(String artistName) {
    this.artistName = artistName;
  }

  public Album primaryGenres(AlbumPrimaryGenres primaryGenres) {
    this.primaryGenres = primaryGenres;
    return this;
  }

   /**
   * Get primaryGenres
   * @return primaryGenres
  **/
  @ApiModelProperty(example = "null", value = "")
  public AlbumPrimaryGenres getPrimaryGenres() {
    return primaryGenres;
  }

  public void setPrimaryGenres(AlbumPrimaryGenres primaryGenres) {
    this.primaryGenres = primaryGenres;
  }

  public Album albumId(BigDecimal albumId) {
    this.albumId = albumId;
    return this;
  }

   /**
   * 
   * @return albumId
  **/
  @ApiModelProperty(example = "null", value = "")
  public BigDecimal getAlbumId() {
    return albumId;
  }

  public void setAlbumId(BigDecimal albumId) {
    this.albumId = albumId;
  }

  public Album albumRating(BigDecimal albumRating) {
    this.albumRating = albumRating;
    return this;
  }

   /**
   * 
   * @return albumRating
  **/
  @ApiModelProperty(example = "null", value = "")
  public BigDecimal getAlbumRating() {
    return albumRating;
  }

  public void setAlbumRating(BigDecimal albumRating) {
    this.albumRating = albumRating;
  }

  public Album albumPline(String albumPline) {
    this.albumPline = albumPline;
    return this;
  }

   /**
   * 
   * @return albumPline
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumPline() {
    return albumPline;
  }

  public void setAlbumPline(String albumPline) {
    this.albumPline = albumPline;
  }

  public Album albumTrackCount(BigDecimal albumTrackCount) {
    this.albumTrackCount = albumTrackCount;
    return this;
  }

   /**
   * 
   * @return albumTrackCount
  **/
  @ApiModelProperty(example = "null", value = "")
  public BigDecimal getAlbumTrackCount() {
    return albumTrackCount;
  }

  public void setAlbumTrackCount(BigDecimal albumTrackCount) {
    this.albumTrackCount = albumTrackCount;
  }

  public Album albumReleaseType(String albumReleaseType) {
    this.albumReleaseType = albumReleaseType;
    return this;
  }

   /**
   * 
   * @return albumReleaseType
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumReleaseType() {
    return albumReleaseType;
  }

  public void setAlbumReleaseType(String albumReleaseType) {
    this.albumReleaseType = albumReleaseType;
  }

  public Album albumReleaseDate(String albumReleaseDate) {
    this.albumReleaseDate = albumReleaseDate;
    return this;
  }

   /**
   * 
   * @return albumReleaseDate
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumReleaseDate() {
    return albumReleaseDate;
  }

  public void setAlbumReleaseDate(String albumReleaseDate) {
    this.albumReleaseDate = albumReleaseDate;
  }

  public Album albumEditUrl(String albumEditUrl) {
    this.albumEditUrl = albumEditUrl;
    return this;
  }

   /**
   * 
   * @return albumEditUrl
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumEditUrl() {
    return albumEditUrl;
  }

  public void setAlbumEditUrl(String albumEditUrl) {
    this.albumEditUrl = albumEditUrl;
  }

  public Album updatedTime(String updatedTime) {
    this.updatedTime = updatedTime;
    return this;
  }

   /**
   * 
   * @return updatedTime
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getUpdatedTime() {
    return updatedTime;
  }

  public void setUpdatedTime(String updatedTime) {
    this.updatedTime = updatedTime;
  }

  public Album secondaryGenres(ArtistSecondaryGenres secondaryGenres) {
    this.secondaryGenres = secondaryGenres;
    return this;
  }

   /**
   * Get secondaryGenres
   * @return secondaryGenres
  **/
  @ApiModelProperty(example = "null", value = "")
  public ArtistSecondaryGenres getSecondaryGenres() {
    return secondaryGenres;
  }

  public void setSecondaryGenres(ArtistSecondaryGenres secondaryGenres) {
    this.secondaryGenres = secondaryGenres;
  }

  public Album albumMbid(String albumMbid) {
    this.albumMbid = albumMbid;
    return this;
  }

   /**
   * 
   * @return albumMbid
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumMbid() {
    return albumMbid;
  }

  public void setAlbumMbid(String albumMbid) {
    this.albumMbid = albumMbid;
  }

  public Album albumVanityId(String albumVanityId) {
    this.albumVanityId = albumVanityId;
    return this;
  }

   /**
   * 
   * @return albumVanityId
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumVanityId() {
    return albumVanityId;
  }

  public void setAlbumVanityId(String albumVanityId) {
    this.albumVanityId = albumVanityId;
  }

  public Album albumCoverart100x100(String albumCoverart100x100) {
    this.albumCoverart100x100 = albumCoverart100x100;
    return this;
  }

   /**
   * 
   * @return albumCoverart100x100
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumCoverart100x100() {
    return albumCoverart100x100;
  }

  public void setAlbumCoverart100x100(String albumCoverart100x100) {
    this.albumCoverart100x100 = albumCoverart100x100;
  }

  public Album albumLabel(String albumLabel) {
    this.albumLabel = albumLabel;
    return this;
  }

   /**
   * 
   * @return albumLabel
  **/
  @ApiModelProperty(example = "null", value = "")
  public String getAlbumLabel() {
    return albumLabel;
  }

  public void setAlbumLabel(String albumLabel) {
    this.albumLabel = albumLabel;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Album album = (Album) o;
    return Objects.equals(this.albumCoverart500x500, album.albumCoverart500x500) &&
        Objects.equals(this.restricted, album.restricted) &&
        Objects.equals(this.artistId, album.artistId) &&
        Objects.equals(this.albumName, album.albumName) &&
        Objects.equals(this.albumCoverart800x800, album.albumCoverart800x800) &&
        Objects.equals(this.albumCopyright, album.albumCopyright) &&
        Objects.equals(this.albumCoverart350x350, album.albumCoverart350x350) &&
        Objects.equals(this.artistName, album.artistName) &&
        Objects.equals(this.primaryGenres, album.primaryGenres) &&
        Objects.equals(this.albumId, album.albumId) &&
        Objects.equals(this.albumRating, album.albumRating) &&
        Objects.equals(this.albumPline, album.albumPline) &&
        Objects.equals(this.albumTrackCount, album.albumTrackCount) &&
        Objects.equals(this.albumReleaseType, album.albumReleaseType) &&
        Objects.equals(this.albumReleaseDate, album.albumReleaseDate) &&
        Objects.equals(this.albumEditUrl, album.albumEditUrl) &&
        Objects.equals(this.updatedTime, album.updatedTime) &&
        Objects.equals(this.secondaryGenres, album.secondaryGenres) &&
        Objects.equals(this.albumMbid, album.albumMbid) &&
        Objects.equals(this.albumVanityId, album.albumVanityId) &&
        Objects.equals(this.albumCoverart100x100, album.albumCoverart100x100) &&
        Objects.equals(this.albumLabel, album.albumLabel);
  }

  @Override
  public int hashCode() {
    return Objects.hash(albumCoverart500x500, restricted, artistId, albumName, albumCoverart800x800, albumCopyright, albumCoverart350x350, artistName, primaryGenres, albumId, albumRating, albumPline, albumTrackCount, albumReleaseType, albumReleaseDate, albumEditUrl, updatedTime, secondaryGenres, albumMbid, albumVanityId, albumCoverart100x100, albumLabel);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Album {\n");
    
    sb.append("    albumCoverart500x500: ").append(toIndentedString(albumCoverart500x500)).append("\n");
    sb.append("    restricted: ").append(toIndentedString(restricted)).append("\n");
    sb.append("    artistId: ").append(toIndentedString(artistId)).append("\n");
    sb.append("    albumName: ").append(toIndentedString(albumName)).append("\n");
    sb.append("    albumCoverart800x800: ").append(toIndentedString(albumCoverart800x800)).append("\n");
    sb.append("    albumCopyright: ").append(toIndentedString(albumCopyright)).append("\n");
    sb.append("    albumCoverart350x350: ").append(toIndentedString(albumCoverart350x350)).append("\n");
    sb.append("    artistName: ").append(toIndentedString(artistName)).append("\n");
    sb.append("    primaryGenres: ").append(toIndentedString(primaryGenres)).append("\n");
    sb.append("    albumId: ").append(toIndentedString(albumId)).append("\n");
    sb.append("    albumRating: ").append(toIndentedString(albumRating)).append("\n");
    sb.append("    albumPline: ").append(toIndentedString(albumPline)).append("\n");
    sb.append("    albumTrackCount: ").append(toIndentedString(albumTrackCount)).append("\n");
    sb.append("    albumReleaseType: ").append(toIndentedString(albumReleaseType)).append("\n");
    sb.append("    albumReleaseDate: ").append(toIndentedString(albumReleaseDate)).append("\n");
    sb.append("    albumEditUrl: ").append(toIndentedString(albumEditUrl)).append("\n");
    sb.append("    updatedTime: ").append(toIndentedString(updatedTime)).append("\n");
    sb.append("    secondaryGenres: ").append(toIndentedString(secondaryGenres)).append("\n");
    sb.append("    albumMbid: ").append(toIndentedString(albumMbid)).append("\n");
    sb.append("    albumVanityId: ").append(toIndentedString(albumVanityId)).append("\n");
    sb.append("    albumCoverart100x100: ").append(toIndentedString(albumCoverart100x100)).append("\n");
    sb.append("    albumLabel: ").append(toIndentedString(albumLabel)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

