
# InlineResponse2002MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**albumList** | [**List&lt;InlineResponse200MessageBody&gt;**](InlineResponse200MessageBody.md) | A list of albums |  [optional]



