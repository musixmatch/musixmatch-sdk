
# ArtistArtistNameTranslation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **String** |  |  [optional]
**translation** | **String** |  |  [optional]



