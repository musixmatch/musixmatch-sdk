
# Track

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**albumCoverart350x350** | **String** |  |  [optional]
**firstReleaseDate** | **String** |  |  [optional]
**trackIsrc** | **String** |  |  [optional]
**explicit** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**trackEditUrl** | **String** |  |  [optional]
**numFavourite** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**albumCoverart500x500** | **String** |  |  [optional]
**albumName** | **String** |  |  [optional]
**trackRating** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**trackShareUrl** | **String** |  |  [optional]
**trackSoundcloudId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**artistName** | **String** |  |  [optional]
**albumCoverart800x800** | **String** |  |  [optional]
**albumCoverart100x100** | **String** |  |  [optional]
**trackNameTranslationList** | **List&lt;String&gt;** |  |  [optional]
**trackName** | **String** |  |  [optional]
**restricted** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**hasSubtitles** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**updatedTime** | **String** |  |  [optional]
**subtitleId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**lyricsId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**trackSpotifyId** | **String** |  |  [optional]
**hasLyrics** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**artistId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**albumId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**artistMbid** | **String** |  |  [optional]
**secondaryGenres** | [**TrackSecondaryGenres**](TrackSecondaryGenres.md) |  |  [optional]
**commontrackVanityId** | **String** |  |  [optional]
**trackId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**trackXboxmusicId** | **String** |  |  [optional]
**primaryGenres** | [**TrackPrimaryGenres**](TrackPrimaryGenres.md) |  |  [optional]
**trackLength** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**trackMbid** | **String** |  |  [optional]
**commontrackId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



