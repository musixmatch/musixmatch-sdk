
# InlineResponse2006MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackList** | [**List&lt;InlineResponse2006MessageBodyTrackList&gt;**](InlineResponse2006MessageBodyTrackList.md) | A list of tracks |  [optional]



