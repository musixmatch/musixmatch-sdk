
# ArtistArtistCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | **List&lt;String&gt;** |  |  [optional]



