
# ArtistSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | **List&lt;String&gt;** |  |  [optional]



