
# TrackSecondaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**TrackSecondaryGenresMusicGenre**](TrackSecondaryGenresMusicGenre.md) |  |  [optional]



