# AlbumApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**albumGetGet**](AlbumApi.md#albumGetGet) | **GET** /album.get | 
[**artistAlbumsGetGet**](AlbumApi.md#artistAlbumsGetGet) | **GET** /artist.albums.get | 


<a name="albumGetGet"></a>
# **albumGetGet**
> InlineResponse200 albumGetGet(albumId, format, callback)





### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AlbumApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: key
ApiKeyAuth key = (ApiKeyAuth) defaultClient.getAuthentication("key");
key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//key.setApiKeyPrefix("Token");

AlbumApi apiInstance = new AlbumApi();
String albumId = "albumId_example"; // String | The musiXmatch album id
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
try {
    InlineResponse200 result = apiInstance.albumGetGet(albumId, format, callback);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlbumApi#albumGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **albumId** | **String**| The musiXmatch album id |
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="artistAlbumsGetGet"></a>
# **artistAlbumsGetGet**
> InlineResponse2002 artistAlbumsGetGet(artistId, format, callback, sReleaseDate, gAlbumName, pageSize, page)





### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.AlbumApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: key
ApiKeyAuth key = (ApiKeyAuth) defaultClient.getAuthentication("key");
key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//key.setApiKeyPrefix("Token");

AlbumApi apiInstance = new AlbumApi();
String artistId = "artistId_example"; // String | The musiXmatch artist id
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
String sReleaseDate = "sReleaseDate_example"; // String | Sort by release date (asc|desc)
String gAlbumName = "gAlbumName_example"; // String | Group by Album Name
BigDecimal pageSize = new BigDecimal(); // BigDecimal | Define the page size for paginated results.Range is 1 to 100.
BigDecimal page = new BigDecimal(); // BigDecimal | Define the page number for paginated results
try {
    InlineResponse2002 result = apiInstance.artistAlbumsGetGet(artistId, format, callback, sReleaseDate, gAlbumName, pageSize, page);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling AlbumApi#artistAlbumsGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artistId** | **String**| The musiXmatch artist id |
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **sReleaseDate** | **String**| Sort by release date (asc|desc) | [optional]
 **gAlbumName** | **String**| Group by Album Name | [optional]
 **pageSize** | **BigDecimal**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **page** | **BigDecimal**| Define the page number for paginated results | [optional]

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

