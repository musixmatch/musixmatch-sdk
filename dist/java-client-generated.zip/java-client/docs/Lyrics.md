
# Lyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**pixelTrackingUrl** | **String** |  |  [optional]
**publisherList** | **List&lt;String&gt;** |  |  [optional]
**lyricsLanguageDescription** | **String** |  |  [optional]
**restricted** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**updatedTime** | **String** |  |  [optional]
**explicit** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**lyricsCopyright** | **String** |  |  [optional]
**htmlTrackingUrl** | **String** |  |  [optional]
**lyricsLanguage** | **String** |  |  [optional]
**scriptTrackingUrl** | **String** |  |  [optional]
**verified** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**lyricsBody** | **String** |  |  [optional]
**lyricsId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**writerList** | **List&lt;String&gt;** |  |  [optional]
**canEdit** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**actionRequested** | **String** |  |  [optional]
**locked** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



