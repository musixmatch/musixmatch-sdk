
# ArtistPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**ArtistPrimaryGenresMusicGenre**](ArtistPrimaryGenresMusicGenre.md) |  |  [optional]



