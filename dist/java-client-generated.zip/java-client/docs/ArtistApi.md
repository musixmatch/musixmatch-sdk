# ArtistApi

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**artistGetGet**](ArtistApi.md#artistGetGet) | **GET** /artist.get | 
[**artistRelatedGetGet**](ArtistApi.md#artistRelatedGetGet) | **GET** /artist.related.get | 
[**artistSearchGet**](ArtistApi.md#artistSearchGet) | **GET** /artist.search | 
[**chartArtistsGetGet**](ArtistApi.md#chartArtistsGetGet) | **GET** /chart.artists.get | 


<a name="artistGetGet"></a>
# **artistGetGet**
> InlineResponse2003 artistGetGet(artistId, format, callback)





### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtistApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: key
ApiKeyAuth key = (ApiKeyAuth) defaultClient.getAuthentication("key");
key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//key.setApiKeyPrefix("Token");

ArtistApi apiInstance = new ArtistApi();
String artistId = "artistId_example"; // String |  The musiXmatch artist id
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
try {
    InlineResponse2003 result = apiInstance.artistGetGet(artistId, format, callback);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtistApi#artistGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artistId** | **String**|  The musiXmatch artist id |
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="artistRelatedGetGet"></a>
# **artistRelatedGetGet**
> InlineResponse2004 artistRelatedGetGet(artistId, format, callback, pageSize, page)





### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtistApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: key
ApiKeyAuth key = (ApiKeyAuth) defaultClient.getAuthentication("key");
key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//key.setApiKeyPrefix("Token");

ArtistApi apiInstance = new ArtistApi();
String artistId = "artistId_example"; // String | The musiXmatch artist id
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
BigDecimal pageSize = new BigDecimal(); // BigDecimal | Define the page size for paginated results.Range is 1 to 100.
BigDecimal page = new BigDecimal(); // BigDecimal | Define the page number for paginated results
try {
    InlineResponse2004 result = apiInstance.artistRelatedGetGet(artistId, format, callback, pageSize, page);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtistApi#artistRelatedGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artistId** | **String**| The musiXmatch artist id |
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **pageSize** | **BigDecimal**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **page** | **BigDecimal**| Define the page number for paginated results | [optional]

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="artistSearchGet"></a>
# **artistSearchGet**
> InlineResponse2004 artistSearchGet(format, callback, qArtist, fArtistId, page, pageSize)





### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtistApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: key
ApiKeyAuth key = (ApiKeyAuth) defaultClient.getAuthentication("key");
key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//key.setApiKeyPrefix("Token");

ArtistApi apiInstance = new ArtistApi();
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
String qArtist = "qArtist_example"; // String | The song artist
BigDecimal fArtistId = new BigDecimal(); // BigDecimal | When set, filter by this artist id
BigDecimal page = new BigDecimal(); // BigDecimal | Define the page number for paginated results
BigDecimal pageSize = new BigDecimal(); // BigDecimal | Define the page size for paginated results.Range is 1 to 100.
try {
    InlineResponse2004 result = apiInstance.artistSearchGet(format, callback, qArtist, fArtistId, page, pageSize);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtistApi#artistSearchGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **qArtist** | **String**| The song artist | [optional]
 **fArtistId** | **BigDecimal**| When set, filter by this artist id | [optional]
 **page** | **BigDecimal**| Define the page number for paginated results | [optional]
 **pageSize** | **BigDecimal**| Define the page size for paginated results.Range is 1 to 100. | [optional]

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="chartArtistsGetGet"></a>
# **chartArtistsGetGet**
> InlineResponse2005 chartArtistsGetGet(format, callback, page, pageSize, country)





### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.ArtistApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: key
ApiKeyAuth key = (ApiKeyAuth) defaultClient.getAuthentication("key");
key.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//key.setApiKeyPrefix("Token");

ArtistApi apiInstance = new ArtistApi();
String format = "json"; // String | output format: json, jsonp, xml.
String callback = "callback_example"; // String | jsonp callback
BigDecimal page = new BigDecimal(); // BigDecimal | Define the page number for paginated results
BigDecimal pageSize = new BigDecimal(); // BigDecimal | Define the page size for paginated results.Range is 1 to 100.
String country = "us"; // String | A valid ISO 3166 country code
try {
    InlineResponse2005 result = apiInstance.chartArtistsGetGet(format, callback, page, pageSize, country);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ArtistApi#chartArtistsGetGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **String**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **String**| jsonp callback | [optional]
 **page** | **BigDecimal**| Define the page number for paginated results | [optional]
 **pageSize** | **BigDecimal**| Define the page size for paginated results.Range is 1 to 100. | [optional]
 **country** | **String**| A valid ISO 3166 country code | [optional] [default to us]

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

