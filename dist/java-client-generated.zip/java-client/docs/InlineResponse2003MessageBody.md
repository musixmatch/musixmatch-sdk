
# InlineResponse2003MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | [**Artist**](Artist.md) |  |  [optional]



