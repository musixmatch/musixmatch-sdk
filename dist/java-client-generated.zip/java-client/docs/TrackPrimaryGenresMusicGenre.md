
# TrackPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreVanity** | **String** |  |  [optional]
**musicGenreNameExtended** | **String** |  |  [optional]
**musicGenreName** | **String** |  |  [optional]
**musicGenreParentId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**musicGenreId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



