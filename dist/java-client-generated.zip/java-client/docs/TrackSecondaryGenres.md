
# TrackSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**List&lt;TrackSecondaryGenresMusicGenreList&gt;**](TrackSecondaryGenresMusicGenreList.md) |  |  [optional]



