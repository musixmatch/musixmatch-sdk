
# InlineResponse2001MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**statusCode** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**available** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**executeTime** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



