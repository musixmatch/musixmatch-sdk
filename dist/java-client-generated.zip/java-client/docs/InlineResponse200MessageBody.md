
# InlineResponse200MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**album** | [**Album**](Album.md) |  |  [optional]



