
# Subtitle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subtitleBody** | **String** |  |  [optional]
**publisherList** | **List&lt;String&gt;** |  |  [optional]
**subtitleLanguage** | **String** |  |  [optional]
**subtitleLanguageDescription** | **String** |  |  [optional]
**subtitleId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**pixelTrackingUrl** | **String** |  |  [optional]
**htmlTrackingUrl** | **String** |  |  [optional]
**restricted** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**lyricsCopyright** | **String** |  |  [optional]
**scriptTrackingUrl** | **String** |  |  [optional]
**subtitleLength** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**updatedTime** | **String** |  |  [optional]
**writerList** | **List&lt;String&gt;** |  |  [optional]



