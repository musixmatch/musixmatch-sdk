
# TrackSecondaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreVanity** | **String** |  |  [optional]
**musicGenreNameExtended** | **String** |  |  [optional]
**musicGenreParentId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**musicGenreName** | **String** |  |  [optional]
**musicGenreId** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



