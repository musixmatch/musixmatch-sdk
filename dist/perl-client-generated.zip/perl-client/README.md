# NAME

WWW::SwaggerClient::Role - a Moose role for the Musixmatch API

Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop 

# VERSION

Automatically generated by the [Swagger Codegen](https://github.com/swagger-api/swagger-codegen) project:

- API version: 1.1.0
- Package version: 1.0.0
- Build date: 2016-09-26T10:40:46.452Z
- Build package: class io.swagger.codegen.languages.PerlClientCodegen
For more information, please visit [https://musixmatch.com](https://musixmatch.com)

## A note on Moose

This role is the only component of the library that uses Moose. See 
WWW::SwaggerClient::ApiFactory for non-Moosey usage. 

# SYNOPSIS

The Perl Swagger Codegen project builds a library of Perl modules to interact with 
a web service defined by a OpenAPI Specification. See below for how to build the 
library.

This module provides an interface to the generated library. All the classes, 
objects, and methods (well, not quite \*all\*, see below) are flattened into this 
role. 

        package MyApp;
        use Moose;
        with 'WWW::SwaggerClient::Role';
        
        package main;
        
        my $api = MyApp->new({ tokens => $tokens });
        
        my $pet = $api->get_pet_by_id(pet_id => $pet_id);
        

## Structure of the library

The library consists of a set of API classes, one for each endpoint. These APIs
implement the method calls available on each endpoint. 

Additionally, there is a set of "object" classes, which represent the objects 
returned by and sent to the methods on the endpoints. 

An API factory class is provided, which builds instances of each endpoint API. 

This Moose role flattens all the methods from the endpoint APIs onto the consuming 
class. It also provides methods to retrieve the endpoint API objects, and the API 
factory object, should you need it. 

For documentation of all these methods, see AUTOMATIC DOCUMENTATION below.

## Configuring authentication

In the normal case, the OpenAPI Spec will describe what parameters are
required and where to put them. You just need to supply the tokens.

    my $tokens = {
        # basic
        username => $username,
        password => $password,
        
        # oauth
        access_token => $oauth_token,
        
        # keys
        $some_key => { token => $token,
                       prefix => $prefix, 
                       in => $in,             # 'head||query',     
                       },
                       
        $another => { token => $token,
                      prefix => $prefix, 
                      in => $in,              # 'head||query',      
                      },                   
        ...,
        
        };
        
        my $api = MyApp->new({ tokens => $tokens });

Note these are all optional, as are `prefix` and `in`, and depend on the API
you are accessing. Usually `prefix` and `in` will be determined by the code generator from
the spec and you will not need to set them at run time. If not, `in` will
default to 'head' and `prefix` to the empty string. 

The tokens will be placed in the `WWW::SwaggerClient::Configuration` namespace
as follows, but you don't need to know about this. 

- `$WWW::SwaggerClient::Configuration::username`

    String. The username for basic auth.

- `$WWW::SwaggerClient::Configuration::password`

    String. The password for basic auth.

- `$WWW::SwaggerClient::Configuration::api_key`

    Hashref. Keyed on the name of each key (there can be multiple tokens).

            $WWW::SwaggerClient::Configuration::api_key = {
                    secretKey => 'aaaabbbbccccdddd',
                    anotherKey => '1111222233334444',
                    };

- `$WWW::SwaggerClient::Configuration::api_key_prefix`

    Hashref. Keyed on the name of each key (there can be multiple tokens). Note not
    all api keys require a prefix.

            $WWW::SwaggerClient::Configuration::api_key_prefix = {
                    secretKey => 'string',
                    anotherKey => 'same or some other string',
                    };

- `$WWW::SwaggerClient::Configuration::access_token`

    String. The OAuth access token. 

# METHODS

## `base_url`

The generated code has the `base_url` already set as a default value. This method 
returns (and optionally sets, but only if the API client has not been 
created yet) the current value of `base_url`.

## `api_factory`

Returns an API factory object. You probably won't need to call this directly. 

        $self->api_factory('Pet'); # returns a WWW::SwaggerClient::PetApi instance
        
        $self->pet_api;            # the same

# MISSING METHODS

Most of the methods on the API are delegated to individual endpoint API objects
(e.g. Pet API, Store API, User API etc). Where different endpoint APIs use the
same method name (e.g. `new()`), these methods can't be delegated. So you need
to call `$api->pet_api->new()`.

In principle, every API is susceptible to the presence of a few, random, undelegatable 
method names. In practice, because of the way method names are constructed, it's 
unlikely in general that any methods will be undelegatable, except for: 

        new()
        class_documentation()
        method_documentation()

To call these methods, you need to get a handle on the relevant object, either
by calling `$api->foo_api` or by retrieving an object, e.g.
`$api->get_pet_by_id(pet_id => $pet_id)`. They are class methods, so
you could also call them on class names.

# BUILDING YOUR LIBRARY

See the homepage `https://github.com/swagger-api/swagger-codegen` for full details. 
But briefly, clone the git repository, build the codegen codebase, set up your build 
config file, then run the API build script. You will need git, Java 7 or 8 and Apache
maven 3.0.3 or better already installed.

The config file should specify the project name for the generated library: 

        {"moduleName":"WWW::MyProjectName"}

Your library files will be built under `WWW::MyProjectName`.

          $ git clone https://github.com/swagger-api/swagger-codegen.git
          $ cd swagger-codegen
          $ mvn package
          $ java -jar modules/swagger-codegen-cli/target/swagger-codegen-cli.jar generate \
    -i [URL or file path to JSON swagger API spec] \
    -l perl \
    -c /path/to/config/file.json \
    -o /path/to/output/folder

Bang, all done. Run the `autodoc` script in the `bin` directory to see the API 
you just built. 

# AUTOMATIC DOCUMENTATION

You can print out a summary of the generated API by running the included
`autodoc` script in the `bin` directory of your generated library. A few
output formats are supported:

          Usage: autodoc [OPTION]

    -w           wide format (default)
    -n           narrow format
    -p           POD format 
    -H           HTML format 
    -m           Markdown format
    -h           print this help message
    -c           your application class
    

The `-c` option allows you to load and inspect your own application. A dummy
namespace is used if you don't supply your own class.

# DOCUMENTATION FROM THE OpenAPI Spec

Additional documentation for each class and method may be provided by the Swagger 
spec. If so, this is available via the `class_documentation()` and 
`method_documentation()` methods on each generated object class, and the 
`method_documentation()` method on the endpoint API classes: 

        my $cmdoc = $api->pet_api->method_documentation->{$method_name}; 
        
        my $odoc = $api->get_pet_by_id->(pet_id => $pet_id)->class_documentation;                                  
        my $omdoc = $api->get_pet_by_id->(pet_id => $pet_id)->method_documentation->{method_name}; 
        

Each of these calls returns a hashref with various useful pieces of information.

# LOAD THE MODULES

To load the API packages:
```perl
use WWW::SwaggerClient::AlbumApi;
use WWW::SwaggerClient::ArtistApi;
use WWW::SwaggerClient::LyricsApi;
use WWW::SwaggerClient::SnippetApi;
use WWW::SwaggerClient::SubtitleApi;
use WWW::SwaggerClient::TrackApi;

```

To load the models:
```perl
use WWW::SwaggerClient::Object::Album;
use WWW::SwaggerClient::Object::AlbumPrimaryGenres;
use WWW::SwaggerClient::Object::AlbumPrimaryGenresMusicGenre;
use WWW::SwaggerClient::Object::AlbumPrimaryGenresMusicGenreList;
use WWW::SwaggerClient::Object::Artist;
use WWW::SwaggerClient::Object::ArtistArtistAliasList;
use WWW::SwaggerClient::Object::ArtistArtistCredits;
use WWW::SwaggerClient::Object::ArtistArtistNameTranslation;
use WWW::SwaggerClient::Object::ArtistArtistNameTranslationList;
use WWW::SwaggerClient::Object::ArtistPrimaryGenres;
use WWW::SwaggerClient::Object::ArtistPrimaryGenresMusicGenre;
use WWW::SwaggerClient::Object::ArtistPrimaryGenresMusicGenreList;
use WWW::SwaggerClient::Object::ArtistSecondaryGenres;
use WWW::SwaggerClient::Object::InlineResponse200;
use WWW::SwaggerClient::Object::InlineResponse2001;
use WWW::SwaggerClient::Object::InlineResponse20010;
use WWW::SwaggerClient::Object::InlineResponse20010Message;
use WWW::SwaggerClient::Object::InlineResponse20010MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2001Message;
use WWW::SwaggerClient::Object::InlineResponse2001MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2001MessageHeader;
use WWW::SwaggerClient::Object::InlineResponse2002;
use WWW::SwaggerClient::Object::InlineResponse2002Message;
use WWW::SwaggerClient::Object::InlineResponse2002MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2002MessageHeader;
use WWW::SwaggerClient::Object::InlineResponse2003;
use WWW::SwaggerClient::Object::InlineResponse2003Message;
use WWW::SwaggerClient::Object::InlineResponse2003MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2004;
use WWW::SwaggerClient::Object::InlineResponse2004Message;
use WWW::SwaggerClient::Object::InlineResponse2004MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2005;
use WWW::SwaggerClient::Object::InlineResponse2005Message;
use WWW::SwaggerClient::Object::InlineResponse2005MessageHeader;
use WWW::SwaggerClient::Object::InlineResponse2006;
use WWW::SwaggerClient::Object::InlineResponse2006Message;
use WWW::SwaggerClient::Object::InlineResponse2006MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2006MessageBodyTrackList;
use WWW::SwaggerClient::Object::InlineResponse2007;
use WWW::SwaggerClient::Object::InlineResponse2007Message;
use WWW::SwaggerClient::Object::InlineResponse2007MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2008;
use WWW::SwaggerClient::Object::InlineResponse2008Message;
use WWW::SwaggerClient::Object::InlineResponse2008MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2009;
use WWW::SwaggerClient::Object::InlineResponse2009Message;
use WWW::SwaggerClient::Object::InlineResponse200Message;
use WWW::SwaggerClient::Object::InlineResponse200MessageBody;
use WWW::SwaggerClient::Object::InlineResponse200MessageHeader;
use WWW::SwaggerClient::Object::Lyrics;
use WWW::SwaggerClient::Object::Snippet;
use WWW::SwaggerClient::Object::Subtitle;
use WWW::SwaggerClient::Object::Track;
use WWW::SwaggerClient::Object::TrackPrimaryGenres;
use WWW::SwaggerClient::Object::TrackPrimaryGenresMusicGenre;
use WWW::SwaggerClient::Object::TrackPrimaryGenresMusicGenreList;
use WWW::SwaggerClient::Object::TrackSecondaryGenres;
use WWW::SwaggerClient::Object::TrackSecondaryGenresMusicGenre;
use WWW::SwaggerClient::Object::TrackSecondaryGenresMusicGenreList;

````

# GETTING STARTED
Put the Perl SDK under the 'lib' folder in your project directory, then run the following
```perl
#!/usr/bin/perl
use lib 'lib';
use strict;
use warnings;
# load the API package
use WWW::SwaggerClient::AlbumApi;
use WWW::SwaggerClient::ArtistApi;
use WWW::SwaggerClient::LyricsApi;
use WWW::SwaggerClient::SnippetApi;
use WWW::SwaggerClient::SubtitleApi;
use WWW::SwaggerClient::TrackApi;

# load the models
use WWW::SwaggerClient::Object::Album;
use WWW::SwaggerClient::Object::AlbumPrimaryGenres;
use WWW::SwaggerClient::Object::AlbumPrimaryGenresMusicGenre;
use WWW::SwaggerClient::Object::AlbumPrimaryGenresMusicGenreList;
use WWW::SwaggerClient::Object::Artist;
use WWW::SwaggerClient::Object::ArtistArtistAliasList;
use WWW::SwaggerClient::Object::ArtistArtistCredits;
use WWW::SwaggerClient::Object::ArtistArtistNameTranslation;
use WWW::SwaggerClient::Object::ArtistArtistNameTranslationList;
use WWW::SwaggerClient::Object::ArtistPrimaryGenres;
use WWW::SwaggerClient::Object::ArtistPrimaryGenresMusicGenre;
use WWW::SwaggerClient::Object::ArtistPrimaryGenresMusicGenreList;
use WWW::SwaggerClient::Object::ArtistSecondaryGenres;
use WWW::SwaggerClient::Object::InlineResponse200;
use WWW::SwaggerClient::Object::InlineResponse2001;
use WWW::SwaggerClient::Object::InlineResponse20010;
use WWW::SwaggerClient::Object::InlineResponse20010Message;
use WWW::SwaggerClient::Object::InlineResponse20010MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2001Message;
use WWW::SwaggerClient::Object::InlineResponse2001MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2001MessageHeader;
use WWW::SwaggerClient::Object::InlineResponse2002;
use WWW::SwaggerClient::Object::InlineResponse2002Message;
use WWW::SwaggerClient::Object::InlineResponse2002MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2002MessageHeader;
use WWW::SwaggerClient::Object::InlineResponse2003;
use WWW::SwaggerClient::Object::InlineResponse2003Message;
use WWW::SwaggerClient::Object::InlineResponse2003MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2004;
use WWW::SwaggerClient::Object::InlineResponse2004Message;
use WWW::SwaggerClient::Object::InlineResponse2004MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2005;
use WWW::SwaggerClient::Object::InlineResponse2005Message;
use WWW::SwaggerClient::Object::InlineResponse2005MessageHeader;
use WWW::SwaggerClient::Object::InlineResponse2006;
use WWW::SwaggerClient::Object::InlineResponse2006Message;
use WWW::SwaggerClient::Object::InlineResponse2006MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2006MessageBodyTrackList;
use WWW::SwaggerClient::Object::InlineResponse2007;
use WWW::SwaggerClient::Object::InlineResponse2007Message;
use WWW::SwaggerClient::Object::InlineResponse2007MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2008;
use WWW::SwaggerClient::Object::InlineResponse2008Message;
use WWW::SwaggerClient::Object::InlineResponse2008MessageBody;
use WWW::SwaggerClient::Object::InlineResponse2009;
use WWW::SwaggerClient::Object::InlineResponse2009Message;
use WWW::SwaggerClient::Object::InlineResponse200Message;
use WWW::SwaggerClient::Object::InlineResponse200MessageBody;
use WWW::SwaggerClient::Object::InlineResponse200MessageHeader;
use WWW::SwaggerClient::Object::Lyrics;
use WWW::SwaggerClient::Object::Snippet;
use WWW::SwaggerClient::Object::Subtitle;
use WWW::SwaggerClient::Object::Track;
use WWW::SwaggerClient::Object::TrackPrimaryGenres;
use WWW::SwaggerClient::Object::TrackPrimaryGenresMusicGenre;
use WWW::SwaggerClient::Object::TrackPrimaryGenresMusicGenreList;
use WWW::SwaggerClient::Object::TrackSecondaryGenres;
use WWW::SwaggerClient::Object::TrackSecondaryGenresMusicGenre;
use WWW::SwaggerClient::Object::TrackSecondaryGenresMusicGenreList;

# for displaying the API response data
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = 'Bearer';

my $api_instance = WWW::SwaggerClient::AlbumApi->new();
my $album_id = 'album_id_example'; # string | The musiXmatch album id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback

eval {
    my $result = $api_instance->album_get_get(album_id => $album_id, format => $format, callback => $callback);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AlbumApi->album_get_get: $@\n";
}

```

# DOCUMENTATION FOR API ENDPOINTS

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*AlbumApi* | [**album_get_get**](docs/AlbumApi.md#album_get_get) | **GET** /album.get | 
*AlbumApi* | [**artist_albums_get_get**](docs/AlbumApi.md#artist_albums_get_get) | **GET** /artist.albums.get | 
*ArtistApi* | [**artist_get_get**](docs/ArtistApi.md#artist_get_get) | **GET** /artist.get | 
*ArtistApi* | [**artist_related_get_get**](docs/ArtistApi.md#artist_related_get_get) | **GET** /artist.related.get | 
*ArtistApi* | [**artist_search_get**](docs/ArtistApi.md#artist_search_get) | **GET** /artist.search | 
*ArtistApi* | [**chart_artists_get_get**](docs/ArtistApi.md#chart_artists_get_get) | **GET** /chart.artists.get | 
*LyricsApi* | [**matcher_lyrics_get_get**](docs/LyricsApi.md#matcher_lyrics_get_get) | **GET** /matcher.lyrics.get | 
*LyricsApi* | [**track_lyrics_get_get**](docs/LyricsApi.md#track_lyrics_get_get) | **GET** /track.lyrics.get | 
*SnippetApi* | [**track_snippet_get_get**](docs/SnippetApi.md#track_snippet_get_get) | **GET** /track.snippet.get | 
*SubtitleApi* | [**matcher_subtitle_get_get**](docs/SubtitleApi.md#matcher_subtitle_get_get) | **GET** /matcher.subtitle.get | 
*SubtitleApi* | [**track_subtitle_get_get**](docs/SubtitleApi.md#track_subtitle_get_get) | **GET** /track.subtitle.get | 
*TrackApi* | [**album_tracks_get_get**](docs/TrackApi.md#album_tracks_get_get) | **GET** /album.tracks.get | 
*TrackApi* | [**chart_tracks_get_get**](docs/TrackApi.md#chart_tracks_get_get) | **GET** /chart.tracks.get | 
*TrackApi* | [**matcher_track_get_get**](docs/TrackApi.md#matcher_track_get_get) | **GET** /matcher.track.get | 
*TrackApi* | [**track_get_get**](docs/TrackApi.md#track_get_get) | **GET** /track.get | 
*TrackApi* | [**track_search_get**](docs/TrackApi.md#track_search_get) | **GET** /track.search | 


# DOCUMENTATION FOR MODELS
 - [WWW::SwaggerClient::Object::Album](docs/Album.md)
 - [WWW::SwaggerClient::Object::AlbumPrimaryGenres](docs/AlbumPrimaryGenres.md)
 - [WWW::SwaggerClient::Object::AlbumPrimaryGenresMusicGenre](docs/AlbumPrimaryGenresMusicGenre.md)
 - [WWW::SwaggerClient::Object::AlbumPrimaryGenresMusicGenreList](docs/AlbumPrimaryGenresMusicGenreList.md)
 - [WWW::SwaggerClient::Object::Artist](docs/Artist.md)
 - [WWW::SwaggerClient::Object::ArtistArtistAliasList](docs/ArtistArtistAliasList.md)
 - [WWW::SwaggerClient::Object::ArtistArtistCredits](docs/ArtistArtistCredits.md)
 - [WWW::SwaggerClient::Object::ArtistArtistNameTranslation](docs/ArtistArtistNameTranslation.md)
 - [WWW::SwaggerClient::Object::ArtistArtistNameTranslationList](docs/ArtistArtistNameTranslationList.md)
 - [WWW::SwaggerClient::Object::ArtistPrimaryGenres](docs/ArtistPrimaryGenres.md)
 - [WWW::SwaggerClient::Object::ArtistPrimaryGenresMusicGenre](docs/ArtistPrimaryGenresMusicGenre.md)
 - [WWW::SwaggerClient::Object::ArtistPrimaryGenresMusicGenreList](docs/ArtistPrimaryGenresMusicGenreList.md)
 - [WWW::SwaggerClient::Object::ArtistSecondaryGenres](docs/ArtistSecondaryGenres.md)
 - [WWW::SwaggerClient::Object::InlineResponse200](docs/InlineResponse200.md)
 - [WWW::SwaggerClient::Object::InlineResponse2001](docs/InlineResponse2001.md)
 - [WWW::SwaggerClient::Object::InlineResponse20010](docs/InlineResponse20010.md)
 - [WWW::SwaggerClient::Object::InlineResponse20010Message](docs/InlineResponse20010Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse20010MessageBody](docs/InlineResponse20010MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse2001Message](docs/InlineResponse2001Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse2001MessageBody](docs/InlineResponse2001MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse2001MessageHeader](docs/InlineResponse2001MessageHeader.md)
 - [WWW::SwaggerClient::Object::InlineResponse2002](docs/InlineResponse2002.md)
 - [WWW::SwaggerClient::Object::InlineResponse2002Message](docs/InlineResponse2002Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse2002MessageBody](docs/InlineResponse2002MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse2002MessageHeader](docs/InlineResponse2002MessageHeader.md)
 - [WWW::SwaggerClient::Object::InlineResponse2003](docs/InlineResponse2003.md)
 - [WWW::SwaggerClient::Object::InlineResponse2003Message](docs/InlineResponse2003Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse2003MessageBody](docs/InlineResponse2003MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse2004](docs/InlineResponse2004.md)
 - [WWW::SwaggerClient::Object::InlineResponse2004Message](docs/InlineResponse2004Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse2004MessageBody](docs/InlineResponse2004MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse2005](docs/InlineResponse2005.md)
 - [WWW::SwaggerClient::Object::InlineResponse2005Message](docs/InlineResponse2005Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse2005MessageHeader](docs/InlineResponse2005MessageHeader.md)
 - [WWW::SwaggerClient::Object::InlineResponse2006](docs/InlineResponse2006.md)
 - [WWW::SwaggerClient::Object::InlineResponse2006Message](docs/InlineResponse2006Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse2006MessageBody](docs/InlineResponse2006MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse2006MessageBodyTrackList](docs/InlineResponse2006MessageBodyTrackList.md)
 - [WWW::SwaggerClient::Object::InlineResponse2007](docs/InlineResponse2007.md)
 - [WWW::SwaggerClient::Object::InlineResponse2007Message](docs/InlineResponse2007Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse2007MessageBody](docs/InlineResponse2007MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse2008](docs/InlineResponse2008.md)
 - [WWW::SwaggerClient::Object::InlineResponse2008Message](docs/InlineResponse2008Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse2008MessageBody](docs/InlineResponse2008MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse2009](docs/InlineResponse2009.md)
 - [WWW::SwaggerClient::Object::InlineResponse2009Message](docs/InlineResponse2009Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse200Message](docs/InlineResponse200Message.md)
 - [WWW::SwaggerClient::Object::InlineResponse200MessageBody](docs/InlineResponse200MessageBody.md)
 - [WWW::SwaggerClient::Object::InlineResponse200MessageHeader](docs/InlineResponse200MessageHeader.md)
 - [WWW::SwaggerClient::Object::Lyrics](docs/Lyrics.md)
 - [WWW::SwaggerClient::Object::Snippet](docs/Snippet.md)
 - [WWW::SwaggerClient::Object::Subtitle](docs/Subtitle.md)
 - [WWW::SwaggerClient::Object::Track](docs/Track.md)
 - [WWW::SwaggerClient::Object::TrackPrimaryGenres](docs/TrackPrimaryGenres.md)
 - [WWW::SwaggerClient::Object::TrackPrimaryGenresMusicGenre](docs/TrackPrimaryGenresMusicGenre.md)
 - [WWW::SwaggerClient::Object::TrackPrimaryGenresMusicGenreList](docs/TrackPrimaryGenresMusicGenreList.md)
 - [WWW::SwaggerClient::Object::TrackSecondaryGenres](docs/TrackSecondaryGenres.md)
 - [WWW::SwaggerClient::Object::TrackSecondaryGenresMusicGenre](docs/TrackSecondaryGenresMusicGenre.md)
 - [WWW::SwaggerClient::Object::TrackSecondaryGenresMusicGenreList](docs/TrackSecondaryGenresMusicGenreList.md)


# DOCUMENTATION FOR AUTHORIATION

## key

- **Type**: API key 
- **API key parameter name**: apikey
- **Location**: URL query string



