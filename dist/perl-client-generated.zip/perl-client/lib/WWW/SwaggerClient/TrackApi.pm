=begin comment

Musixmatch API

Musixmatch lyrics API is a robust service that permits you to search and retrieve lyrics in the simplest possible way. It just works.  Include millions of licensed lyrics on your website or in your application legally.  The fastest, most powerful and legal way to display lyrics on your website or in your application.  #### Read musixmatch API Terms & Conditions and the Privacy Policy: Before getting started, you must take a look at the [API Terms & Conditions](http://musixmatch.com/apiterms/) and the [Privacy Policy](https://developer.musixmatch.com/privacy). We’ve worked hard to make this service completely legal so that we are all protected from any foreseeable liability. Take the time to read this stuff.  #### Register for an API key: All you need to do is [register](https://developer.musixmatch.com/signup) in order to get your API key, a mandatory parameter for most of our API calls. It’s your personal identifier and should be kept secret:  ```   https://api.musixmatch.com/ws/v1.1/track.get?apikey=YOUR_API_KEY ``` #### Integrate the musixmatch service with your web site or application In the most common scenario you only need to implement two API calls:  The first call is to match your catalog to ours using the [track.search](#!/Track/get_track_search) function and the second is to get the lyrics using the [track.lyrics.get](#!/Lyrics/get_track_lyrics_get) api. That’s it!  ## API Methods What does the musiXmatch API do?  The musiXmatch API allows you to read objects from our huge 100% licensed lyrics database.  To make your life easier we are providing you with one or more examples to show you how it could work in the wild. You’ll find both the API request and API response in all the available output formats for each API call. Follow the links below for the details.  The current API version is 1.1, the root URL is located at https://api.musixmatch.com/ws/1.1/  Supported input parameters can be found on the page [Input Parameters](https://developer.musixmatch.com/documentation/input-parameters). Use UTF-8 to encode arguments when calling API methods.  Every response includes a status_code. A list of all status codes can be consulted at [Status Codes](https://developer.musixmatch.com/documentation/status-codes).  ## Music meta data The musiXmatch api is built around lyrics, but there are many other data we provide through the api that can be used to improve every existent music service.  ## Track Inside the track object you can get the following extra information:  ### TRACK RATING  The track rating is a score 0-100 identifying how popular is a song in musixmatch.  You can use this information to sort search results, like the most popular songs of an artist, of a music genre, of a lyrics language.  ### INSTRUMENTAL AND EXPLICIT FLAGS  The instrumental flag identifies songs with music only, no lyrics.  The explicit flag identifies songs with explicit lyrics or explicit title. We're able to identify explicit words and set the flag for the most common languages.  ### FAVOURITES  How many users have this song in their list of favourites.  Can be used to sort tracks by num favourite to identify more popular tracks within a set.  ### MUSIC GENRE  The music genere of the song.  Can be used to group songs by genre, as input for similarity alghorithms, artist genre identification, navigate songs by genere, etc.  ### SONG TITLES TRANSLATIONS  The track title, as translated in different lanauages, can be used to display the right writing for a given user, example:  LIES (Bigbang) becomes 在光化門 in chinese HALLELUJAH (Bigbang) becomes ハレルヤ in japanese   ## Artist Inside the artist object you can get the following nice extra information:  ### COMMENTS AND COUNTRY  An artist comment is a short snippet of text which can be mainly used for disambiguation.  The artist country is the born country of the artist/group  There are two perfect search result if you search by artist with the keyword \"U2\". Indeed there are two distinct music groups with this same name, one is the most known irish group of Bono Vox, the other is a less popular (world wide speaking) group from Japan.  Here's how you can made use of the artist comment in your search result page:  U2 (Irish rock band) U2 (あきやまうに) You can also show the artist country for even better disambiguation:  U2 (Irish rock band) from Ireland U2 (あきやまうに) from Japan ARTIST TRANSLATIONS  When you create a world wide music related service you have to take into consideration to display the artist name in the user's local language. These translation are also used as aliases to improve the search results.  Let's use PSY for this example.  Western people know him as PSY but korean want to see the original name 싸이.  Using the name translations provided by our api you can show to every user the writing they expect to see.  Furthermore, when you search for \"psy gangnam style\" or \"싸이 gangnam style\" with our search/match api you will still be able to find the song.  ### ARTIST RATING  The artist rating is a score 0-100 identifying how popular is an artist in musixmatch.  You can use this information to build charts, for suggestions, to sort search results. In the example above about U2, we use the artist rating to show the irish band before the japanese one in our serp.  ### ARTIST MUSIC GENRE  We provide one or more main artist genre, this information can be used to calculate similar artist, suggestions, or the filter a search by artist genre.    ## Album Inside the album object you can get the following nice extra information:  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM RATING  The album rating is a score 0-100 identifying how popular is an album in musixmatch.  You can use this information to sort search results, like the most popular albums of an artist.  ### ALBUM COPYRIGHT AND LABEL  For most of our albums we can provide extra information like for example:  Label: Universal-Island Records Ltd. Copyright: (P) 2013 Rubyworks, under license to Columbia Records, a Division of Sony Music Entertainment. ALBUM TYPE AND RELEASE DATE  The album official release date can be used to sort an artist's albums view starting by the most recent one.  Album can also be filtered or grouped by type: Single, Album, Compilation, Remix, Live. This can help to build an artist page with a more organized structure.  ### ALBUM MUSIC GENRE  For most of the albums we provide two groups of music genres. Primary and secondary. This information can be used to help user navigate albums by genre.  An example could be:  Primary genere: POP Secondary genre: K-POP or Mandopop 

OpenAPI spec version: 1.1.0
Contact: info@musixmatch.com
Generated by: https://github.com/swagger-api/swagger-codegen.git

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

=end comment

=cut

#
# NOTE: This class is auto generated by the swagger code generator program. 
# Do not edit the class manually.
# Ref: https://github.com/swagger-api/swagger-codegen
#
package WWW::SwaggerClient::TrackApi;

require 5.6.0;
use strict;
use warnings;
use utf8; 
use Exporter;
use Carp qw( croak );
use Log::Any qw($log);

use WWW::SwaggerClient::ApiClient;
use WWW::SwaggerClient::Configuration;

use base "Class::Data::Inheritable";

__PACKAGE__->mk_classdata('method_documentation' => {});

sub new {
    my $class   = shift;
    my (%self) = (
        'api_client' => WWW::SwaggerClient::ApiClient->instance,
        @_
    );

    #my $self = {
    #    #api_client => $options->{api_client}
    #    api_client => $default_api_client
    #}; 

    bless \%self, $class;

}


#
# album_tracks_get_get
#
# 
# 
# @param string $album_id The musiXmatch album id (required)
# @param string $format output format: json, jsonp, xml. (optional, default to json)
# @param string $callback jsonp callback (optional)
# @param string $f_has_lyrics When set, filter only contents with lyrics (optional)
# @param Number $page Define the page number for paginated results (optional)
# @param Number $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
{
    my $params = {
    'album_id' => {
        data_type => 'string',
        description => 'The musiXmatch album id',
        required => '1',
    },
    'format' => {
        data_type => 'string',
        description => 'output format: json, jsonp, xml.',
        required => '0',
    },
    'callback' => {
        data_type => 'string',
        description => 'jsonp callback',
        required => '0',
    },
    'f_has_lyrics' => {
        data_type => 'string',
        description => 'When set, filter only contents with lyrics',
        required => '0',
    },
    'page' => {
        data_type => 'Number',
        description => 'Define the page number for paginated results',
        required => '0',
    },
    'page_size' => {
        data_type => 'Number',
        description => 'Define the page size for paginated results.Range is 1 to 100.',
        required => '0',
    },
    };
    __PACKAGE__->method_documentation->{ 'album_tracks_get_get' } = { 
    	summary => '',
        params => $params,
        returns => 'InlineResponse2001',
        };
}
# @return InlineResponse2001
#
sub album_tracks_get_get {
    my ($self, %args) = @_;

    # verify the required parameter 'album_id' is set
    unless (exists $args{'album_id'}) {
      croak("Missing the required parameter 'album_id' when calling album_tracks_get_get");
    }

    # parse inputs
    my $_resource_path = '/album.tracks.get';
    $_resource_path =~ s/{format}/json/; # default format to json

    my $_method = 'GET';
    my $query_params = {};
    my $header_params = {};
    my $form_params = {};

    # 'Accept' and 'Content-Type' header
    my $_header_accept = $self->{api_client}->select_header_accept('application/json');
    if ($_header_accept) {
        $header_params->{'Accept'} = $_header_accept;
    }
    $header_params->{'Content-Type'} = $self->{api_client}->select_header_content_type('application/json');

    # query params
    if ( exists $args{'format'}) {
        $query_params->{'format'} = $self->{api_client}->to_query_value($args{'format'});
    }

    # query params
    if ( exists $args{'callback'}) {
        $query_params->{'callback'} = $self->{api_client}->to_query_value($args{'callback'});
    }

    # query params
    if ( exists $args{'album_id'}) {
        $query_params->{'album_id'} = $self->{api_client}->to_query_value($args{'album_id'});
    }

    # query params
    if ( exists $args{'f_has_lyrics'}) {
        $query_params->{'f_has_lyrics'} = $self->{api_client}->to_query_value($args{'f_has_lyrics'});
    }

    # query params
    if ( exists $args{'page'}) {
        $query_params->{'page'} = $self->{api_client}->to_query_value($args{'page'});
    }

    # query params
    if ( exists $args{'page_size'}) {
        $query_params->{'page_size'} = $self->{api_client}->to_query_value($args{'page_size'});
    }

    my $_body_data;
    # authentication setting, if any
    my $auth_settings = [qw(key )];

    # make the API Call
    my $response = $self->{api_client}->call_api($_resource_path, $_method,
                                           $query_params, $form_params,
                                           $header_params, $_body_data, $auth_settings);
    if (!$response) {
        return;
    }
    my $_response_object = $self->{api_client}->deserialize('InlineResponse2001', $response);
    return $_response_object;
}

#
# chart_tracks_get_get
#
# 
# 
# @param string $format output format: json, jsonp, xml. (optional, default to json)
# @param string $callback jsonp callback (optional)
# @param Number $page Define the page number for paginated results (optional)
# @param Number $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
# @param string $country A valid ISO 3166 country code (optional, default to us)
# @param string $f_has_lyrics When set, filter only contents with lyrics (optional)
{
    my $params = {
    'format' => {
        data_type => 'string',
        description => 'output format: json, jsonp, xml.',
        required => '0',
    },
    'callback' => {
        data_type => 'string',
        description => 'jsonp callback',
        required => '0',
    },
    'page' => {
        data_type => 'Number',
        description => 'Define the page number for paginated results',
        required => '0',
    },
    'page_size' => {
        data_type => 'Number',
        description => 'Define the page size for paginated results.Range is 1 to 100.',
        required => '0',
    },
    'country' => {
        data_type => 'string',
        description => 'A valid ISO 3166 country code',
        required => '0',
    },
    'f_has_lyrics' => {
        data_type => 'string',
        description => 'When set, filter only contents with lyrics',
        required => '0',
    },
    };
    __PACKAGE__->method_documentation->{ 'chart_tracks_get_get' } = { 
    	summary => '',
        params => $params,
        returns => 'InlineResponse2006',
        };
}
# @return InlineResponse2006
#
sub chart_tracks_get_get {
    my ($self, %args) = @_;

    # parse inputs
    my $_resource_path = '/chart.tracks.get';
    $_resource_path =~ s/{format}/json/; # default format to json

    my $_method = 'GET';
    my $query_params = {};
    my $header_params = {};
    my $form_params = {};

    # 'Accept' and 'Content-Type' header
    my $_header_accept = $self->{api_client}->select_header_accept('application/json');
    if ($_header_accept) {
        $header_params->{'Accept'} = $_header_accept;
    }
    $header_params->{'Content-Type'} = $self->{api_client}->select_header_content_type('application/json');

    # query params
    if ( exists $args{'format'}) {
        $query_params->{'format'} = $self->{api_client}->to_query_value($args{'format'});
    }

    # query params
    if ( exists $args{'callback'}) {
        $query_params->{'callback'} = $self->{api_client}->to_query_value($args{'callback'});
    }

    # query params
    if ( exists $args{'page'}) {
        $query_params->{'page'} = $self->{api_client}->to_query_value($args{'page'});
    }

    # query params
    if ( exists $args{'page_size'}) {
        $query_params->{'page_size'} = $self->{api_client}->to_query_value($args{'page_size'});
    }

    # query params
    if ( exists $args{'country'}) {
        $query_params->{'country'} = $self->{api_client}->to_query_value($args{'country'});
    }

    # query params
    if ( exists $args{'f_has_lyrics'}) {
        $query_params->{'f_has_lyrics'} = $self->{api_client}->to_query_value($args{'f_has_lyrics'});
    }

    my $_body_data;
    # authentication setting, if any
    my $auth_settings = [qw(key )];

    # make the API Call
    my $response = $self->{api_client}->call_api($_resource_path, $_method,
                                           $query_params, $form_params,
                                           $header_params, $_body_data, $auth_settings);
    if (!$response) {
        return;
    }
    my $_response_object = $self->{api_client}->deserialize('InlineResponse2006', $response);
    return $_response_object;
}

#
# matcher_track_get_get
#
# 
# 
# @param string $format output format: json, jsonp, xml. (optional, default to json)
# @param string $callback jsonp callback (optional)
# @param string $q_artist The song artist (optional)
# @param string $q_track The song title (optional)
# @param Number $f_has_lyrics When set, filter only contents with lyrics (optional)
# @param Number $f_has_subtitle When set, filter only contents with subtitles (optional)
{
    my $params = {
    'format' => {
        data_type => 'string',
        description => 'output format: json, jsonp, xml.',
        required => '0',
    },
    'callback' => {
        data_type => 'string',
        description => 'jsonp callback',
        required => '0',
    },
    'q_artist' => {
        data_type => 'string',
        description => 'The song artist',
        required => '0',
    },
    'q_track' => {
        data_type => 'string',
        description => 'The song title',
        required => '0',
    },
    'f_has_lyrics' => {
        data_type => 'Number',
        description => 'When set, filter only contents with lyrics',
        required => '0',
    },
    'f_has_subtitle' => {
        data_type => 'Number',
        description => 'When set, filter only contents with subtitles',
        required => '0',
    },
    };
    __PACKAGE__->method_documentation->{ 'matcher_track_get_get' } = { 
    	summary => '',
        params => $params,
        returns => 'InlineResponse2009',
        };
}
# @return InlineResponse2009
#
sub matcher_track_get_get {
    my ($self, %args) = @_;

    # parse inputs
    my $_resource_path = '/matcher.track.get';
    $_resource_path =~ s/{format}/json/; # default format to json

    my $_method = 'GET';
    my $query_params = {};
    my $header_params = {};
    my $form_params = {};

    # 'Accept' and 'Content-Type' header
    my $_header_accept = $self->{api_client}->select_header_accept('application/json');
    if ($_header_accept) {
        $header_params->{'Accept'} = $_header_accept;
    }
    $header_params->{'Content-Type'} = $self->{api_client}->select_header_content_type('application/json');

    # query params
    if ( exists $args{'format'}) {
        $query_params->{'format'} = $self->{api_client}->to_query_value($args{'format'});
    }

    # query params
    if ( exists $args{'callback'}) {
        $query_params->{'callback'} = $self->{api_client}->to_query_value($args{'callback'});
    }

    # query params
    if ( exists $args{'q_artist'}) {
        $query_params->{'q_artist'} = $self->{api_client}->to_query_value($args{'q_artist'});
    }

    # query params
    if ( exists $args{'q_track'}) {
        $query_params->{'q_track'} = $self->{api_client}->to_query_value($args{'q_track'});
    }

    # query params
    if ( exists $args{'f_has_lyrics'}) {
        $query_params->{'f_has_lyrics'} = $self->{api_client}->to_query_value($args{'f_has_lyrics'});
    }

    # query params
    if ( exists $args{'f_has_subtitle'}) {
        $query_params->{'f_has_subtitle'} = $self->{api_client}->to_query_value($args{'f_has_subtitle'});
    }

    my $_body_data;
    # authentication setting, if any
    my $auth_settings = [qw(key )];

    # make the API Call
    my $response = $self->{api_client}->call_api($_resource_path, $_method,
                                           $query_params, $form_params,
                                           $header_params, $_body_data, $auth_settings);
    if (!$response) {
        return;
    }
    my $_response_object = $self->{api_client}->deserialize('InlineResponse2009', $response);
    return $_response_object;
}

#
# track_get_get
#
# 
# 
# @param string $track_id The musiXmatch track id (required)
# @param string $format output format: json, jsonp, xml. (optional, default to json)
# @param string $callback jsonp callback (optional)
{
    my $params = {
    'track_id' => {
        data_type => 'string',
        description => 'The musiXmatch track id',
        required => '1',
    },
    'format' => {
        data_type => 'string',
        description => 'output format: json, jsonp, xml.',
        required => '0',
    },
    'callback' => {
        data_type => 'string',
        description => 'jsonp callback',
        required => '0',
    },
    };
    __PACKAGE__->method_documentation->{ 'track_get_get' } = { 
    	summary => '',
        params => $params,
        returns => 'InlineResponse2009',
        };
}
# @return InlineResponse2009
#
sub track_get_get {
    my ($self, %args) = @_;

    # verify the required parameter 'track_id' is set
    unless (exists $args{'track_id'}) {
      croak("Missing the required parameter 'track_id' when calling track_get_get");
    }

    # parse inputs
    my $_resource_path = '/track.get';
    $_resource_path =~ s/{format}/json/; # default format to json

    my $_method = 'GET';
    my $query_params = {};
    my $header_params = {};
    my $form_params = {};

    # 'Accept' and 'Content-Type' header
    my $_header_accept = $self->{api_client}->select_header_accept('application/json');
    if ($_header_accept) {
        $header_params->{'Accept'} = $_header_accept;
    }
    $header_params->{'Content-Type'} = $self->{api_client}->select_header_content_type('application/json');

    # query params
    if ( exists $args{'format'}) {
        $query_params->{'format'} = $self->{api_client}->to_query_value($args{'format'});
    }

    # query params
    if ( exists $args{'callback'}) {
        $query_params->{'callback'} = $self->{api_client}->to_query_value($args{'callback'});
    }

    # query params
    if ( exists $args{'track_id'}) {
        $query_params->{'track_id'} = $self->{api_client}->to_query_value($args{'track_id'});
    }

    my $_body_data;
    # authentication setting, if any
    my $auth_settings = [qw(key )];

    # make the API Call
    my $response = $self->{api_client}->call_api($_resource_path, $_method,
                                           $query_params, $form_params,
                                           $header_params, $_body_data, $auth_settings);
    if (!$response) {
        return;
    }
    my $_response_object = $self->{api_client}->deserialize('InlineResponse2009', $response);
    return $_response_object;
}

#
# track_search_get
#
# 
# 
# @param string $format output format: json, jsonp, xml. (optional, default to json)
# @param string $callback jsonp callback (optional)
# @param string $q_track The song title (optional)
# @param string $q_artist The song artist (optional)
# @param string $q_lyrics Any word in the lyrics (optional)
# @param Number $f_artist_id When set, filter by this artist id (optional)
# @param Number $f_music_genre_id When set, filter by this music category id (optional)
# @param Number $f_lyrics_language Filter by the lyrics language (en,it,..) (optional)
# @param Number $f_has_lyrics When set, filter only contents with lyrics (optional)
# @param string $s_artist_rating Sort by our popularity index for artists (asc|desc) (optional)
# @param string $s_track_rating Sort by our popularity index for tracks (asc|desc) (optional)
# @param Number $quorum_factor Search only a part of the given query string.Allowed range is (0.1 – 0.9) (optional, default to 1)
# @param Number $page_size Define the page size for paginated results.Range is 1 to 100. (optional)
# @param Number $page Define the page number for paginated results (optional)
{
    my $params = {
    'format' => {
        data_type => 'string',
        description => 'output format: json, jsonp, xml.',
        required => '0',
    },
    'callback' => {
        data_type => 'string',
        description => 'jsonp callback',
        required => '0',
    },
    'q_track' => {
        data_type => 'string',
        description => 'The song title',
        required => '0',
    },
    'q_artist' => {
        data_type => 'string',
        description => 'The song artist',
        required => '0',
    },
    'q_lyrics' => {
        data_type => 'string',
        description => 'Any word in the lyrics',
        required => '0',
    },
    'f_artist_id' => {
        data_type => 'Number',
        description => 'When set, filter by this artist id',
        required => '0',
    },
    'f_music_genre_id' => {
        data_type => 'Number',
        description => 'When set, filter by this music category id',
        required => '0',
    },
    'f_lyrics_language' => {
        data_type => 'Number',
        description => 'Filter by the lyrics language (en,it,..)',
        required => '0',
    },
    'f_has_lyrics' => {
        data_type => 'Number',
        description => 'When set, filter only contents with lyrics',
        required => '0',
    },
    's_artist_rating' => {
        data_type => 'string',
        description => 'Sort by our popularity index for artists (asc|desc)',
        required => '0',
    },
    's_track_rating' => {
        data_type => 'string',
        description => 'Sort by our popularity index for tracks (asc|desc)',
        required => '0',
    },
    'quorum_factor' => {
        data_type => 'Number',
        description => 'Search only a part of the given query string.Allowed range is (0.1 – 0.9)',
        required => '0',
    },
    'page_size' => {
        data_type => 'Number',
        description => 'Define the page size for paginated results.Range is 1 to 100.',
        required => '0',
    },
    'page' => {
        data_type => 'Number',
        description => 'Define the page number for paginated results',
        required => '0',
    },
    };
    __PACKAGE__->method_documentation->{ 'track_search_get' } = { 
    	summary => '',
        params => $params,
        returns => 'InlineResponse2006',
        };
}
# @return InlineResponse2006
#
sub track_search_get {
    my ($self, %args) = @_;

    # parse inputs
    my $_resource_path = '/track.search';
    $_resource_path =~ s/{format}/json/; # default format to json

    my $_method = 'GET';
    my $query_params = {};
    my $header_params = {};
    my $form_params = {};

    # 'Accept' and 'Content-Type' header
    my $_header_accept = $self->{api_client}->select_header_accept('application/json');
    if ($_header_accept) {
        $header_params->{'Accept'} = $_header_accept;
    }
    $header_params->{'Content-Type'} = $self->{api_client}->select_header_content_type('application/json');

    # query params
    if ( exists $args{'format'}) {
        $query_params->{'format'} = $self->{api_client}->to_query_value($args{'format'});
    }

    # query params
    if ( exists $args{'callback'}) {
        $query_params->{'callback'} = $self->{api_client}->to_query_value($args{'callback'});
    }

    # query params
    if ( exists $args{'q_track'}) {
        $query_params->{'q_track'} = $self->{api_client}->to_query_value($args{'q_track'});
    }

    # query params
    if ( exists $args{'q_artist'}) {
        $query_params->{'q_artist'} = $self->{api_client}->to_query_value($args{'q_artist'});
    }

    # query params
    if ( exists $args{'q_lyrics'}) {
        $query_params->{'q_lyrics'} = $self->{api_client}->to_query_value($args{'q_lyrics'});
    }

    # query params
    if ( exists $args{'f_artist_id'}) {
        $query_params->{'f_artist_id'} = $self->{api_client}->to_query_value($args{'f_artist_id'});
    }

    # query params
    if ( exists $args{'f_music_genre_id'}) {
        $query_params->{'f_music_genre_id'} = $self->{api_client}->to_query_value($args{'f_music_genre_id'});
    }

    # query params
    if ( exists $args{'f_lyrics_language'}) {
        $query_params->{'f_lyrics_language'} = $self->{api_client}->to_query_value($args{'f_lyrics_language'});
    }

    # query params
    if ( exists $args{'f_has_lyrics'}) {
        $query_params->{'f_has_lyrics'} = $self->{api_client}->to_query_value($args{'f_has_lyrics'});
    }

    # query params
    if ( exists $args{'s_artist_rating'}) {
        $query_params->{'s_artist_rating'} = $self->{api_client}->to_query_value($args{'s_artist_rating'});
    }

    # query params
    if ( exists $args{'s_track_rating'}) {
        $query_params->{'s_track_rating'} = $self->{api_client}->to_query_value($args{'s_track_rating'});
    }

    # query params
    if ( exists $args{'quorum_factor'}) {
        $query_params->{'quorum_factor'} = $self->{api_client}->to_query_value($args{'quorum_factor'});
    }

    # query params
    if ( exists $args{'page_size'}) {
        $query_params->{'page_size'} = $self->{api_client}->to_query_value($args{'page_size'});
    }

    # query params
    if ( exists $args{'page'}) {
        $query_params->{'page'} = $self->{api_client}->to_query_value($args{'page'});
    }

    my $_body_data;
    # authentication setting, if any
    my $auth_settings = [qw(key )];

    # make the API Call
    my $response = $self->{api_client}->call_api($_resource_path, $_method,
                                           $query_params, $form_params,
                                           $header_params, $_body_data, $auth_settings);
    if (!$response) {
        return;
    }
    my $_response_object = $self->{api_client}->deserialize('InlineResponse2006', $response);
    return $_response_object;
}

1;
