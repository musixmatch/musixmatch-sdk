# WWW::SwaggerClient::Object::InlineResponse2001MessageHeader

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2001MessageHeader;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status_code** | [**Number**](Number.md) |  | [optional] 
**available** | [**Number**](Number.md) |  | [optional] 
**execute_time** | [**Number**](Number.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


