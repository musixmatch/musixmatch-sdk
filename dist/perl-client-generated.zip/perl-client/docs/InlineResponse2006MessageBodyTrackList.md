# WWW::SwaggerClient::Object::InlineResponse2006MessageBodyTrackList

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2006MessageBodyTrackList;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track** | [**Track**](Track.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


