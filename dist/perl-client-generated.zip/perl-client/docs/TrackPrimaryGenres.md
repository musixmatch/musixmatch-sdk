# WWW::SwaggerClient::Object::TrackPrimaryGenres

## Load the model package
```perl
use WWW::SwaggerClient::Object::TrackPrimaryGenres;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_list** | [**ARRAY[TrackPrimaryGenresMusicGenreList]**](TrackPrimaryGenresMusicGenreList.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


