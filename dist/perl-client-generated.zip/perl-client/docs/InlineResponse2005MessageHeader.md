# WWW::SwaggerClient::Object::InlineResponse2005MessageHeader

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2005MessageHeader;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | [**Number**](Number.md) |  | [optional] 
**status_code** | [**Number**](Number.md) |  | [optional] 
**execute_time** | [**Number**](Number.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


