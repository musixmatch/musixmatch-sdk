# WWW::SwaggerClient::Object::Snippet

## Load the model package
```perl
use WWW::SwaggerClient::Object::Snippet;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**html_tracking_url** | **string** |  | [optional] 
**instrumental** | [**Number**](Number.md) |  | [optional] 
**restricted** | [**Number**](Number.md) |  | [optional] 
**updated_time** | **string** |  | [optional] 
**snippet_body** | **string** |  | [optional] 
**pixel_tracking_url** | **string** |  | [optional] 
**snippet_id** | [**Number**](Number.md) |  | [optional] 
**script_tracking_url** | **string** |  | [optional] 
**snippet_language** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


