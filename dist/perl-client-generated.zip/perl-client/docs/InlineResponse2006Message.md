# WWW::SwaggerClient::Object::InlineResponse2006Message

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2006Message;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2005MessageHeader**](InlineResponse2005MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2006MessageBody**](InlineResponse2006MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


