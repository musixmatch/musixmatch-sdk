# WWW::SwaggerClient::Object::InlineResponse20010Message

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse20010Message;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse20010MessageBody**](InlineResponse20010MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


