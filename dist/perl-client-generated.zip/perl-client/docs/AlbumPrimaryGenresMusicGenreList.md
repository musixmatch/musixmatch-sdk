# WWW::SwaggerClient::Object::AlbumPrimaryGenresMusicGenreList

## Load the model package
```perl
use WWW::SwaggerClient::Object::AlbumPrimaryGenresMusicGenreList;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre** | [**AlbumPrimaryGenresMusicGenre**](AlbumPrimaryGenresMusicGenre.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


