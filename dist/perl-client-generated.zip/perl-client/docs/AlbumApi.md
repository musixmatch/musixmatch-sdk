# WWW::SwaggerClient::AlbumApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::AlbumApi;
```

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**album_get_get**](AlbumApi.md#album_get_get) | **GET** /album.get | 
[**artist_albums_get_get**](AlbumApi.md#artist_albums_get_get) | **GET** /artist.albums.get | 


# **album_get_get**
> InlineResponse200 album_get_get(album_id => $album_id, format => $format, callback => $callback)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::AlbumApi->new();
my $album_id = 'album_id_example'; # string | The musiXmatch album id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback

eval { 
    my $result = $api_instance->album_get_get(album_id => $album_id, format => $format, callback => $callback);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AlbumApi->album_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **album_id** | **string**| The musiXmatch album id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **artist_albums_get_get**
> InlineResponse2002 artist_albums_get_get(artist_id => $artist_id, format => $format, callback => $callback, s_release_date => $s_release_date, g_album_name => $g_album_name, page_size => $page_size, page => $page)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::AlbumApi->new();
my $artist_id = 'artist_id_example'; # string | The musiXmatch artist id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $s_release_date = 's_release_date_example'; # string | Sort by release date (asc|desc)
my $g_album_name = 'g_album_name_example'; # string | Group by Album Name
my $page_size = 3.4; # Number | Define the page size for paginated results.Range is 1 to 100.
my $page = 3.4; # Number | Define the page number for paginated results

eval { 
    my $result = $api_instance->artist_albums_get_get(artist_id => $artist_id, format => $format, callback => $callback, s_release_date => $s_release_date, g_album_name => $g_album_name, page_size => $page_size, page => $page);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling AlbumApi->artist_albums_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **string**| The musiXmatch artist id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **s_release_date** | **string**| Sort by release date (asc|desc) | [optional] 
 **g_album_name** | **string**| Group by Album Name | [optional] 
 **page_size** | **Number**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **Number**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

