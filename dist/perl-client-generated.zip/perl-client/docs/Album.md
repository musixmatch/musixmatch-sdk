# WWW::SwaggerClient::Object::Album

## Load the model package
```perl
use WWW::SwaggerClient::Object::Album;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**album_coverart_500x500** | **string** |  | [optional] 
**restricted** | [**Number**](Number.md) |  | [optional] 
**artist_id** | [**Number**](Number.md) |  | [optional] 
**album_name** | **string** |  | [optional] 
**album_coverart_800x800** | **string** |  | [optional] 
**album_copyright** | **string** |  | [optional] 
**album_coverart_350x350** | **string** |  | [optional] 
**artist_name** | **string** |  | [optional] 
**primary_genres** | [**AlbumPrimaryGenres**](AlbumPrimaryGenres.md) |  | [optional] 
**album_id** | [**Number**](Number.md) |  | [optional] 
**album_rating** | [**Number**](Number.md) |  | [optional] 
**album_pline** | **string** |  | [optional] 
**album_track_count** | [**Number**](Number.md) |  | [optional] 
**album_release_type** | **string** |  | [optional] 
**album_release_date** | **string** |  | [optional] 
**album_edit_url** | **string** |  | [optional] 
**updated_time** | **string** |  | [optional] 
**secondary_genres** | [**ArtistSecondaryGenres**](ArtistSecondaryGenres.md) |  | [optional] 
**album_mbid** | **string** |  | [optional] 
**album_vanity_id** | **string** |  | [optional] 
**album_coverart_100x100** | **string** |  | [optional] 
**album_label** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


