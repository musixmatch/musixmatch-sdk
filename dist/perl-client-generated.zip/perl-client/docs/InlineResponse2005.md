# WWW::SwaggerClient::Object::InlineResponse2005

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2005;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2005Message**](InlineResponse2005Message.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


