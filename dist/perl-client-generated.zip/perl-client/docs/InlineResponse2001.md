# WWW::SwaggerClient::Object::InlineResponse2001

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2001;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2001Message**](InlineResponse2001Message.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


