# WWW::SwaggerClient::Object::InlineResponse2006MessageBody

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2006MessageBody;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track_list** | [**ARRAY[InlineResponse2006MessageBodyTrackList]**](InlineResponse2006MessageBodyTrackList.md) | A list of tracks | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


