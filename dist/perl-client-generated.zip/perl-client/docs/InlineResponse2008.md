# WWW::SwaggerClient::Object::InlineResponse2008

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2008;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2008Message**](InlineResponse2008Message.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


