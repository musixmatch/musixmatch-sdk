# WWW::SwaggerClient::Object::InlineResponse2008Message

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2008Message;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2008MessageBody**](InlineResponse2008MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


