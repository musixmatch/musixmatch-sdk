# WWW::SwaggerClient::SubtitleApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::SubtitleApi;
```

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**matcher_subtitle_get_get**](SubtitleApi.md#matcher_subtitle_get_get) | **GET** /matcher.subtitle.get | 
[**track_subtitle_get_get**](SubtitleApi.md#track_subtitle_get_get) | **GET** /track.subtitle.get | 


# **matcher_subtitle_get_get**
> InlineResponse2008 matcher_subtitle_get_get(format => $format, callback => $callback, q_track => $q_track, q_artist => $q_artist, f_subtitle_length => $f_subtitle_length, f_subtitle_length_max_deviation => $f_subtitle_length_max_deviation)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::SubtitleApi->new();
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $q_track = 'q_track_example'; # string | The song title
my $q_artist = 'q_artist_example'; # string |  The song artist
my $f_subtitle_length = 3.4; # Number | Filter by subtitle length in seconds
my $f_subtitle_length_max_deviation = 3.4; # Number | Max deviation for a subtitle length in seconds

eval { 
    my $result = $api_instance->matcher_subtitle_get_get(format => $format, callback => $callback, q_track => $q_track, q_artist => $q_artist, f_subtitle_length => $f_subtitle_length, f_subtitle_length_max_deviation => $f_subtitle_length_max_deviation);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SubtitleApi->matcher_subtitle_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **q_track** | **string**| The song title | [optional] 
 **q_artist** | **string**|  The song artist | [optional] 
 **f_subtitle_length** | **Number**| Filter by subtitle length in seconds | [optional] 
 **f_subtitle_length_max_deviation** | **Number**| Max deviation for a subtitle length in seconds | [optional] 

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **track_subtitle_get_get**
> InlineResponse2008 track_subtitle_get_get(track_id => $track_id, format => $format, callback => $callback)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::SubtitleApi->new();
my $track_id = 'track_id_example'; # string | The musiXmatch track id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback

eval { 
    my $result = $api_instance->track_subtitle_get_get(track_id => $track_id, format => $format, callback => $callback);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SubtitleApi->track_subtitle_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **string**| The musiXmatch track id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse2008**](InlineResponse2008.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

