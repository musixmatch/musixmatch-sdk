# WWW::SwaggerClient::SnippetApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::SnippetApi;
```

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**track_snippet_get_get**](SnippetApi.md#track_snippet_get_get) | **GET** /track.snippet.get | 


# **track_snippet_get_get**
> InlineResponse20010 track_snippet_get_get(track_id => $track_id, format => $format, callback => $callback)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::SnippetApi->new();
my $track_id = 'track_id_example'; # string | The musiXmatch track id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback

eval { 
    my $result = $api_instance->track_snippet_get_get(track_id => $track_id, format => $format, callback => $callback);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling SnippetApi->track_snippet_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **string**| The musiXmatch track id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse20010**](InlineResponse20010.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

