# WWW::SwaggerClient::Object::InlineResponse20010

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse20010;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse20010Message**](InlineResponse20010Message.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


