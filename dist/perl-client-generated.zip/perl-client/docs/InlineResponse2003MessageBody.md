# WWW::SwaggerClient::Object::InlineResponse2003MessageBody

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2003MessageBody;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | [**Artist**](Artist.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


