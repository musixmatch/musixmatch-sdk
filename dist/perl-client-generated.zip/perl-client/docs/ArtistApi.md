# WWW::SwaggerClient::ArtistApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::ArtistApi;
```

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**artist_get_get**](ArtistApi.md#artist_get_get) | **GET** /artist.get | 
[**artist_related_get_get**](ArtistApi.md#artist_related_get_get) | **GET** /artist.related.get | 
[**artist_search_get**](ArtistApi.md#artist_search_get) | **GET** /artist.search | 
[**chart_artists_get_get**](ArtistApi.md#chart_artists_get_get) | **GET** /chart.artists.get | 


# **artist_get_get**
> InlineResponse2003 artist_get_get(artist_id => $artist_id, format => $format, callback => $callback)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::ArtistApi->new();
my $artist_id = 'artist_id_example'; # string |  The musiXmatch artist id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback

eval { 
    my $result = $api_instance->artist_get_get(artist_id => $artist_id, format => $format, callback => $callback);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArtistApi->artist_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **string**|  The musiXmatch artist id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **artist_related_get_get**
> InlineResponse2004 artist_related_get_get(artist_id => $artist_id, format => $format, callback => $callback, page_size => $page_size, page => $page)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::ArtistApi->new();
my $artist_id = 'artist_id_example'; # string | The musiXmatch artist id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $page_size = 3.4; # Number | Define the page size for paginated results.Range is 1 to 100.
my $page = 3.4; # Number | Define the page number for paginated results

eval { 
    my $result = $api_instance->artist_related_get_get(artist_id => $artist_id, format => $format, callback => $callback, page_size => $page_size, page => $page);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArtistApi->artist_related_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **artist_id** | **string**| The musiXmatch artist id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **page_size** | **Number**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **Number**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **artist_search_get**
> InlineResponse2004 artist_search_get(format => $format, callback => $callback, q_artist => $q_artist, f_artist_id => $f_artist_id, page => $page, page_size => $page_size)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::ArtistApi->new();
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $q_artist = 'q_artist_example'; # string | The song artist
my $f_artist_id = 3.4; # Number | When set, filter by this artist id
my $page = 3.4; # Number | Define the page number for paginated results
my $page_size = 3.4; # Number | Define the page size for paginated results.Range is 1 to 100.

eval { 
    my $result = $api_instance->artist_search_get(format => $format, callback => $callback, q_artist => $q_artist, f_artist_id => $f_artist_id, page => $page, page_size => $page_size);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArtistApi->artist_search_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **q_artist** | **string**| The song artist | [optional] 
 **f_artist_id** | **Number**| When set, filter by this artist id | [optional] 
 **page** | **Number**| Define the page number for paginated results | [optional] 
 **page_size** | **Number**| Define the page size for paginated results.Range is 1 to 100. | [optional] 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chart_artists_get_get**
> InlineResponse2005 chart_artists_get_get(format => $format, callback => $callback, page => $page, page_size => $page_size, country => $country)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::ArtistApi->new();
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $page = 3.4; # Number | Define the page number for paginated results
my $page_size = 3.4; # Number | Define the page size for paginated results.Range is 1 to 100.
my $country = 'country_example'; # string | A valid ISO 3166 country code

eval { 
    my $result = $api_instance->chart_artists_get_get(format => $format, callback => $callback, page => $page, page_size => $page_size, country => $country);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling ArtistApi->chart_artists_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **page** | **Number**| Define the page number for paginated results | [optional] 
 **page_size** | **Number**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **country** | **string**| A valid ISO 3166 country code | [optional] [default to us]

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

