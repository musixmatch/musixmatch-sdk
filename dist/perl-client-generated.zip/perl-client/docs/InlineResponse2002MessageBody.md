# WWW::SwaggerClient::Object::InlineResponse2002MessageBody

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2002MessageBody;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**album_list** | [**ARRAY[InlineResponse200MessageBody]**](InlineResponse200MessageBody.md) | A list of albums | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


