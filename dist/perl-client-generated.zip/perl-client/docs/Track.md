# WWW::SwaggerClient::Object::Track

## Load the model package
```perl
use WWW::SwaggerClient::Object::Track;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | [**Number**](Number.md) |  | [optional] 
**album_coverart_350x350** | **string** |  | [optional] 
**first_release_date** | **string** |  | [optional] 
**track_isrc** | **string** |  | [optional] 
**explicit** | [**Number**](Number.md) |  | [optional] 
**track_edit_url** | **string** |  | [optional] 
**num_favourite** | [**Number**](Number.md) |  | [optional] 
**album_coverart_500x500** | **string** |  | [optional] 
**album_name** | **string** |  | [optional] 
**track_rating** | [**Number**](Number.md) |  | [optional] 
**track_share_url** | **string** |  | [optional] 
**track_soundcloud_id** | [**Number**](Number.md) |  | [optional] 
**artist_name** | **string** |  | [optional] 
**album_coverart_800x800** | **string** |  | [optional] 
**album_coverart_100x100** | **string** |  | [optional] 
**track_name_translation_list** | **ARRAY[string]** |  | [optional] 
**track_name** | **string** |  | [optional] 
**restricted** | [**Number**](Number.md) |  | [optional] 
**has_subtitles** | [**Number**](Number.md) |  | [optional] 
**updated_time** | **string** |  | [optional] 
**subtitle_id** | [**Number**](Number.md) |  | [optional] 
**lyrics_id** | [**Number**](Number.md) |  | [optional] 
**track_spotify_id** | **string** |  | [optional] 
**has_lyrics** | [**Number**](Number.md) |  | [optional] 
**artist_id** | [**Number**](Number.md) |  | [optional] 
**album_id** | [**Number**](Number.md) |  | [optional] 
**artist_mbid** | **string** |  | [optional] 
**secondary_genres** | [**TrackSecondaryGenres**](TrackSecondaryGenres.md) |  | [optional] 
**commontrack_vanity_id** | **string** |  | [optional] 
**track_id** | [**Number**](Number.md) |  | [optional] 
**track_xboxmusic_id** | **string** |  | [optional] 
**primary_genres** | [**TrackPrimaryGenres**](TrackPrimaryGenres.md) |  | [optional] 
**track_length** | [**Number**](Number.md) |  | [optional] 
**track_mbid** | **string** |  | [optional] 
**commontrack_id** | [**Number**](Number.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


