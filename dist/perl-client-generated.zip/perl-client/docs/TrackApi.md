# WWW::SwaggerClient::TrackApi

## Load the API package
```perl
use WWW::SwaggerClient::Object::TrackApi;
```

All URIs are relative to *https://api.musixmatch.com/ws/1.1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**album_tracks_get_get**](TrackApi.md#album_tracks_get_get) | **GET** /album.tracks.get | 
[**chart_tracks_get_get**](TrackApi.md#chart_tracks_get_get) | **GET** /chart.tracks.get | 
[**matcher_track_get_get**](TrackApi.md#matcher_track_get_get) | **GET** /matcher.track.get | 
[**track_get_get**](TrackApi.md#track_get_get) | **GET** /track.get | 
[**track_search_get**](TrackApi.md#track_search_get) | **GET** /track.search | 


# **album_tracks_get_get**
> InlineResponse2001 album_tracks_get_get(album_id => $album_id, format => $format, callback => $callback, f_has_lyrics => $f_has_lyrics, page => $page, page_size => $page_size)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::TrackApi->new();
my $album_id = 'album_id_example'; # string | The musiXmatch album id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $f_has_lyrics = 'f_has_lyrics_example'; # string | When set, filter only contents with lyrics
my $page = 3.4; # Number | Define the page number for paginated results
my $page_size = 3.4; # Number | Define the page size for paginated results.Range is 1 to 100.

eval { 
    my $result = $api_instance->album_tracks_get_get(album_id => $album_id, format => $format, callback => $callback, f_has_lyrics => $f_has_lyrics, page => $page, page_size => $page_size);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TrackApi->album_tracks_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **album_id** | **string**| The musiXmatch album id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **f_has_lyrics** | **string**| When set, filter only contents with lyrics | [optional] 
 **page** | **Number**| Define the page number for paginated results | [optional] 
 **page_size** | **Number**| Define the page size for paginated results.Range is 1 to 100. | [optional] 

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chart_tracks_get_get**
> InlineResponse2006 chart_tracks_get_get(format => $format, callback => $callback, page => $page, page_size => $page_size, country => $country, f_has_lyrics => $f_has_lyrics)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::TrackApi->new();
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $page = 3.4; # Number | Define the page number for paginated results
my $page_size = 3.4; # Number | Define the page size for paginated results.Range is 1 to 100.
my $country = 'country_example'; # string | A valid ISO 3166 country code
my $f_has_lyrics = 'f_has_lyrics_example'; # string | When set, filter only contents with lyrics

eval { 
    my $result = $api_instance->chart_tracks_get_get(format => $format, callback => $callback, page => $page, page_size => $page_size, country => $country, f_has_lyrics => $f_has_lyrics);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TrackApi->chart_tracks_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **page** | **Number**| Define the page number for paginated results | [optional] 
 **page_size** | **Number**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **country** | **string**| A valid ISO 3166 country code | [optional] [default to us]
 **f_has_lyrics** | **string**| When set, filter only contents with lyrics | [optional] 

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **matcher_track_get_get**
> InlineResponse2009 matcher_track_get_get(format => $format, callback => $callback, q_artist => $q_artist, q_track => $q_track, f_has_lyrics => $f_has_lyrics, f_has_subtitle => $f_has_subtitle)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::TrackApi->new();
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $q_artist = 'q_artist_example'; # string | The song artist
my $q_track = 'q_track_example'; # string | The song title
my $f_has_lyrics = 3.4; # Number | When set, filter only contents with lyrics
my $f_has_subtitle = 3.4; # Number | When set, filter only contents with subtitles

eval { 
    my $result = $api_instance->matcher_track_get_get(format => $format, callback => $callback, q_artist => $q_artist, q_track => $q_track, f_has_lyrics => $f_has_lyrics, f_has_subtitle => $f_has_subtitle);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TrackApi->matcher_track_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **q_artist** | **string**| The song artist | [optional] 
 **q_track** | **string**| The song title | [optional] 
 **f_has_lyrics** | **Number**| When set, filter only contents with lyrics | [optional] 
 **f_has_subtitle** | **Number**| When set, filter only contents with subtitles | [optional] 

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **track_get_get**
> InlineResponse2009 track_get_get(track_id => $track_id, format => $format, callback => $callback)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::TrackApi->new();
my $track_id = 'track_id_example'; # string | The musiXmatch track id
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback

eval { 
    my $result = $api_instance->track_get_get(track_id => $track_id, format => $format, callback => $callback);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TrackApi->track_get_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **track_id** | **string**| The musiXmatch track id | 
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 

### Return type

[**InlineResponse2009**](InlineResponse2009.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **track_search_get**
> InlineResponse2006 track_search_get(format => $format, callback => $callback, q_track => $q_track, q_artist => $q_artist, q_lyrics => $q_lyrics, f_artist_id => $f_artist_id, f_music_genre_id => $f_music_genre_id, f_lyrics_language => $f_lyrics_language, f_has_lyrics => $f_has_lyrics, s_artist_rating => $s_artist_rating, s_track_rating => $s_track_rating, quorum_factor => $quorum_factor, page_size => $page_size, page => $page)





### Example 
```perl
use Data::Dumper;

# Configure API key authorization: key
$WWW::SwaggerClient::Configuration::api_key->{'apikey'} = 'YOUR_API_KEY';
# uncomment below to setup prefix (e.g. Bearer) for API key, if needed
#$WWW::SwaggerClient::Configuration::api_key_prefix->{'apikey'} = "Bearer";

my $api_instance = WWW::SwaggerClient::TrackApi->new();
my $format = 'format_example'; # string | output format: json, jsonp, xml.
my $callback = 'callback_example'; # string | jsonp callback
my $q_track = 'q_track_example'; # string | The song title
my $q_artist = 'q_artist_example'; # string | The song artist
my $q_lyrics = 'q_lyrics_example'; # string | Any word in the lyrics
my $f_artist_id = 3.4; # Number | When set, filter by this artist id
my $f_music_genre_id = 3.4; # Number | When set, filter by this music category id
my $f_lyrics_language = 3.4; # Number | Filter by the lyrics language (en,it,..)
my $f_has_lyrics = 3.4; # Number | When set, filter only contents with lyrics
my $s_artist_rating = 's_artist_rating_example'; # string | Sort by our popularity index for artists (asc|desc)
my $s_track_rating = 's_track_rating_example'; # string | Sort by our popularity index for tracks (asc|desc)
my $quorum_factor = 3.4; # Number | Search only a part of the given query string.Allowed range is (0.1 – 0.9)
my $page_size = 3.4; # Number | Define the page size for paginated results.Range is 1 to 100.
my $page = 3.4; # Number | Define the page number for paginated results

eval { 
    my $result = $api_instance->track_search_get(format => $format, callback => $callback, q_track => $q_track, q_artist => $q_artist, q_lyrics => $q_lyrics, f_artist_id => $f_artist_id, f_music_genre_id => $f_music_genre_id, f_lyrics_language => $f_lyrics_language, f_has_lyrics => $f_has_lyrics, s_artist_rating => $s_artist_rating, s_track_rating => $s_track_rating, quorum_factor => $quorum_factor, page_size => $page_size, page => $page);
    print Dumper($result);
};
if ($@) {
    warn "Exception when calling TrackApi->track_search_get: $@\n";
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **string**| output format: json, jsonp, xml. | [optional] [default to json]
 **callback** | **string**| jsonp callback | [optional] 
 **q_track** | **string**| The song title | [optional] 
 **q_artist** | **string**| The song artist | [optional] 
 **q_lyrics** | **string**| Any word in the lyrics | [optional] 
 **f_artist_id** | **Number**| When set, filter by this artist id | [optional] 
 **f_music_genre_id** | **Number**| When set, filter by this music category id | [optional] 
 **f_lyrics_language** | **Number**| Filter by the lyrics language (en,it,..) | [optional] 
 **f_has_lyrics** | **Number**| When set, filter only contents with lyrics | [optional] 
 **s_artist_rating** | **string**| Sort by our popularity index for artists (asc|desc) | [optional] 
 **s_track_rating** | **string**| Sort by our popularity index for tracks (asc|desc) | [optional] 
 **quorum_factor** | **Number**| Search only a part of the given query string.Allowed range is (0.1 – 0.9) | [optional] [default to 1]
 **page_size** | **Number**| Define the page size for paginated results.Range is 1 to 100. | [optional] 
 **page** | **Number**| Define the page number for paginated results | [optional] 

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

[key](../README.md#key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

