# WWW::SwaggerClient::Object::InlineResponse2001MessageBody

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2001MessageBody;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track_list** | [**ARRAY[Track]**](Track.md) | A list of tracks | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


