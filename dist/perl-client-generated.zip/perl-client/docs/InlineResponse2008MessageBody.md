# WWW::SwaggerClient::Object::InlineResponse2008MessageBody

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2008MessageBody;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subtitle** | [**Subtitle**](Subtitle.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


