# WWW::SwaggerClient::Object::Lyrics

## Load the model package
```perl
use WWW::SwaggerClient::Object::Lyrics;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | [**Number**](Number.md) |  | [optional] 
**pixel_tracking_url** | **string** |  | [optional] 
**publisher_list** | **ARRAY[string]** |  | [optional] 
**lyrics_language_description** | **string** |  | [optional] 
**restricted** | [**Number**](Number.md) |  | [optional] 
**updated_time** | **string** |  | [optional] 
**explicit** | [**Number**](Number.md) |  | [optional] 
**lyrics_copyright** | **string** |  | [optional] 
**html_tracking_url** | **string** |  | [optional] 
**lyrics_language** | **string** |  | [optional] 
**script_tracking_url** | **string** |  | [optional] 
**verified** | [**Number**](Number.md) |  | [optional] 
**lyrics_body** | **string** |  | [optional] 
**lyrics_id** | [**Number**](Number.md) |  | [optional] 
**writer_list** | **ARRAY[string]** |  | [optional] 
**can_edit** | [**Number**](Number.md) |  | [optional] 
**action_requested** | **string** |  | [optional] 
**locked** | [**Number**](Number.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


