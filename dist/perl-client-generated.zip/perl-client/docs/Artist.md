# WWW::SwaggerClient::Object::Artist

## Load the model package
```perl
use WWW::SwaggerClient::Object::Artist;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist_credits** | [**ArtistArtistCredits**](ArtistArtistCredits.md) |  | [optional] 
**artist_mbid** | **string** |  | [optional] 
**artist_name** | **string** |  | [optional] 
**secondary_genres** | [**ArtistSecondaryGenres**](ArtistSecondaryGenres.md) |  | [optional] 
**artist_alias_list** | [**ARRAY[ArtistArtistAliasList]**](ArtistArtistAliasList.md) |  | [optional] 
**artist_vanity_id** | **string** |  | [optional] 
**restricted** | [**Number**](Number.md) |  | [optional] 
**artist_country** | **string** |  | [optional] 
**artist_comment** | **string** |  | [optional] 
**artist_name_translation_list** | [**ARRAY[ArtistArtistNameTranslationList]**](ArtistArtistNameTranslationList.md) |  | [optional] 
**artist_edit_url** | **string** |  | [optional] 
**artist_share_url** | **string** |  | [optional] 
**artist_id** | [**Number**](Number.md) |  | [optional] 
**updated_time** | **string** |  | [optional] 
**managed** | [**Number**](Number.md) |  | [optional] 
**primary_genres** | [**ArtistPrimaryGenres**](ArtistPrimaryGenres.md) |  | [optional] 
**artist_twitter_url** | **string** |  | [optional] 
**artist_rating** | [**Number**](Number.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


