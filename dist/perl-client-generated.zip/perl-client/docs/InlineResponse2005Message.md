# WWW::SwaggerClient::Object::InlineResponse2005Message

## Load the model package
```perl
use WWW::SwaggerClient::Object::InlineResponse2005Message;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2005MessageHeader**](InlineResponse2005MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2004MessageBody**](InlineResponse2004MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


