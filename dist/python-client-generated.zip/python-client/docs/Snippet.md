# Snippet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**html_tracking_url** | **str** |  | [optional] 
**instrumental** | **float** |  | [optional] 
**restricted** | **float** |  | [optional] 
**updated_time** | **str** |  | [optional] 
**snippet_body** | **str** |  | [optional] 
**pixel_tracking_url** | **str** |  | [optional] 
**snippet_id** | **float** |  | [optional] 
**script_tracking_url** | **str** |  | [optional] 
**snippet_language** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


