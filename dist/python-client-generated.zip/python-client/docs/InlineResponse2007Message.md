# InlineResponse2007Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2007MessageBody**](InlineResponse2007MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


