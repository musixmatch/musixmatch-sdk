# Lyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrumental** | **float** |  | [optional] 
**pixel_tracking_url** | **str** |  | [optional] 
**publisher_list** | **list[str]** |  | [optional] 
**lyrics_language_description** | **str** |  | [optional] 
**restricted** | **float** |  | [optional] 
**updated_time** | **str** |  | [optional] 
**explicit** | **float** |  | [optional] 
**lyrics_copyright** | **str** |  | [optional] 
**html_tracking_url** | **str** |  | [optional] 
**lyrics_language** | **str** |  | [optional] 
**script_tracking_url** | **str** |  | [optional] 
**verified** | **float** |  | [optional] 
**lyrics_body** | **str** |  | [optional] 
**lyrics_id** | **float** |  | [optional] 
**writer_list** | **list[str]** |  | [optional] 
**can_edit** | **float** |  | [optional] 
**action_requested** | **str** |  | [optional] 
**locked** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


