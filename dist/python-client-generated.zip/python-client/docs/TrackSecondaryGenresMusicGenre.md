# TrackSecondaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**music_genre_vanity** | **str** |  | [optional] 
**music_genre_name_extended** | **str** |  | [optional] 
**music_genre_parent_id** | **float** |  | [optional] 
**music_genre_name** | **str** |  | [optional] 
**music_genre_id** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


