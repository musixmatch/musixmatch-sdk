# InlineResponse2002Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2002MessageHeader**](InlineResponse2002MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2002MessageBody**](InlineResponse2002MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


