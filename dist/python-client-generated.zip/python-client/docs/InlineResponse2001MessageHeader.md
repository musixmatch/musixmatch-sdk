# InlineResponse2001MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status_code** | **float** |  | [optional] 
**available** | **float** |  | [optional] 
**execute_time** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


