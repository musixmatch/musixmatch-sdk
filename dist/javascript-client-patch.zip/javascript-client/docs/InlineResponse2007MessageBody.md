# MusixmatchApi.InlineResponse2007MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lyrics** | [**Lyrics**](Lyrics.md) |  | [optional] 


