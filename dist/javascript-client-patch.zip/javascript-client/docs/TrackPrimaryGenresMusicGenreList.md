# MusixmatchApi.TrackPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**TrackPrimaryGenresMusicGenre**](TrackPrimaryGenresMusicGenre.md) |  | [optional] 


