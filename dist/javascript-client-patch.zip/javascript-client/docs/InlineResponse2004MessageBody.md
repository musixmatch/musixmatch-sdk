# MusixmatchApi.InlineResponse2004MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | [**[InlineResponse2003MessageBody]**](InlineResponse2003MessageBody.md) | A list of artists | [optional] 


