# MusixmatchApi.TrackSecondaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 


