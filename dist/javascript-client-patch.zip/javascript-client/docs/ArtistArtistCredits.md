# MusixmatchApi.ArtistArtistCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistList** | **[String]** |  | [optional] 


