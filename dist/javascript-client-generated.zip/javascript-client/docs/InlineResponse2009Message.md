# MusixmatchApi.InlineResponse2009Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2006MessageBodyTrackList**](InlineResponse2006MessageBodyTrackList.md) |  | [optional] 


