# MusixmatchApi.TrackPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[TrackPrimaryGenresMusicGenreList]**](TrackPrimaryGenresMusicGenreList.md) |  | [optional] 


