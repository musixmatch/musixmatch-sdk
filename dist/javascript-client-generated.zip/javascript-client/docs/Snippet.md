# MusixmatchApi.Snippet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**htmlTrackingUrl** | **String** |  | [optional] 
**instrumental** | **Number** |  | [optional] 
**restricted** | **Number** |  | [optional] 
**updatedTime** | **String** |  | [optional] 
**snippetBody** | **String** |  | [optional] 
**pixelTrackingUrl** | **String** |  | [optional] 
**snippetId** | **Number** |  | [optional] 
**scriptTrackingUrl** | **String** |  | [optional] 
**snippetLanguage** | **String** |  | [optional] 


