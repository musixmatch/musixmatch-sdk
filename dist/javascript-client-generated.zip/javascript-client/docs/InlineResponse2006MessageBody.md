# MusixmatchApi.InlineResponse2006MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackList** | [**[InlineResponse2006MessageBodyTrackList]**](InlineResponse2006MessageBodyTrackList.md) | A list of tracks | [optional] 


