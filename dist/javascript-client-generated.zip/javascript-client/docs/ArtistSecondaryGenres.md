# MusixmatchApi.ArtistSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | **[String]** |  | [optional] 


