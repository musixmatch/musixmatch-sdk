# MusixmatchApi.InlineResponse2001MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackList** | [**[Track]**](Track.md) | A list of tracks | [optional] 


