# MusixmatchApi.InlineResponse20010MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**snippet** | [**Snippet**](Snippet.md) |  | [optional] 


