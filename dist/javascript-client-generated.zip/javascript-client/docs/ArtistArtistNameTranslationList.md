# MusixmatchApi.ArtistArtistNameTranslationList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artistNameTranslation** | [**ArtistArtistNameTranslation**](ArtistArtistNameTranslation.md) |  | [optional] 


