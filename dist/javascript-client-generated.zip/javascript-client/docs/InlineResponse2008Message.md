# MusixmatchApi.InlineResponse2008Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2008MessageBody**](InlineResponse2008MessageBody.md) |  | [optional] 


