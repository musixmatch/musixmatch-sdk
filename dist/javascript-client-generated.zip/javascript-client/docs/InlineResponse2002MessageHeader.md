# MusixmatchApi.InlineResponse2002MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**available** | **Number** |  | [optional] 
**statusCode** | **Number** |  | [optional] 
**executeTime** | **Number** |  | [optional] 


