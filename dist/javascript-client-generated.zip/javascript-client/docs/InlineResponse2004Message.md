# MusixmatchApi.InlineResponse2004Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2002MessageHeader**](InlineResponse2002MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2004MessageBody**](InlineResponse2004MessageBody.md) |  | [optional] 


