# MusixmatchApi.InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2005Message**](InlineResponse2005Message.md) |  | [optional] 


