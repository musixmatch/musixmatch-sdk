# SWGInlineResponse2006MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackList** | [**NSArray&lt;SWGInlineResponse2006MessageBodyTrackList&gt;***](SWGInlineResponse2006MessageBodyTrackList.md) | A list of tracks | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


