# SWGInlineResponse200Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**SWGInlineResponse200MessageHeader***](SWGInlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**SWGInlineResponse200MessageBody***](SWGInlineResponse200MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


