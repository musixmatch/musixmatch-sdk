# SWGTrackSecondaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreVanity** | **NSString*** |  | [optional] 
**musicGenreNameExtended** | **NSString*** |  | [optional] 
**musicGenreParentId** | **NSNumber*** |  | [optional] 
**musicGenreName** | **NSString*** |  | [optional] 
**musicGenreId** | **NSNumber*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


