# SWGInlineResponse2002Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**SWGInlineResponse2002MessageHeader***](SWGInlineResponse2002MessageHeader.md) |  | [optional] 
**body** | [**SWGInlineResponse2002MessageBody***](SWGInlineResponse2002MessageBody.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


