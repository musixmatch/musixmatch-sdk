# InlineResponse2001MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TrackList** | [**[]Track**](Track.md) | A list of tracks | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


