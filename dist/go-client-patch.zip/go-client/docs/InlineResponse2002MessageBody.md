# InlineResponse2002MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlbumList** | [**[]InlineResponse200MessageBody**](inline_response_200_message_body.md) | A list of albums | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


