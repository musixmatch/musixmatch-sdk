# InlineResponse2001Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Header** | [**InlineResponse2001MessageHeader**](inline_response_200_1_message_header.md) |  | [optional] [default to null]
**Body** | [**InlineResponse2001MessageBody**](inline_response_200_1_message_body.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


