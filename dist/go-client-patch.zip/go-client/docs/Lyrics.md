# Lyrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Instrumental** | **float32** |  | [optional] [default to null]
**PixelTrackingUrl** | **string** |  | [optional] [default to null]
**PublisherList** | **[]string** |  | [optional] [default to null]
**LyricsLanguageDescription** | **string** |  | [optional] [default to null]
**Restricted** | **float32** |  | [optional] [default to null]
**UpdatedTime** | **string** |  | [optional] [default to null]
**Explicit** | **float32** |  | [optional] [default to null]
**LyricsCopyright** | **string** |  | [optional] [default to null]
**HtmlTrackingUrl** | **string** |  | [optional] [default to null]
**LyricsLanguage** | **string** |  | [optional] [default to null]
**ScriptTrackingUrl** | **string** |  | [optional] [default to null]
**Verified** | **float32** |  | [optional] [default to null]
**LyricsBody** | **string** |  | [optional] [default to null]
**LyricsId** | **float32** |  | [optional] [default to null]
**WriterList** | **[]string** |  | [optional] [default to null]
**CanEdit** | **float32** |  | [optional] [default to null]
**ActionRequested** | **string** |  | [optional] [default to null]
**Locked** | **float32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


